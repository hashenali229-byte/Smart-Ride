import type { Timestamp } from 'firebase/firestore';

export type UserRole = 'customer' | 'driver' | 'admin';
export type AccountStatus = 'active' | 'suspended' | 'pending';
export type LanguageCode = 'en' | 'bn' | 'as';
export type DriverApprovalStatus = 'pending' | 'approved' | 'rejected';
export type PortalSection = 'profile' | 'address' | 'status';
export type GenderOption = 'male' | 'female' | 'other';
export type UpiPaymentApp =
  | 'phonepe'
  | 'gpay'
  | 'amazonpay'
  | 'paytm'
  | 'upi'
  | 'razorpay'
  | 'cash';

export interface UserProfile {
  uid: string;
  full_name: string;
  phone_number: string;
  email: string;
  role: UserRole;
  profile_image: string;
  account_status: AccountStatus;
  preferred_language: LanguageCode;
  gender?: GenderOption;
  date_of_birth?: string;
  created_at: Timestamp | null;
  updated_at: Timestamp | null;
}

export interface CustomerProfile {
  uid: string;
  full_name: string;
  phone_number: string;
  email: string;
  profile_image: string;
  default_city: string;
  total_rides: number;
  account_status: 'active' | 'suspended';
  gender?: GenderOption;
  date_of_birth?: string;
  created_at: Timestamp | null;
  updated_at: Timestamp | null;
}

export interface DriverProfile {
  uid: string;
  full_name: string;
  phone_number: string;
  profile_image: string;
  vehicle_number: string;
  vehicle_type: 'Electric Rickshaw';
  driving_license: string;
  vehicle_document: string;
  approval_status: DriverApprovalStatus;
  rejection_reason: string;
  is_online: boolean;
  total_completed_rides: number;
  total_earnings: number;
  rating_avg: number;
  vehicle_check_status?: 'valid_format' | 'invalid_format' | 'unchecked';
  vehicle_rto_state?: string;
  dl_validity_status?: 'valid' | 'invalid' | 'expired' | 'unchecked';
  registration_fee_amount?: number;
  registration_fee_status?: 'pending' | 'paid';
  registration_fee_method?: '' | 'upi' | 'cash' | 'razorpay';
  registration_fee_app?: '' | UpiPaymentApp;
  registration_fee_ref?: string;
  gender?: GenderOption;
  date_of_birth?: string;
  address?: string;
  app_registration_number?: string;
  created_at: Timestamp | null;
  updated_at: Timestamp | null;
}

export interface VehicleRecord {
  vehicle_id: string;
  driver_id: string;
  vehicle_number: string;
  vehicle_type: 'Electric Rickshaw';
  manufacturer: string;
  model_year: number;
  battery_capacity: string;
  rc_number: string;
  status: 'pending' | 'verified' | 'rejected';
  created_at: Timestamp | null;
  updated_at: Timestamp | null;
}

export interface DriverDocumentRecord {
  doc_id: string;
  driver_id: string;
  driving_license_number: string;
  driving_license_url: string;
  rc_number: string;
  vehicle_rc_url: string;
  insurance_url: string;
  verification_status: DriverApprovalStatus;
  reviewed_by: string;
  notes: string;
  created_at: Timestamp | null;
  updated_at: Timestamp | null;
}

export interface FareSettingsRecord {
  base_fare: number;
  price_per_km: number;
  minimum_fare: number;
  waiting_charge: number;
  platform_commission: number;
  driver_registration_fee?: number;
  admin_upi_id?: string;
  business_payee_name?: string;
  currency: 'INR';
  updated_by: string;
  updated_at: Timestamp | null;
}

export interface RideRecord {
  ride_id: string;
  customer_id: string;
  customer_name: string;
  customer_phone: string;
  driver_id: string;
  driver_name: string;
  driver_phone: string;
  driver_vehicle_number: string;
  driver_photo: string;
  pickup_address: string;
  destination_address: string;
  pickup_lat: number;
  pickup_lng: number;
  destination_lat: number;
  destination_lng: number;
  distance_km: number;
  duration_minutes: number;
  waiting_minutes: number;
  estimated_fare: number;
  final_fare: number;
  ride_status: 'requested' | 'accepted' | 'arrived' | 'in_progress' | 'completed' | 'cancelled';
  payment_status: 'pending' | 'paid' | 'failed';
  payment_method: '' | 'cash' | 'upi' | 'razorpay';
  cancelled_by: '' | 'customer' | 'driver' | 'admin';
  created_at: Timestamp | null;
  updated_at: Timestamp | null;
}

export interface DriverLocationRecord {
  driver_id: string;
  lat: number;
  lng: number;
  heading: number;
  is_online: boolean;
  updated_at: Timestamp | null;
}

export interface PaymentRecord {
  payment_id: string;
  ride_id: string;
  customer_id: string;
  driver_id: string;
  amount: number;
  method: 'cash' | 'upi' | 'razorpay';
  status: 'pending' | 'verified' | 'failed';
  created_at: Timestamp | null;
}

export interface NotificationRecord {
  notification_id: string;
  recipient_id: string;
  title: string;
  body: string;
  type: 'driver_approval' | 'ride_update' | 'payment' | 'system';
  is_read: boolean;
  created_at: Timestamp | null;
}

export interface RatingRecord {
  rating_id: string;
  ride_id: string;
  customer_id: string;
  driver_id: string;
  score: number;
  feedback: string;
  created_at: Timestamp | null;
}

export interface ComplaintRecord {
  complaint_id: string;
  ride_id: string;
  reporter_id: string;
  reporter_role: 'customer' | 'driver';
  reporter_name: string;
  subject: string;
  description: string;
  status: 'open' | 'resolved' | 'dismissed';
  admin_notes: string;
  created_at: Timestamp | null;
  updated_at: Timestamp | null;
}

export interface AdminUserRecord {
  uid: string;
  email: string;
  full_name: string;
  role: 'super_admin' | 'ops_admin';
  status: 'active' | 'revoked';
  created_at: Timestamp | null;
  updated_at: Timestamp | null;
}

export interface AdminPayoutSettingsRecord {
  account_holder_name: string;
  bank_name: string;
  account_number: string;
  ifsc_code: string;
  branch_name: string;
  upi_id: string;
  payee_display_name: string;
  updated_by: string;
  updated_at: Timestamp | null;
}

export interface AppRatingRecord {
  rating_id: string;
  user_id: string;
  user_role: 'customer' | 'driver';
  user_name: string;
  ride_id: string;
  score: number;
  feedback: string;
  created_at: Timestamp | null;
}
