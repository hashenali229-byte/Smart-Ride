import React, { useEffect, useState } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import {
  isSignInWithEmailLink,
  onAuthStateChanged,
  signInWithEmailLink,
  signOut,
  type User,
} from 'firebase/auth';
import {
  Activity,
  ArrowRight,
  FileText,
  Globe,
  Headphones,
  IdCard,
  ImagePlus,
  LogIn,
  LogOut,
  MapPin,
  Maximize2,
  Menu,
  Minimize2,
  Palette,
  QrCode,
  RefreshCw,
  RotateCcw,
  Shield,
  Smartphone,
  Truck,
  User as UserIcon,
  UserCheck,
  X,
} from 'lucide-react';
import { AdminDashboard } from './components/AdminDashboard';
import { AndroidBuildHub } from './components/AndroidBuildHub';
import { CustomerPortal } from './components/CustomerPortal';
import { CustomerSupportView } from './components/CustomerSupportView';
import { DriverIdCardView } from './components/DriverIdCardView';
import { DriverPortal } from './components/DriverPortal';
import { ErrorBoundary } from './components/ErrorBoundary';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallButton';
import { TermsConditionsView } from './components/TermsConditionsView';
import { VehicleStickerView } from './components/VehicleStickerView';
import {
  ADMIN_OTP_EMAIL_STORAGE_KEY,
  ADMIN_SESSION_EXPIRED_KEY,
  auth,
  getAdminSessionTiming,
  verifyAdminSession,
} from './lib/firebase';
import { TRANSLATIONS } from './lib/i18n';
import { getGoogleMapsApiKey } from './lib/maps';
import {
  compressWallpaperFile,
  loadSavedWallpaper,
  saveWallpaperConfig,
  WALLPAPER_OPTIONS,
  type WallpaperConfig,
  type WallpaperPresetId,
} from './lib/wallpapers';
import type { LanguageCode, PortalSection } from './types/smartride';

type ActivePortal =
  | 'welcome'
  | 'customer'
  | 'driver'
  | 'driver_id'
  | 'app_sticker'
  | 'terms'
  | 'support'
  | 'admin'
  | 'android';

const ROLE_STORAGE_KEY = 'smart_ride_role';
const LANG_STORAGE_KEY = 'smart_ride_lang';

function getInitialPortal(): ActivePortal {
  try {
    const saved = window.localStorage.getItem(ROLE_STORAGE_KEY);
    if (saved === 'customer' || saved === 'driver') {
      return saved;
    }
  } catch {
    // Ignore storage access errors in restricted frames
  }
  return 'welcome';
}

function getInitialLanguage(): LanguageCode {
  try {
    const saved = window.localStorage.getItem(LANG_STORAGE_KEY);
    if (saved === 'en' || saved === 'bn' || saved === 'as') {
      return saved;
    }
  } catch {
    // Ignore storage access errors
  }
  return 'en';
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isAuthorizedAdmin, setIsAuthorizedAdmin] = useState(false);
  const [activePortal, setActivePortal] = useState<ActivePortal>(getInitialPortal);
  const [activeSection, setActiveSection] = useState<PortalSection>(() =>
    getInitialPortal() === 'driver' ? 'status' : 'address'
  );
  const [menuOpen, setMenuOpen] = useState(false);
  const [language, setLanguage] = useState<LanguageCode>(getInitialLanguage);
  const [wallpaper, setWallpaper] = useState<WallpaperConfig>(loadSavedWallpaper);
  const [wallpaperError, setWallpaperError] = useState<string | null>(null);
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [pendingEmailLink, setPendingEmailLink] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPwaMode, setIsPwaMode] = useState(false);
  const [adminSessionExpiredNotice, setAdminSessionExpiredNotice] = useState<boolean>(() => {
    try {
      return window.localStorage.getItem(ADMIN_SESSION_EXPIRED_KEY) === '1';
    } catch {
      return false;
    }
  });

  const mapsApiKey = getGoogleMapsApiKey();
  const mapsEnabled = mapsApiKey.length > 0;
  const t = TRANSLATIONS[language];

  useEffect(() => {
    const checkDisplay = () => {
      const pwa =
        window.matchMedia('(display-mode: fullscreen)').matches ||
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as unknown as { standalone?: boolean }).standalone === true;
      setIsPwaMode(pwa);
      setIsFullscreen(Boolean(document.fullscreenElement) || pwa);
    };
    checkDisplay();
    document.addEventListener('fullscreenchange', checkDisplay);
    return () => document.removeEventListener('fullscreenchange', checkDisplay);
  }, []);

  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
      }
    } catch {
      // Ignore browser fullscreen restrictions in embedded previews
    }
  };

  // Auto-complete Admin Gmail OTP sign-in link when returning from Gmail
  useEffect(() => {
    const fullHref = window.location.href;
    const isOtpQuery = new URLSearchParams(window.location.search).get('adminOtp') === '1';
    if (isSignInWithEmailLink(auth, fullHref)) {
      setActivePortal('admin');
      let savedEmail = '';
      try {
        savedEmail = window.localStorage.getItem(ADMIN_OTP_EMAIL_STORAGE_KEY) || '';
      } catch {
        savedEmail = '';
      }
      window.history.replaceState({}, document.title, window.location.pathname);
      if (savedEmail) {
        void signInWithEmailLink(auth, savedEmail, fullHref)
          .then(() => {
            try {
              window.localStorage.removeItem(ADMIN_OTP_EMAIL_STORAGE_KEY);
              window.localStorage.removeItem(ADMIN_SESSION_EXPIRED_KEY);
            } catch {
              // Ignore storage errors
            }
            setAdminSessionExpiredNotice(false);
            setPendingEmailLink(null);
          })
          .catch(() => {
            setPendingEmailLink(fullHref);
          });
      } else {
        setPendingEmailLink(fullHref);
      }
    } else if (isOtpQuery) {
      setActivePortal('admin');
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    let active = true;
    if (!user) {
      setIsAuthorizedAdmin(false);
      return () => {
        active = false;
      };
    }
    void verifyAdminSession(user).then((allowed) => {
      if (!active) return;
      setIsAuthorizedAdmin(allowed);
      if (allowed) {
        try {
          window.localStorage.removeItem(ADMIN_SESSION_EXPIRED_KEY);
        } catch {
          // Ignore storage errors
        }
        setAdminSessionExpiredNotice(false);
      } else if (activePortal === 'admin') {
        void getAdminSessionTiming(user).then((timing) => {
          if (active && !timing.valid) {
            try {
              window.localStorage.setItem(ADMIN_SESSION_EXPIRED_KEY, '1');
            } catch {
              // Ignore storage errors
            }
            setAdminSessionExpiredNotice(true);
            void signOut(auth);
          }
        });
      }
    });
    return () => {
      active = false;
    };
  }, [user, activePortal]);

  // Global 12-hour Admin auto-logout enforcement even if Admin switches to another tab
  useEffect(() => {
    if (!user || !isAuthorizedAdmin) return;
    let cancelled = false;
    let timeoutId: number | undefined;

    const enforceExpiry = async () => {
      const timing = await getAdminSessionTiming(user);
      if (cancelled) return;
      if (!timing.valid) {
        try {
          window.localStorage.setItem(ADMIN_SESSION_EXPIRED_KEY, '1');
        } catch {
          // Ignore storage errors
        }
        setAdminSessionExpiredNotice(true);
        setIsAuthorizedAdmin(false);
        setActivePortal('admin');
        await signOut(auth);
        return;
      }
      if (timeoutId) window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(
        () => {
          void enforceExpiry();
        },
        Math.min(timing.remainingMs + 500, 2147483000)
      );
    };

    void enforceExpiry();
    const intervalId = window.setInterval(() => {
      void enforceExpiry();
    }, 30000);
    const onFocusOrVisibility = () => {
      if (document.visibilityState === 'visible') {
        void enforceExpiry();
      }
    };
    window.addEventListener('focus', onFocusOrVisibility);
    document.addEventListener('visibilitychange', onFocusOrVisibility);

    return () => {
      cancelled = true;
      if (timeoutId) window.clearTimeout(timeoutId);
      window.clearInterval(intervalId);
      window.removeEventListener('focus', onFocusOrVisibility);
      document.removeEventListener('visibilitychange', onFocusOrVisibility);
    };
  }, [user, isAuthorizedAdmin]);

  useEffect(() => {
    const onQuotaExceeded = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  const handleLanguageChange = (nextLang: LanguageCode) => {
    setLanguage(nextLang);
    try {
      window.localStorage.setItem(LANG_STORAGE_KEY, nextLang);
    } catch {
      // Ignore storage errors
    }
  };

  const handleSelectWallpaperPreset = (id: Exclude<WallpaperPresetId, 'custom'>) => {
    const next: WallpaperConfig = { id };
    setWallpaper(next);
    setWallpaperError(null);
    saveWallpaperConfig(next);
  };

  const handleUploadWallpaper = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setWallpaperError(null);
    try {
      const dataUrl = await compressWallpaperFile(file);
      const next: WallpaperConfig = { id: 'custom', customImage: dataUrl };
      setWallpaper(next);
      saveWallpaperConfig(next);
    } catch (err) {
      setWallpaperError(err instanceof Error ? err.message : 'Failed to load wallpaper image.');
    }
  };

  const handleResetWallpaper = () => {
    const next: WallpaperConfig = { id: 'clean' };
    setWallpaper(next);
    setWallpaperError(null);
    saveWallpaperConfig(next);
  };

  const selectRolePortal = (role: 'customer' | 'driver', section?: PortalSection) => {
    try {
      window.localStorage.setItem(ROLE_STORAGE_KEY, role);
    } catch {
      // Ignore storage errors
    }
    setActivePortal(role);
    setActiveSection(section ?? (role === 'customer' ? 'address' : 'status'));
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSwitchRole = () => {
    try {
      window.localStorage.removeItem(ROLE_STORAGE_KEY);
    } catch {
      // Ignore storage errors
    }
    setActivePortal('welcome');
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectSection = (section: PortalSection) => {
    if (activePortal !== 'customer' && activePortal !== 'driver') {
      selectRolePortal('customer', section);
      return;
    }
    setActiveSection(section);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePrimaryAuthAction = async () => {
    if (user) {
      await signOut(auth);
      if (activePortal === 'admin' || activePortal === 'android') {
        setActivePortal('welcome');
      }
    } else {
      if (activePortal === 'welcome') {
        selectRolePortal('customer', 'profile');
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  };

  const isRidePortal = activePortal === 'customer' || activePortal === 'driver';
  const savedRole =
    typeof window !== 'undefined' && window.localStorage.getItem(ROLE_STORAGE_KEY) === 'driver'
      ? 'driver'
      : 'customer';

  const welcomeScreen = (
    <section className="max-w-2xl mx-auto py-1 sm:py-10">
      <div className="bg-white border border-neutral-200 rounded-2xl sm:rounded-3xl p-5 sm:p-10 space-y-6 sm:space-y-8 shadow-sm">
        <div className="text-center space-y-2.5 sm:space-y-3">
          <img
            src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
            alt="Smart Ride"
            referrerPolicy="no-referrer"
            className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl object-cover border border-neutral-200 mx-auto"
          />
          <h1 className="text-xl sm:text-3xl font-bold tracking-tight text-neutral-900 text-balance">
            {t.welcomeHeadline}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-600">{t.chooseRoleSubtitle}</p>
        </div>

        {/* Strictly Customer & Driver Sign Up Options Only */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">
          <button
            type="button"
            onClick={() => selectRolePortal('customer', 'address')}
            className="group text-left p-5 sm:p-6 rounded-2xl border-2 border-emerald-200 bg-emerald-50/40 hover:bg-emerald-50 hover:border-emerald-500 active:scale-[0.99] transition-all flex flex-col justify-between gap-4 sm:gap-5 min-h-[144px] sm:min-h-[168px]"
          >
            <div className="space-y-2.5 sm:space-y-3">
              <div className="w-11 h-11 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                <UserIcon className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-neutral-900">{t.signUpCustomerBtn}</h2>
                <p className="text-xs text-neutral-600 mt-1">{t.roleCustomerDesc}</p>
              </div>
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-emerald-200/70 text-xs font-semibold text-emerald-700">
              <span>{t.signUpCustomerBtn}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => selectRolePortal('driver', 'status')}
            className="group text-left p-5 sm:p-6 rounded-2xl border-2 border-neutral-200 bg-neutral-50 hover:bg-white hover:border-neutral-900 active:scale-[0.99] transition-all flex flex-col justify-between gap-4 sm:gap-5 min-h-[144px] sm:min-h-[168px]"
          >
            <div className="space-y-2.5 sm:space-y-3">
              <div className="w-11 h-11 rounded-xl bg-neutral-900 text-white flex items-center justify-center">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-neutral-900">{t.signUpDriverBtn}</h2>
                <p className="text-xs text-neutral-600 mt-1">{t.roleDriverDesc}</p>
              </div>
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-neutral-200 text-xs font-semibold text-neutral-900">
              <span>{t.signUpDriverBtn}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>
        </div>
      </div>

      <div className="mt-4 flex justify-center">
        <PWAInstallButton />
      </div>
    </section>
  );

  const portalContent = !authReady ? (
    <div className="bg-white border border-neutral-200 rounded-2xl p-8 space-y-4">
      <div className="h-6 w-48 bg-neutral-200 rounded animate-pulse" />
      <div className="h-40 w-full bg-neutral-100 rounded-xl animate-pulse" />
    </div>
  ) : activePortal === 'welcome' ? (
    welcomeScreen
  ) : activePortal === 'customer' ? (
    <CustomerPortal
      user={user}
      language={language}
      onLanguageChange={handleLanguageChange}
      mapsEnabled={mapsEnabled}
      activeSection={activeSection}
      onSectionChange={setActiveSection}
    />
  ) : activePortal === 'driver' ? (
    <DriverPortal
      user={user}
      language={language}
      mapsEnabled={mapsEnabled}
      activeSection={activeSection}
      onSectionChange={setActiveSection}
      onOpenIdCard={() => {
        setActivePortal('driver_id');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }}
      onOpenSticker={() => {
        setActivePortal('app_sticker');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }}
    />
  ) : activePortal === 'driver_id' ? (
    <DriverIdCardView
      user={user}
      language={language}
      onOpenDriverPortal={() => selectRolePortal('driver', 'profile')}
    />
  ) : activePortal === 'app_sticker' ? (
    <VehicleStickerView
      user={user}
      language={language}
      onOpenDriverPortal={() => selectRolePortal('driver', 'profile')}
    />
  ) : activePortal === 'terms' ? (
    <TermsConditionsView
      language={language}
      userRoleLabel={savedRole === 'driver' ? 'Driver' : 'Customer'}
    />
  ) : activePortal === 'support' ? (
    <CustomerSupportView
      user={user}
      language={language}
      reporterRole={savedRole}
    />
  ) : activePortal === 'admin' ? (
    <AdminDashboard
      user={user}
      language={language}
      mapsEnabled={mapsEnabled}
      sessionExpiredNotice={adminSessionExpiredNotice}
      pendingEmailLink={pendingEmailLink}
      onClearPendingEmailLink={() => setPendingEmailLink(null)}
    />
  ) : isAuthorizedAdmin ? (
    <AndroidBuildHub />
  ) : (
    welcomeScreen
  );

  const activeWallpaperOption = WALLPAPER_OPTIONS.find((w) => w.id === wallpaper.id);
  const isCustomWallpaper = wallpaper.id === 'custom' && Boolean(wallpaper.customImage);
  const hasDarkOuterBg = isCustomWallpaper || Boolean(activeWallpaperOption?.isDarkCanvas);
  const outerContainerClass = isCustomWallpaper
    ? 'min-h-[100dvh] w-full overflow-x-hidden flex flex-col relative text-neutral-900 bg-neutral-900'
    : `min-h-[100dvh] w-full overflow-x-hidden flex flex-col relative ${activeWallpaperOption?.containerClass || 'bg-neutral-50 text-neutral-900'}`;

  const mobileScreenTitle =
    activePortal === 'customer'
      ? t.navCustomer
      : activePortal === 'driver'
        ? t.navDriver
        : activePortal === 'driver_id'
          ? t.menuDriverIdCard
          : activePortal === 'app_sticker'
            ? t.menuAppSticker
            : activePortal === 'terms'
              ? t.menuTerms
              : activePortal === 'support'
                ? t.menuSupport
                : activePortal === 'admin'
                  ? t.navAdmin
                  : activePortal === 'android'
                    ? t.navAndroid
                    : t.brandName;

  return (
    <div className={outerContainerClass}>
      {isCustomWallpaper && wallpaper.customImage && (
        <>
          <img
            src={wallpaper.customImage}
            alt=""
            aria-hidden="true"
            className="fixed inset-0 w-full h-full object-cover pointer-events-none z-0"
          />
          <div
            aria-hidden="true"
            className="fixed inset-0 bg-black/25 pointer-events-none z-0"
          />
        </>
      )}
      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Top Navigation Bar: Native Fullscreen Android App Bar on mobile, 3-zone header on desktop */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-neutral-200 pt-safe">
        {/* Mobile Android App Header */}
        <div className="md:hidden px-2.5 h-14 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 min-w-0">
            <button
              type="button"
              onClick={() => setMenuOpen((prev) => !prev)}
              aria-label="Open menu"
              aria-expanded={menuOpen}
              className="w-11 h-11 flex items-center justify-center rounded-xl text-neutral-900 active:bg-neutral-100 shrink-0"
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <button
              type="button"
              onClick={() => setActivePortal('welcome')}
              className="flex items-center gap-2 min-w-0 text-left"
            >
              <img
                src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
                alt="Smart Ride"
                referrerPolicy="no-referrer"
                className="w-7 h-7 rounded-lg object-cover border border-neutral-200 shrink-0"
              />
              <span className="text-base font-bold tracking-tight text-neutral-900 truncate">
                {mobileScreenTitle}
              </span>
            </button>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {!isPwaMode && (
              <button
                type="button"
                onClick={() => void toggleFullscreen()}
                aria-label={isFullscreen ? 'Exit Full Screen' : 'Full Screen'}
                className="w-10 h-10 flex items-center justify-center rounded-xl text-neutral-700 hover:bg-neutral-100 active:bg-neutral-200"
              >
                {isFullscreen ? (
                  <Minimize2 className="w-4 h-4" />
                ) : (
                  <Maximize2 className="w-4 h-4" />
                )}
              </button>
            )}
            <button
              type="button"
              onClick={handlePrimaryAuthAction}
              className="min-h-[38px] px-3 py-1.5 text-xs font-semibold text-white bg-neutral-900 active:bg-neutral-800 rounded-xl whitespace-nowrap inline-flex items-center gap-1.5"
            >
              {user ? (
                <>
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{t.signOut}</span>
                </>
              ) : (
                <>
                  <LogIn className="w-3.5 h-3.5" />
                  <span>{t.signIn}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Desktop Header */}
        <div className="hidden md:flex max-w-7xl mx-auto px-6 h-16 items-center justify-between gap-8">
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setMenuOpen((prev) => !prev)}
              aria-label="Open 3-line menu"
              aria-expanded={menuOpen}
              className="min-h-[40px] px-3 flex items-center justify-center gap-1.5 rounded-lg border border-neutral-300 bg-white hover:bg-neutral-100 text-neutral-900 transition-colors"
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              <span className="text-xs font-semibold">Menu</span>
            </button>

            <button
              type="button"
              onClick={() => setActivePortal('welcome')}
              className="text-lg font-bold tracking-tight text-neutral-900 whitespace-nowrap shrink-0 flex items-center gap-2.5"
            >
              <img
                src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
                alt="Smart Ride"
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-lg object-cover border border-neutral-200"
              />
              <span>{t.brandName}</span>
            </button>
          </div>

          <nav className="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <button
              type="button"
              onClick={() => selectRolePortal('customer', 'address')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activePortal === 'customer'
                  ? 'border-emerald-600 text-neutral-900 font-semibold'
                  : 'border-transparent hover:text-neutral-900'
              }`}
            >
              {t.navCustomer}
            </button>
            <button
              type="button"
              onClick={() => selectRolePortal('driver', 'status')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activePortal === 'driver'
                  ? 'border-emerald-600 text-neutral-900 font-semibold'
                  : 'border-transparent hover:text-neutral-900'
              }`}
            >
              {t.navDriver}
            </button>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={handlePrimaryAuthAction}
              className="px-4 py-2 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
            >
              {user ? (
                <>
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{t.signOut}</span>
                </>
              ) : (
                <>
                  <LogIn className="w-3.5 h-3.5" />
                  <span>{t.signIn}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* 3-Line Menu Drawer (Profile, Address, Ride Status, Customer Support, Language, Admin-only access) */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-[1px]"
            onClick={() => setMenuOpen(false)}
          />
          <aside className="relative z-10 w-80 max-w-[85vw] bg-white h-full border-r border-neutral-200 shadow-2xl p-5 flex flex-col justify-between overflow-y-auto">
            <div className="space-y-5">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
                <div className="flex items-center gap-2.5">
                  <img
                    src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
                    alt="Smart Ride"
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded-lg object-cover border border-neutral-200"
                  />
                  <div>
                    <p className="text-sm font-bold text-neutral-900">{t.brandName}</p>
                    <p className="text-xs text-neutral-500">
                      {activePortal === 'driver'
                        ? t.roleDriverTitle
                        : activePortal === 'customer'
                          ? t.roleCustomerTitle
                          : t.brandName}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setMenuOpen(false)}
                  aria-label="Close menu"
                  className="p-2 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Exact 3 Lines: 1. Profile, 2. Address, 3. Ride Status */}
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => handleSelectSection('profile')}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors text-left ${
                    isRidePortal && activeSection === 'profile'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-900'
                  }`}
                >
                  <UserCheck className="w-4 h-4 shrink-0" />
                  <span>{t.menuProfile}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectSection('address')}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors text-left ${
                    isRidePortal && activeSection === 'address'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-900'
                  }`}
                >
                  <MapPin className="w-4 h-4 shrink-0" />
                  <span>{t.menuAddress}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectSection('status')}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors text-left ${
                    isRidePortal && activeSection === 'status'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-900'
                  }`}
                >
                  <Activity className="w-4 h-4 shrink-0" />
                  <span>{t.menuRideStatus}</span>
                </button>

                {/* 4. Customer Support */}
                <button
                  type="button"
                  onClick={() => {
                    setActivePortal('support');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors text-left ${
                    activePortal === 'support'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-900'
                  }`}
                >
                  <Headphones className="w-4 h-4 shrink-0" />
                  <span>{t.menuSupport}</span>
                </button>

                {/* 5. Terms & Conditions for Customer & Driver */}
                <button
                  type="button"
                  onClick={() => {
                    setActivePortal('terms');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors text-left ${
                    activePortal === 'terms'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-900'
                  }`}
                >
                  <FileText className="w-4 h-4 shrink-0" />
                  <span>{t.menuTerms}</span>
                </button>

                {/* 6. Driver ID Card & App Vehicle Sticker */}
                <div className="pt-2 mt-2 border-t border-neutral-100 space-y-2">
                  <button
                    type="button"
                    onClick={() => {
                      setActivePortal('driver_id');
                      setMenuOpen(false);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors text-left ${
                      activePortal === 'driver_id'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-900'
                    }`}
                  >
                    <IdCard className="w-4 h-4 shrink-0" />
                    <span>{t.menuDriverIdCard}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setActivePortal('app_sticker');
                      setMenuOpen(false);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors text-left ${
                      activePortal === 'app_sticker'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-900'
                    }`}
                  >
                    <QrCode className="w-4 h-4 shrink-0" />
                    <span>{t.menuAppSticker}</span>
                  </button>
                </div>
              </div>

              {/* Admin Option: Exclusively inside Menu; non-admins are blocked by AuthGate & Firestore rules */}
              <div className="pt-4 border-t border-neutral-200 space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setActivePortal('admin');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between gap-3 px-3.5 py-3 rounded-xl text-xs font-semibold border transition-colors ${
                    activePortal === 'admin'
                      ? 'bg-neutral-900 text-white border-neutral-900'
                      : 'bg-neutral-100 border-neutral-300 text-neutral-900 hover:bg-neutral-200'
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <Shield className="w-4 h-4 shrink-0" />
                    <span>{t.navAdmin}</span>
                  </span>
                  <span
                    className={`text-[10px] font-medium ${
                      activePortal === 'admin' ? 'text-emerald-300' : 'text-neutral-500'
                    }`}
                  >
                    {isAuthorizedAdmin ? 'Active' : 'Owner'}
                  </span>
                </button>

                {isAuthorizedAdmin && (
                  <button
                    type="button"
                    onClick={() => {
                      setActivePortal('android');
                      setMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-xs font-medium transition-colors ${
                      activePortal === 'android'
                        ? 'bg-neutral-900 text-white'
                        : 'text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 shrink-0" />
                    <span>{t.navAndroid}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleSwitchRole}
                  className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-neutral-800 border border-neutral-200 hover:bg-neutral-50"
                >
                  <RefreshCw className="w-4 h-4 shrink-0 text-emerald-700" />
                  <span>{t.switchRole}</span>
                </button>
              </div>

              {/* 5. Language Option Exclusively Inside Menu (English / বাংলা / অসমীয়া) */}
              <div className="pt-4 border-t border-neutral-200 space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-semibold text-neutral-700 px-1">
                  <Globe className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{t.languageLabel}</span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleLanguageChange('en')}
                    className={`px-2 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                      language === 'en'
                        ? 'bg-neutral-900 text-white border-neutral-900'
                        : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
                    }`}
                  >
                    English
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLanguageChange('bn')}
                    className={`px-2 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                      language === 'bn'
                        ? 'bg-neutral-900 text-white border-neutral-900'
                        : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
                    }`}
                  >
                    বাংলা
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLanguageChange('as')}
                    className={`px-2 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                      language === 'as'
                        ? 'bg-neutral-900 text-white border-neutral-900'
                        : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
                    }`}
                  >
                    অসমীয়া
                  </button>
                </div>
              </div>
              {/* 6. App Wallpaper Selector Exclusively Inside Menu */}
              <div className="pt-4 border-t border-neutral-200 space-y-2.5">
                <div className="flex items-center justify-between gap-2 px-1">
                  <span className="flex items-center gap-2 text-xs font-semibold text-neutral-700">
                    <Palette className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{t.wallpaperLabel}</span>
                  </span>
                  {wallpaper.id !== 'clean' && (
                    <button
                      type="button"
                      onClick={handleResetWallpaper}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-neutral-600 hover:text-neutral-900"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>{t.resetWallpaper}</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-5 gap-1.5">
                  {WALLPAPER_OPTIONS.map((opt) => {
                    const selected = wallpaper.id === opt.id;
                    const label =
                      language === 'as'
                        ? opt.labelAs
                        : language === 'bn'
                          ? opt.labelBn
                          : opt.labelEn;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => handleSelectWallpaperPreset(opt.id)}
                        title={label}
                        className={`flex flex-col items-center gap-1 p-1.5 rounded-lg border transition-colors ${
                          selected
                            ? 'border-emerald-600 ring-2 ring-emerald-500/30 bg-emerald-50/40'
                            : 'border-neutral-200 hover:bg-neutral-50'
                        }`}
                      >
                        <span
                          className={`w-6 h-6 rounded-md border ${opt.swatchClass} block`}
                        />
                        <span className="text-[10px] font-medium text-neutral-700 truncate w-full text-center">
                          {label}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <label className="w-full min-h-[38px] px-3 py-2 rounded-xl border border-neutral-300 bg-neutral-50 hover:bg-neutral-100 text-xs font-medium text-neutral-800 flex items-center justify-center gap-2 cursor-pointer transition-colors">
                  <ImagePlus className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>{t.uploadWallpaper}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleUploadWallpaper}
                    className="hidden"
                  />
                </label>

                {wallpaperError && (
                  <p className="text-[11px] text-red-600 px-1">{wallpaperError}</p>
                )}
              </div>
            </div>

            {user && (
              <div className="pt-4 border-t border-neutral-200 text-xs text-neutral-500">
                <p className="truncate font-mono text-emerald-700">
                  {user.email || user.phoneNumber || user.uid}
                </p>
              </div>
            )}
          </aside>
        </div>
      )}

      {/* Main Content */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-3 sm:pt-5 pb-24 md:pb-12 space-y-4 sm:space-y-6 overflow-x-hidden">
        {/* Desktop Status Bar (Hidden on Mobile so phone view stays native full-screen app) */}
        {(user || isRidePortal) && (
          <div
            className={`hidden md:flex flex-row items-center justify-between gap-3 ${
              hasDarkOuterBg
                ? 'bg-white/95 backdrop-blur-sm px-4 py-2.5 rounded-xl border border-neutral-200 shadow-sm'
                : 'pb-4 border-b border-neutral-200'
            }`}
          >
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
              <span className="font-medium text-neutral-800">Smart Ride Electronic Rickshaw</span>
              <span aria-hidden="true">·</span>
              <span>India (INR ₹)</span>
              {isRidePortal && (
                <>
                  <span aria-hidden="true">·</span>
                  <button
                    type="button"
                    onClick={handleSwitchRole}
                    className="font-medium text-emerald-700 hover:underline"
                  >
                    {t.switchRole}
                  </button>
                </>
              )}
              {user && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-emerald-700">
                    {user.email || user.phoneNumber || user.uid}
                  </span>
                </>
              )}
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <PWAInstallButton />
            </div>
          </div>
        )}

        <ErrorBoundary>
          {mapsEnabled ? (
            <APIProvider
              apiKey={mapsApiKey}
              language={language === 'bn' ? 'bn' : language === 'as' ? 'as' : 'en'}
              region="IN"
              libraries={['places', 'routes']}
            >
              {portalContent}
            </APIProvider>
          ) : (
            portalContent
          )}
        </ErrorBoundary>
      </main>

      <OfflineIndicator />

      {/* Native Android Bottom Navigation Bar */}
      {isRidePortal ? (
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200 grid grid-cols-4 min-h-[64px] pb-safe">
          <button
            type="button"
            onClick={() => handleSelectSection('profile')}
            className={`relative flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium ${
              activeSection === 'profile' ? 'text-emerald-700 font-semibold' : 'text-neutral-500'
            }`}
          >
            {activeSection === 'profile' && (
              <span className="absolute top-0 w-8 h-0.5 rounded-full bg-emerald-600" />
            )}
            <UserCheck className="w-5 h-5" />
            <span className="truncate max-w-[78px]">Profile</span>
          </button>
          <button
            type="button"
            onClick={() => handleSelectSection('address')}
            className={`relative flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium ${
              activeSection === 'address' ? 'text-emerald-700 font-semibold' : 'text-neutral-500'
            }`}
          >
            {activeSection === 'address' && (
              <span className="absolute top-0 w-8 h-0.5 rounded-full bg-emerald-600" />
            )}
            <MapPin className="w-5 h-5" />
            <span className="truncate max-w-[78px]">Ride</span>
          </button>
          <button
            type="button"
            onClick={() => handleSelectSection('status')}
            className={`relative flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium ${
              activeSection === 'status' ? 'text-emerald-700 font-semibold' : 'text-neutral-500'
            }`}
          >
            {activeSection === 'status' && (
              <span className="absolute top-0 w-8 h-0.5 rounded-full bg-emerald-600" />
            )}
            <Activity className="w-5 h-5" />
            <span className="truncate max-w-[78px]">Status</span>
          </button>
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="relative flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium text-neutral-500"
          >
            <Menu className="w-5 h-5" />
            <span className="truncate max-w-[78px]">Menu</span>
          </button>
        </nav>
      ) : (
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200 grid grid-cols-4 min-h-[64px] pb-safe">
          <button
            type="button"
            onClick={() => selectRolePortal('customer', 'address')}
            className={`relative flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium ${
              activePortal === 'welcome' ? 'text-emerald-700 font-semibold' : 'text-neutral-600'
            }`}
          >
            <UserIcon className="w-5 h-5" />
            <span>Customer</span>
          </button>
          <button
            type="button"
            onClick={() => selectRolePortal('driver', 'status')}
            className="relative flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium text-neutral-600"
          >
            <Truck className="w-5 h-5" />
            <span>Driver</span>
          </button>
          <button
            type="button"
            onClick={() => setActivePortal('support')}
            className={`relative flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium ${
              activePortal === 'support' ? 'text-emerald-700 font-semibold' : 'text-neutral-500'
            }`}
          >
            {activePortal === 'support' && (
              <span className="absolute top-0 w-8 h-0.5 rounded-full bg-emerald-600" />
            )}
            <Headphones className="w-5 h-5" />
            <span>Support</span>
          </button>
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="relative flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium text-neutral-500"
          >
            <Menu className="w-5 h-5" />
            <span>Menu</span>
          </button>
        </nav>
      )}
    </div>
  );
}

