import React, { useEffect, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import { CheckCircle2, Headphones, MessageSquareWarning, PhoneCall } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import { clampText, FIELD_LIMITS } from '../lib/validation';
import type { ComplaintRecord, LanguageCode } from '../types/smartride';
import { AuthGateCard } from './AuthGateCard';

interface CustomerSupportViewProps {
  user: User | null;
  language: LanguageCode;
  reporterRole: 'customer' | 'driver';
}

export function CustomerSupportView({
  user,
  language,
  reporterRole,
}: CustomerSupportViewProps) {
  const t = TRANSLATIONS[language];
  const [complaints, setComplaints] = useState<ComplaintRecord[]>([]);
  const [rideId, setRideId] = useState('');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    if (!user) {
      setComplaints([]);
      return;
    }

    const q = query(collection(db, 'complaints'), where('reporter_id', '==', user.uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as ComplaintRecord);
        list.sort((a, b) => (b.created_at?.toMillis?.() ?? 0) - (a.created_at?.toMillis?.() ?? 0));
        setComplaints(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'complaints')
    );

    return () => unsub();
  }, [user]);

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const cleanSubj = clampText(subject, FIELD_LIMITS.SUBJECT_MAX);
    const cleanDesc = clampText(description, FIELD_LIMITS.DESCRIPTION_MAX);
    if (cleanSubj.length < 3 || cleanDesc.length < 5) {
      setFeedback({
        type: 'err',
        text: 'Please provide a clear subject (min 3 chars) and description (min 5 chars).',
      });
      return;
    }

    setSubmitting(true);
    setFeedback(null);
    const complaintId = `cmp_${user.uid.slice(0, 8)}_${Date.now()}`;
    try {
      await setDoc(doc(db, 'complaints', complaintId), {
        complaint_id: complaintId,
        ride_id: clampText(rideId, FIELD_LIMITS.UID_MAX),
        reporter_id: user.uid,
        reporter_role: reporterRole,
        reporter_name: clampText(
          user.displayName || user.email || user.phoneNumber || 'Smart Ride User',
          FIELD_LIMITS.NAME_MAX
        ),
        subject: cleanSubj,
        description: cleanDesc,
        status: 'open',
        admin_notes: '',
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      });
      setRideId('');
      setSubject('');
      setDescription('');
      setFeedback({
        type: 'ok',
        text:
          language === 'as'
            ? 'আপোনাৰ সহায়তা টিকট এডমিনলৈ পঠিওৱা হৈছে।'
            : language === 'bn'
              ? 'আপনার সাপোর্ট টিকিট অ্যাডমিনের কাছে পাঠানো হয়েছে।'
              : 'Your support ticket has been sent to Smart Ride Admin.',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `complaints/${complaintId}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-neutral-900">{t.menuSupport}</h1>
              <p className="text-xs text-neutral-500">
                {language === 'as'
                  ? 'যাত্ৰা, ভাড়া বা চালক সংক্ৰান্তীয় যিকোনো সহায়তাৰ বাবে যোগাযোগ কৰক।'
                  : language === 'bn'
                    ? 'রাইড, ভাড়া বা একাউন্ট সংক্রান্ত যেকোনো সহায়তার জন্য টিকিট জমা দিন।'
                    : 'Get help with rides, fares, payments, or account verification.'}
              </p>
            </div>
          </div>

          <a
            href="tel:112"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-neutral-300 text-xs font-semibold text-neutral-800 hover:bg-neutral-50 shrink-0"
          >
            <PhoneCall className="w-3.5 h-3.5 text-emerald-700" />
            <span>Emergency Helpline · 112</span>
          </a>
        </div>
      </div>

      {!user ? (
        <AuthGateCard portalLabel={t.menuSupport} language={language} allowPhoneOtp />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handleSubmitTicket}
            className="lg:col-span-6 bg-white border border-neutral-200 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-sm font-semibold text-neutral-900 flex items-center gap-2">
              <MessageSquareWarning className="w-4 h-4 text-emerald-700" />
              <span>{t.submitComplaint}</span>
            </h2>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">Ride ID (Optional)</span>
              <input
                type="text"
                value={rideId}
                onChange={(e) => setRideId(e.target.value)}
                placeholder="ride_..."
                className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">Subject</span>
              <input
                type="text"
                required
                minLength={3}
                maxLength={120}
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder={
                  language === 'as'
                    ? 'উদাহৰণ: ভাড়া বা পেমেণ্ট সমস্যা'
                    : language === 'bn'
                      ? 'উদাহরণ: ভাড়া বা পেমেন্ট সমস্যা'
                      : 'e.g. Fare mismatch or lost item'
                }
                className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">Description</span>
              <textarea
                rows={4}
                required
                minLength={5}
                maxLength={600}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your issue clearly..."
                className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            {feedback && (
              <div
                className={`p-3 rounded-xl text-xs border flex items-center gap-2 ${
                  feedback.type === 'ok'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-red-50 border-red-200 text-red-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{feedback.text}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-semibold rounded-xl transition-colors"
            >
              {submitting ? 'Submitting...' : t.submitComplaint}
            </button>
          </form>

          <div className="lg:col-span-6 bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
            <h2 className="text-sm font-semibold text-neutral-900">Your Support Tickets</h2>
            {complaints.length === 0 ? (
              <p className="text-xs text-neutral-500">
                No support tickets submitted yet.
              </p>
            ) : (
              <div className="divide-y divide-neutral-100">
                {complaints.map((c) => (
                  <div key={c.complaint_id} className="py-3 space-y-1 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-neutral-900">{c.subject}</span>
                      <span
                        className={`font-mono capitalize font-semibold ${
                          c.status === 'resolved'
                            ? 'text-emerald-700'
                            : c.status === 'dismissed'
                              ? 'text-neutral-500'
                              : 'text-amber-700'
                        }`}
                      >
                        {c.status}
                      </span>
                    </div>
                    <p className="text-neutral-600">{c.description}</p>
                    {c.admin_notes && (
                      <p className="text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg px-2.5 py-1.5 mt-1">
                        Admin Reply: {c.admin_notes}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
