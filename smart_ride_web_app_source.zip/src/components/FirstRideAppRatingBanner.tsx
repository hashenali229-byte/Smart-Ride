import React, { useState } from 'react';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { CheckCircle2, Sparkles, Star, X } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import { clampText, FIELD_LIMITS } from '../lib/validation';
import type { LanguageCode } from '../types/smartride';

interface FirstRideAppRatingBannerProps {
  userId: string;
  userName: string;
  userRole: 'customer' | 'driver';
  firstCompletedRideId: string;
  language: LanguageCode;
  onDismiss: () => void;
  onSubmitted?: () => void;
}

export function FirstRideAppRatingBanner({
  userId,
  userName,
  userRole,
  firstCompletedRideId,
  language,
  onDismiss,
  onSubmitted,
}: FirstRideAppRatingBannerProps) {
  const t = TRANSLATIONS[language];
  const [score, setScore] = useState(5);
  const [feedback, setFeedback] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId || !firstCompletedRideId) return;
    setSubmitting(true);
    try {
      await setDoc(doc(db, 'app_ratings', userId), {
        rating_id: userId,
        user_id: userId,
        user_role: userRole,
        user_name: clampText(userName || 'Smart Ride User', FIELD_LIMITS.NAME_MAX),
        ride_id: firstCompletedRideId,
        score,
        feedback: clampText(
          feedback || 'Great first Smart Ride experience!',
          FIELD_LIMITS.FEEDBACK_MAX
        ),
        created_at: serverTimestamp(),
      });
      setSubmitted(true);
      onSubmitted?.();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `app_ratings/${userId}`);
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-xs text-emerald-900 font-medium">
          <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
          <span>
            {language === 'as'
              ? 'ধন্যবাদ! আপোনাৰ Smart Ride এপ ৰেটিং সংৰক্ষিত হৈছে।'
              : language === 'bn'
                ? 'ধন্যবাদ! আপনার Smart Ride অ্যাপ রেটিং সংরক্ষিত হয়েছে।'
                : 'Thank you! Your Smart Ride app rating has been saved.'}
          </span>
        </div>
        <button
          type="button"
          onClick={onDismiss}
          className="text-xs font-semibold text-emerald-800 hover:underline shrink-0"
        >
          Close
        </button>
      </div>
    );
  }

  return (
    <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-50 via-white to-amber-50/70 border-2 border-emerald-300 shadow-sm space-y-3.5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-neutral-900">{t.firstRideRateTitle}</h3>
            <p className="text-xs text-neutral-600 mt-0.5 leading-relaxed">
              {t.firstRideRateBody}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss app rating prompt"
          className="p-1.5 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-white/70"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="flex items-center gap-1.5">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => setScore(star)}
              aria-label={`Rate app ${star} stars`}
              className="p-1 rounded-lg hover:bg-amber-100/60 transition-colors"
            >
              <Star
                className={`w-7 h-7 ${
                  star <= score ? 'text-amber-500 fill-amber-500' : 'text-neutral-300'
                }`}
              />
            </button>
          ))}
          <span className="ml-2 text-xs font-mono font-semibold text-neutral-800">{score}/5</span>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            maxLength={500}
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            placeholder={
              language === 'as'
                ? 'এপটোৰ বিষয়ে আপোনাৰ মতামত লিখক (ঐচ্ছিক)...'
                : language === 'bn'
                  ? 'অ্যাপ সম্পর্কে আপনার মতামত লিখুন (ঐচ্ছিক)...'
                  : 'Tell us what you loved or how we can improve (optional)...'
            }
            className="flex-1 px-3.5 py-2.5 border border-neutral-300 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
          />
          <button
            type="submit"
            disabled={submitting}
            className="min-h-[42px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0"
          >
            {submitting ? 'Submitting...' : t.submitAppRating}
          </button>
        </div>
      </form>
    </div>
  );
}
