import React, { useEffect, useState } from 'react';
import type { User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import {
  CheckCircle2,
  Download,
  Printer,
  QrCode,
  Tag,
  Truck,
} from 'lucide-react';
import {
  downloadBlob,
  generateQrDataUrl,
  renderVehicleStickerBlob,
  type StickerTemplateId,
} from '../lib/driverAssets';
import { db } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import { formatDriverAppRegNo, normalizeVehicleNumber } from '../lib/validation';
import type {
  DriverProfile,
  FareSettingsRecord,
  LanguageCode,
} from '../types/smartride';

interface VehicleStickerViewProps {
  user: User | null;
  language: LanguageCode;
  onOpenDriverPortal: () => void;
}

const SHARED_APP_BOOKING_URL =
  'https://ais-pre-bnrocrxy5liys76vg45q27-401772992201.asia-northeast1.run.app';

export function VehicleStickerView({
  user,
  language,
  onOpenDriverPortal,
}: VehicleStickerViewProps) {
  const t = TRANSLATIONS[language];
  const [driver, setDriver] = useState<DriverProfile | null>(null);
  const [fareSettings, setFareSettings] = useState<FareSettingsRecord | null>(null);
  const [template, setTemplate] = useState<StickerTemplateId>('windshield');
  const [standArea, setStandArea] = useState('');
  const [customVehicleNo, setCustomVehicleNo] = useState('');
  const [customDriverName, setCustomDriverName] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [downloading, setDownloading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [exportedStickerUrl, setExportedStickerUrl] = useState<string | null>(null);
  const [exportedStickerBlob, setExportedStickerBlob] = useState<Blob | null>(null);

  useEffect(() => {
    const unsubFare = onSnapshot(
      doc(db, 'fare_settings', 'default'),
      (snap) => {
        setFareSettings(snap.exists() ? (snap.data() as FareSettingsRecord) : null);
      },
      () => {
        // Non-blocking fallback to default fare rates
      }
    );

    if (!user) {
      setDriver(null);
      return () => unsubFare();
    }

    const unsubDriver = onSnapshot(
      doc(db, 'drivers', user.uid),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data() as DriverProfile;
          setDriver(d);
          setCustomVehicleNo(d.vehicle_number);
          setCustomDriverName(d.full_name);
          if (d.address && !standArea) {
            setStandArea(d.address.split(',')[0] || '');
          }
        } else {
          setDriver(null);
        }
      },
      () => {
        setDriver(null);
      }
    );

    return () => {
      unsubFare();
      unsubDriver();
    };
  }, [user]);

  const effectiveAppRegNo = driver
    ? driver.app_registration_number || formatDriverAppRegNo(driver.uid)
    : user
      ? formatDriverAppRegNo(user.uid)
      : 'SR-DRV-PARTNER1';
  const effectiveVehicleNo =
    normalizeVehicleNumber(customVehicleNo || driver?.vehicle_number || '') || 'AS 01 ER 2048';
  const effectiveDriverName =
    (customDriverName || driver?.full_name || user?.displayName || 'Smart Ride Driver').trim();
  const baseFare = fareSettings?.base_fare ?? 10;
  const perKmFare = fareSettings?.price_per_km ?? 12;
  const minFare = fareSettings?.minimum_fare ?? 20;

  const bookingUrl = `${SHARED_APP_BOOKING_URL}/?driver=${encodeURIComponent(effectiveAppRegNo)}`;

  useEffect(() => {
    void generateQrDataUrl(bookingUrl, 320).then(setQrDataUrl).catch(() => setQrDataUrl(''));
  }, [bookingUrl]);

  const handleDownloadSticker = async () => {
    setDownloading(true);
    setFeedback(null);
    try {
      const blob = await renderVehicleStickerBlob({
        template,
        appRegNo: effectiveAppRegNo,
        vehicleNumber: effectiveVehicleNo,
        driverName: effectiveDriverName,
        standArea: standArea.trim(),
        bookingUrl,
        baseFare,
        perKmFare,
        minFare,
      });
      const safeVeh = effectiveVehicleNo.replace(/[^A-Z0-9]/gi, '') || 'RICKSHAW';
      const filename = `SmartRide_${template}_Sticker_${safeVeh}.png`;
      if (exportedStickerUrl) URL.revokeObjectURL(exportedStickerUrl);
      const previewUrl = URL.createObjectURL(blob);
      setExportedStickerUrl(previewUrl);
      setExportedStickerBlob(blob);
      downloadBlob(blob, filename);
      setFeedback(
        language === 'bn'
          ? 'স্টিকার PNG ফাইল তৈরি হয়েছে! ডাউনলোড না হলে নিচের ছবিটি চেপে ধরে Save করুন বা Share বাটনে চাপুন।'
          : 'High-resolution Vehicle Sticker PNG generated! Print at any shop or long-press the preview below to save.'
      );
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Sticker generation failed.');
    } finally {
      setDownloading(false);
    }
  };

  const handleShareSticker = async () => {
    if (!exportedStickerBlob) return;
    const safeVeh = effectiveVehicleNo.replace(/[^A-Z0-9]/gi, '') || 'RICKSHAW';
    const file = new File([exportedStickerBlob], `SmartRide_${template}_Sticker_${safeVeh}.png`, {
      type: 'image/png',
    });
    if (navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] }))) {
      try {
        await navigator.share({ files: [file], title: 'Smart Ride Vehicle Sticker' });
      } catch {
        // User cancelled share sheet
      }
    } else {
      downloadBlob(exportedStickerBlob, `SmartRide_${template}_Sticker_${safeVeh}.png`);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium text-emerald-700">
            {t.brandName} · E-Rickshaw Branding & Passenger QR
          </p>
          <h1 className="text-2xl font-bold text-neutral-900 tracking-tight">
            {t.menuAppSticker}
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            {language === 'bn'
              ? 'গাড়ির সামনে, পাশে বা ভেতরে লাগানোর জন্য প্রিন্ট-রেডি Smart Ride অ্যাপ স্টিকার ডাউনলোড করুন।'
              : 'Download print-ready Smart Ride stickers with scannable booking QR code to stick on your Electric Rickshaw.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={downloading}
            onClick={() => void handleDownloadSticker()}
            className="min-h-[44px] px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>
              {downloading
                ? 'Creating PNG...'
                : language === 'bn'
                  ? 'স্টিকার ডাউনলোড করুন (PNG)'
                  : 'Download Sticker (PNG)'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="min-h-[44px] px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-2 print:hidden"
          >
            <Printer className="w-4 h-4" />
            <span>{language === 'bn' ? 'প্রিন্ট' : 'Print'}</span>
          </button>
        </div>
      </div>

      {!driver && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <p className="text-xs text-amber-950">
            {language === 'bn'
              ? 'ড্রাইভার রেজিস্ট্রেশন সম্পূর্ণ করলে আপনার আসল গাড়ির নম্বর ও অ্যাপ রেজিস্ট্রেশন নম্বর অটোমেটিক স্টিকারে বসে যাবে।'
              : 'Complete Driver Registration to automatically lock your verified Vehicle & App Registration Number onto stickers.'}
          </p>
          <button
            type="button"
            onClick={onOpenDriverPortal}
            className="px-3.5 py-2 bg-neutral-900 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-1.5 shrink-0"
          >
            <Truck className="w-3.5 h-3.5" />
            <span>{t.signUpDriverBtn}</span>
          </button>
        </div>
      )}

      {feedback && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {exportedStickerUrl && (
        <div className="bg-white border border-emerald-200 rounded-2xl p-4 space-y-3 print:hidden">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs font-semibold text-emerald-900">
              {language === 'bn'
                ? 'ডাউনলোডযোগ্য স্টিকার ছবি (ফোনে সেভ করতে চেপে ধরুন)'
                : 'Ready-to-Print Sticker PNG (Long-press image on mobile to save)'}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => void handleShareSticker()}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg"
              >
                {language === 'bn' ? 'সেভ / শেয়ার করুন' : 'Save / Share Image'}
              </button>
              <button
                type="button"
                onClick={() => setExportedStickerUrl(null)}
                className="px-2.5 py-1.5 border border-neutral-300 text-neutral-600 text-xs rounded-lg"
              >
                Hide
              </button>
            </div>
          </div>
          <img
            src={exportedStickerUrl}
            alt="Exported Vehicle Sticker"
            className="w-full max-w-xl mx-auto rounded-xl border border-neutral-200"
          />
        </div>
      )}

      {/* Template Selector + Quick Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        <div className="lg:col-span-4 bg-white border border-neutral-200 rounded-2xl p-5 space-y-4 print:hidden">
          <div className="space-y-2">
            <p className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
              <Tag className="w-4 h-4 text-emerald-700" />
              <span>
                {language === 'bn' ? 'স্টিকারের সাইজ ও ধরন বাছুন' : 'Choose Sticker Placement'}
              </span>
            </p>
            <div className="space-y-2">
              {(
                [
                  {
                    id: 'windshield',
                    title:
                      language === 'bn'
                        ? '১. সামনের কাঁচ / ছাদ ব্যানার'
                        : '1. Front Windshield / Canopy Banner',
                    desc: '1600×620px · Wide front glass strip',
                  },
                  {
                    id: 'side_panel',
                    title:
                      language === 'bn'
                        ? '২. গাড়ির পেছনে / পাশের বড় স্টিকার'
                        : '2. Back / Side Body Square Decal',
                    desc: '1200×1200px · Big QR & Vehicle Plate',
                  },
                  {
                    id: 'cabin_fare',
                    title:
                      language === 'bn'
                        ? '৩. যাত্রী সিটের পেছনের ভাড়া ও QR কার্ড'
                        : '3. Passenger Cabin QR & Fare Card',
                    desc: '960×1280px · Driver Info & Live INR Fare',
                  },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTemplate(item.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-colors ${
                    template === item.id
                      ? 'bg-emerald-50 border-emerald-600 text-emerald-950'
                      : 'bg-neutral-50 border-neutral-200 text-neutral-800 hover:bg-neutral-100'
                  }`}
                >
                  <p className="text-xs font-bold">{item.title}</p>
                  <p className="text-[11px] text-neutral-500 mt-0.5">{item.desc}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3 pt-3 border-t border-neutral-100">
            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.vehicleRegNumber}</span>
              <input
                type="text"
                value={customVehicleNo}
                readOnly={Boolean(driver)}
                onChange={(e) => setCustomVehicleNo(normalizeVehicleNumber(e.target.value))}
                placeholder="AS 01 ER 2048"
                className={`mt-1 w-full px-3 py-2 border border-neutral-300 rounded-xl text-xs font-mono uppercase ${
                  driver ? 'bg-neutral-100 text-neutral-700' : 'bg-white'
                }`}
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">
                {language === 'bn' ? 'স্ট্যান্ড / এলাকার নাম (ঐচ্ছিক)' : 'Stand / Route Area (Optional)'}
              </span>
              <input
                type="text"
                maxLength={50}
                value={standArea}
                onChange={(e) => setStandArea(e.target.value)}
                placeholder="e.g. Station Road / Silchar"
                className="mt-1 w-full px-3 py-2 border border-neutral-300 rounded-xl text-xs bg-white"
              />
            </label>
          </div>
        </div>

        {/* Live Sticker Preview */}
        <div className="lg:col-span-8 bg-white border border-neutral-200 rounded-2xl p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span className="font-semibold text-neutral-800 flex items-center gap-1.5">
              <QrCode className="w-4 h-4 text-emerald-700" />
              <span>{language === 'bn' ? 'লাইভ স্টিকার প্রিভিউ' : 'Live Print Preview'}</span>
            </span>
            <span className="font-mono text-emerald-700">{effectiveAppRegNo}</span>
          </div>

          {template === 'windshield' && (
            <div className="rounded-2xl bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-800 p-5 sm:p-6 text-white border-4 border-emerald-400 space-y-4">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <img
                    src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
                    alt="Smart Ride"
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-2xl object-cover border border-emerald-300/40 shrink-0"
                  />
                  <div>
                    <p className="text-[11px] font-mono text-emerald-200">
                      VERIFIED ELECTRIC RICKSHAW · INDIA
                    </p>
                    <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                      SMART RIDE
                    </h2>
                    <p className="text-xs text-emerald-100">
                      Scan QR Code to Book Ride · Safe & Regulated ₹ Fare
                    </p>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-2.5 text-center shrink-0">
                  {qrDataUrl && (
                    <img src={qrDataUrl} alt="Book QR" className="w-24 h-24 object-contain mx-auto" />
                  )}
                  <p className="text-[10px] font-bold text-emerald-900 mt-1">SCAN TO BOOK</p>
                </div>
              </div>

              <div className="bg-white text-neutral-900 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-[10px] font-semibold text-neutral-500">VEHICLE REG. NO.</p>
                  <p className="text-lg font-extrabold font-mono">{effectiveVehicleNo}</p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-neutral-500">APP REG. NO.</p>
                  <p className="text-sm font-bold font-mono text-emerald-800">
                    {effectiveAppRegNo}
                  </p>
                </div>
                <div className="text-xs font-semibold text-neutral-700">
                  {effectiveDriverName}
                  {standArea ? ` · ${standArea}` : ''}
                </div>
              </div>
            </div>
          )}

          {template === 'side_panel' && (
            <div className="max-w-md mx-auto rounded-3xl bg-white border-4 border-emerald-700 overflow-hidden shadow-sm">
              <div className="bg-emerald-950 text-white p-5 flex items-center gap-3.5">
                <img
                  src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
                  alt="Smart Ride"
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-xl object-cover"
                />
                <div>
                  <h2 className="text-2xl font-extrabold tracking-tight">SMART RIDE</h2>
                  <p className="text-xs text-emerald-200">Book Verified Electric Rickshaw</p>
                </div>
              </div>

              <div className="p-6 flex flex-col items-center text-center space-y-3 bg-neutral-50">
                <div className="bg-white p-3 rounded-2xl border border-neutral-200">
                  {qrDataUrl && (
                    <img src={qrDataUrl} alt="Book QR" className="w-44 h-44 object-contain" />
                  )}
                </div>
                <p className="text-xs font-bold text-emerald-800 tracking-wide">
                  SCAN QR WITH PHONE CAMERA TO BOOK
                </p>
              </div>

              <div className="bg-neutral-900 text-white p-4 text-center space-y-1">
                <p className="text-[10px] text-emerald-300 font-semibold">
                  VEHICLE REGISTRATION NUMBER
                </p>
                <p className="text-2xl font-extrabold font-mono">{effectiveVehicleNo}</p>
                <p className="text-xs font-mono text-neutral-300">
                  {effectiveAppRegNo} · {effectiveDriverName}
                </p>
              </div>
            </div>
          )}

          {template === 'cabin_fare' && (
            <div className="max-w-md mx-auto rounded-3xl bg-white border-2 border-neutral-900 overflow-hidden space-y-4 p-5">
              <div className="bg-emerald-700 text-white rounded-2xl p-4 flex items-center gap-3">
                <img
                  src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
                  alt="Smart Ride"
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-xl object-cover"
                />
                <div>
                  <h2 className="text-xl font-bold">SMART RIDE</h2>
                  <p className="text-[11px] text-emerald-100">
                    Passenger Cabin · Driver & Fare Card
                  </p>
                </div>
              </div>

              <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-4 space-y-2 text-xs">
                <div>
                  <p className="text-[10px] text-neutral-500 font-semibold">VERIFIED DRIVER</p>
                  <p className="text-base font-bold text-neutral-900">{effectiveDriverName}</p>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <p className="text-[10px] text-neutral-500 font-semibold">VEHICLE NO.</p>
                    <p className="font-mono font-bold text-neutral-900">{effectiveVehicleNo}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-neutral-500 font-semibold">APP REG. NO.</p>
                    <p className="font-mono font-bold text-emerald-700">{effectiveAppRegNo}</p>
                  </div>
                </div>
                {standArea && (
                  <p className="text-neutral-600 pt-1">Route / Stand: {standArea}</p>
                )}
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 text-center">
                <p className="text-[10px] font-bold text-emerald-800">
                  OFFICIAL REGULATED INR FARE
                </p>
                <p className="text-sm font-bold font-mono text-neutral-900 mt-1">
                  Base ₹{baseFare} · Per Km ₹{perKmFare} · Min ₹{minFare}
                </p>
              </div>

              <div className="flex flex-col items-center text-center pt-1">
                {qrDataUrl && (
                  <img src={qrDataUrl} alt="Cabin QR" className="w-36 h-36 object-contain" />
                )}
                <p className="text-xs font-bold text-neutral-900 mt-1">
                  SCAN TO BOOK OR RATE RIDE
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
