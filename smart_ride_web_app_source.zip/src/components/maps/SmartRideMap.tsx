import React, { useEffect, useRef, useState } from 'react';
import {
  AdvancedMarker,
  Map as GoogleMap,
  Pin,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import { AlertTriangle, MapPin, Navigation } from 'lucide-react';
import {
  DEFAULT_INDIA_CENTER,
  GMP_ATTRIBUTION_IDS,
  SMART_RIDE_MAP_ID,
  triggerMapsQuotaExceededIfMatched,
} from '../../lib/maps';
import type { DriverLocationRecord } from '../../types/smartride';

export interface LatLngPoint {
  lat: number;
  lng: number;
  label?: string;
}

export interface ComputedRouteResult {
  distanceKm: number;
  durationMinutes: number;
}

interface RouteOverlayProps {
  origin: LatLngPoint;
  destination: LatLngPoint;
  strokeColor?: string;
  onRouteComputed?: (result: ComputedRouteResult) => void;
  onRouteError?: (message: string) => void;
}

function RouteOverlay({
  origin,
  destination,
  strokeColor = '#16a34a',
  onRouteComputed,
  onRouteError,
}: RouteOverlayProps) {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);
  const onComputedRef = useRef(onRouteComputed);
  const onErrorRef = useRef(onRouteError);

  onComputedRef.current = onRouteComputed;
  onErrorRef.current = onRouteError;

  useEffect(() => {
    if (!routesLib || !map) return;

    polylinesRef.current.forEach((p) => p.setMap(null));
    polylinesRef.current = [];

    let cancelled = false;

    const request = {
      origin: { lat: origin.lat, lng: origin.lng },
      destination: { lat: destination.lat, lng: destination.lng },
      travelMode: 'DRIVING',
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    };

    const routeClass = routesLib.Route as unknown as {
      computeRoutes: (req: unknown) => Promise<{
        routes?: Array<{
          distanceMeters?: number;
          durationMillis?: number;
          viewport?: google.maps.LatLngBounds;
          createPolylines: () => google.maps.Polyline[];
        }>;
      }>;
    };

    routeClass
      .computeRoutes(request)
      .then((response) => {
        if (cancelled) return;
        const primaryRoute = response?.routes?.[0];
        if (!primaryRoute) {
          onErrorRef.current?.('No driving route found between these points.');
          return;
        }

        const newPolylines = primaryRoute.createPolylines();
        newPolylines.forEach((polyline) => {
          polyline.setOptions({
            strokeColor,
            strokeOpacity: 0.92,
            strokeWeight: 5,
          });
          polyline.setMap(map);
        });
        polylinesRef.current = newPolylines;

        if (primaryRoute.viewport) {
          map.fitBounds(primaryRoute.viewport, 48);
        }

        const distanceMeters = primaryRoute.distanceMeters ?? 0;
        const durationMillis = primaryRoute.durationMillis ?? 0;
        const distanceKm = Number((distanceMeters / 1000).toFixed(2));
        const durationMinutes = Math.max(1, Math.round(durationMillis / 60000));

        onComputedRef.current?.({ distanceKm, durationMinutes });
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        triggerMapsQuotaExceededIfMatched(err);
        onErrorRef.current?.(
          err instanceof Error ? err.message : 'Unable to compute route via Google Routes API.'
        );
      });

    return () => {
      cancelled = true;
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, [routesLib, map, origin.lat, origin.lng, destination.lat, destination.lng, strokeColor]);

  return null;
}

function MapViewportSync({ center }: { center?: LatLngPoint | null }) {
  const map = useMap();
  useEffect(() => {
    if (!map || !center) return;
    map.panTo({ lat: center.lat, lng: center.lng });
  }, [map, center?.lat, center?.lng]);
  return null;
}

interface SmartRideMapProps {
  apiKeyAvailable: boolean;
  center?: LatLngPoint | null;
  pickup?: LatLngPoint | null;
  destination?: LatLngPoint | null;
  assignedDriver?: LatLngPoint | null;
  onlineDrivers?: DriverLocationRecord[];
  routeOrigin?: LatLngPoint | null;
  routeDestination?: LatLngPoint | null;
  routeStrokeColor?: string;
  heightClassName?: string;
  onMapClick?: (coords: { lat: number; lng: number }) => void;
  onRouteComputed?: (result: ComputedRouteResult) => void;
  onRouteError?: (message: string) => void;
}

export function SmartRideMap({
  apiKeyAvailable,
  center,
  pickup,
  destination,
  assignedDriver,
  onlineDrivers = [],
  routeOrigin,
  routeDestination,
  routeStrokeColor = '#16a34a',
  heightClassName = 'h-[340px] sm:h-[420px]',
  onMapClick,
  onRouteComputed,
  onRouteError,
}: SmartRideMapProps) {
  const [activeHint, setActiveHint] = useState<string | null>(null);

  if (!apiKeyAvailable) {
    return (
      <div
        className={`${heightClassName} w-full rounded-2xl border border-neutral-200 bg-neutral-100 flex flex-col items-center justify-center p-6 text-center space-y-2`}
      >
        <AlertTriangle className="w-6 h-6 text-amber-600" />
        <p className="text-sm font-semibold text-neutral-900">Google Maps API Key Pending</p>
        <p className="text-xs text-neutral-600 max-w-md leading-relaxed">
          Configure <span className="font-mono">VITE_GOOGLE_MAPS_API_KEY</span> or restart the preview server after Maps provisioning so the interactive India map, Places search, and Routes API load.
        </p>
      </div>
    );
  }

  const effectiveCenter = center || pickup || assignedDriver || DEFAULT_INDIA_CENTER;

  return (
    <div className={`relative ${heightClassName} w-full rounded-2xl overflow-hidden border border-neutral-200 bg-neutral-100`}>
      <GoogleMap
        mapId={SMART_RIDE_MAP_ID}
        defaultCenter={effectiveCenter}
        defaultZoom={14}
        gestureHandling="greedy"
        streetViewControl={false}
        mapTypeControl={false}
        fullscreenControl
        internalUsageAttributionIds={GMP_ATTRIBUTION_IDS}
        onClick={(ev) => {
          const latLng = ev.detail?.latLng;
          if (latLng && onMapClick) {
            onMapClick({
              lat: Number(latLng.lat.toFixed(6)),
              lng: Number(latLng.lng.toFixed(6)),
            });
          }
        }}
        className="w-full h-full"
      >
        <MapViewportSync center={center} />
        {pickup && (
          <AdvancedMarker
            position={{ lat: pickup.lat, lng: pickup.lng }}
            title={pickup.label || 'Pickup Location'}
            onClick={() => setActiveHint(pickup.label || 'Pickup Point')}
          >
            <Pin
              background="#16a34a"
              borderColor="#14532d"
              glyphColor="#ffffff"
              glyphText="P"
            />
          </AdvancedMarker>
        )}

        {destination && (
          <AdvancedMarker
            position={{ lat: destination.lat, lng: destination.lng }}
            title={destination.label || 'Destination'}
            onClick={() => setActiveHint(destination.label || 'Destination')}
          >
            <Pin
              background="#171717"
              borderColor="#000000"
              glyphColor="#ffffff"
              glyphText="D"
            />
          </AdvancedMarker>
        )}

        {onlineDrivers
          .filter((d) => d.is_online && d.lat !== 0 && d.lng !== 0)
          .map((drv) => (
            <AdvancedMarker
              key={drv.driver_id}
              position={{ lat: drv.lat, lng: drv.lng }}
              title={`Online E-Rickshaw (${drv.driver_id.slice(0, 6)})`}
              onClick={() => setActiveHint('Available Electric Rickshaw nearby')}
            >
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white border-2 border-white shadow-md flex items-center justify-center">
                <Navigation className="w-4 h-4" />
              </div>
            </AdvancedMarker>
          ))}

        {assignedDriver && assignedDriver.lat !== 0 && assignedDriver.lng !== 0 && (
          <AdvancedMarker
            position={{ lat: assignedDriver.lat, lng: assignedDriver.lng }}
            title={assignedDriver.label || 'Your Electric Rickshaw'}
            onClick={() => setActiveHint(assignedDriver.label || 'Assigned Driver Live GPS')}
          >
            <div className="px-2.5 py-1 rounded-full bg-neutral-900 text-white border-2 border-emerald-400 shadow-lg flex items-center gap-1.5 text-[11px] font-semibold whitespace-nowrap">
              <Navigation className="w-3.5 h-3.5 text-emerald-400" />
              <span>{assignedDriver.label || 'Driver'}</span>
            </div>
          </AdvancedMarker>
        )}

        {routeOrigin && routeDestination && (
          <RouteOverlay
            origin={routeOrigin}
            destination={routeDestination}
            strokeColor={routeStrokeColor}
            onRouteComputed={onRouteComputed}
            onRouteError={onRouteError}
          />
        )}
      </GoogleMap>

      {activeHint && (
        <button
          type="button"
          onClick={() => setActiveHint(null)}
          className="absolute bottom-3 left-3 z-10 bg-white/95 backdrop-blur-sm border border-neutral-200 px-3 py-1.5 rounded-lg shadow-sm text-xs font-medium text-neutral-900 flex items-center gap-1.5"
        >
          <MapPin className="w-3.5 h-3.5 text-emerald-600" />
          <span>{activeHint}</span>
        </button>
      )}
    </div>
  );
}
