import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useMapsLibrary } from '@vis.gl/react-google-maps';
import { Loader2, MapPin, X } from 'lucide-react';
import { useAutocompleteSuggestions } from '../../hooks/useAutocompleteSuggestions';
import { triggerMapsQuotaExceededIfMatched } from '../../lib/maps';

export interface SelectedPlaceResult {
  address: string;
  lat: number;
  lng: number;
}

interface PlaceSearchInputProps {
  value: string;
  onChange: (value: string) => void;
  onPlaceSelect: (place: SelectedPlaceResult) => void;
  placeholder: string;
  icon?: React.ReactNode;
  disabled?: boolean;
  mapsEnabled: boolean;
}

function PlacesAutocompleteField({
  value,
  onChange,
  onPlaceSelect,
  placeholder,
  icon,
  disabled = false,
}: Omit<PlaceSearchInputProps, 'mapsEnabled'>) {
  const placesLib = useMapsLibrary('places');
  const [focused, setFocused] = useState(false);
  const [fetchingPlace, setFetchingPlace] = useState(false);
  const [suppressSearch, setSuppressSearch] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const queryInput = !suppressSearch ? value : '';
  const { suggestions, isLoading, error, resetSession } = useAutocompleteSuggestions(queryInput, {
    includedRegionCodes: ['in'],
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectSuggestion = useCallback(
    async (suggestion: google.maps.places.AutocompleteSuggestion) => {
      if (!placesLib || !suggestion.placePrediction) return;
      setFetchingPlace(true);
      try {
        const place = suggestion.placePrediction.toPlace();
        await place.fetchFields({
          fields: ['displayName', 'formattedAddress', 'location', 'viewport'],
        });
        const loc = place.location;
        if (!loc) {
          setFetchingPlace(false);
          return;
        }
        const lat = typeof loc.lat === 'function' ? loc.lat() : Number(loc.lat);
        const lng = typeof loc.lng === 'function' ? loc.lng() : Number(loc.lng);
        const address =
          place.formattedAddress ||
          place.displayName ||
          suggestion.placePrediction.text.text;

        setSuppressSearch(true);
        setFocused(false);
        onChange(address);
        onPlaceSelect({ address, lat, lng });
        resetSession();
      } catch (err) {
        triggerMapsQuotaExceededIfMatched(err);
      } finally {
        setFetchingPlace(false);
      }
    },
    [placesLib, onChange, onPlaceSelect, resetSession]
  );

  const showDropdown = focused && suggestions.length > 0 && !suppressSearch;

  return (
    <div ref={containerRef} className="relative flex-1">
      <div className="flex items-center gap-2.5 px-3.5 py-2.5 border border-neutral-300 rounded-xl bg-white focus-within:ring-2 focus-within:ring-emerald-600 focus-within:border-emerald-600">
        {icon || <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />}
        <input
          type="text"
          disabled={disabled}
          value={value}
          onFocus={() => setFocused(true)}
          onChange={(e) => {
            setSuppressSearch(false);
            setFocused(true);
            onChange(e.target.value);
          }}
          placeholder={placeholder}
          className="w-full text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none bg-transparent disabled:opacity-60"
        />
        {(isLoading || fetchingPlace) && (
          <Loader2 className="w-4 h-4 text-emerald-600 animate-spin shrink-0" />
        )}
        {value && !disabled && !isLoading && !fetchingPlace && (
          <button
            type="button"
            onClick={() => {
              setSuppressSearch(false);
              onChange('');
              resetSession();
            }}
            aria-label="Clear search"
            className="text-neutral-400 hover:text-neutral-700 p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {showDropdown && (
        <ul className="absolute z-30 left-0 right-0 mt-1.5 bg-white border border-neutral-200 rounded-xl shadow-lg max-h-60 overflow-y-auto divide-y divide-neutral-100">
          {suggestions.map((suggestion, idx) => {
            const label = suggestion.placePrediction?.text?.text || '';
            if (!label) return null;
            return (
              <li key={`${label}-${idx}`}>
                <button
                  type="button"
                  onClick={() => void handleSelectSuggestion(suggestion)}
                  className="w-full text-left px-3.5 py-2.5 text-xs sm:text-sm text-neutral-800 hover:bg-emerald-50 flex items-start gap-2.5 transition-colors"
                >
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {error && focused && (
        <p className="text-[11px] text-amber-700 mt-1 px-1">
          Autocomplete limited ({error}). You can still use GPS or tap the map.
        </p>
      )}
    </div>
  );
}

export function PlaceSearchInput(props: PlaceSearchInputProps) {
  if (!props.mapsEnabled) {
    return (
      <div className="flex-1 flex items-center gap-2.5 px-3.5 py-2.5 border border-neutral-300 rounded-xl bg-white focus-within:ring-2 focus-within:ring-emerald-600">
        {props.icon || <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />}
        <input
          type="text"
          disabled={props.disabled}
          value={props.value}
          onChange={(e) => props.onChange(e.target.value)}
          placeholder={props.placeholder}
          className="w-full text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none bg-transparent disabled:opacity-60"
        />
      </div>
    );
  }

  return <PlacesAutocompleteField {...props} />;
}
