import React, { useEffect, useState } from 'react';
import type { User } from 'firebase/auth';
import { doc, onSnapshot, serverTimestamp, updateDoc } from 'firebase/firestore';
import {
  BadgeCheck,
  CheckCircle2,
  Download,
  Edit3,
  IdCard,
  MapPin,
  Printer,
  ShieldCheck,
  Truck,
} from 'lucide-react';
import {
  downloadBlob,
  generateQrDataUrl,
  renderDriverIdCardBlob,
} from '../lib/driverAssets';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import { clampText, FIELD_LIMITS, formatDriverAppRegNo, validateDateOfBirth } from '../lib/validation';
import type {
  DriverDocumentRecord,
  DriverProfile,
  GenderOption,
  LanguageCode,
} from '../types/smartride';

interface DriverIdCardViewProps {
  user: User | null;
  language: LanguageCode;
  onOpenDriverPortal: () => void;
}

export function DriverIdCardView({
  user,
  language,
  onOpenDriverPortal,
}: DriverIdCardViewProps) {
  const t = TRANSLATIONS[language];
  const [driver, setDriver] = useState<DriverProfile | null>(null);
  const [docsRecord, setDocsRecord] = useState<DriverDocumentRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [qrUrl, setQrUrl] = useState<string>('');
  const [downloading, setDownloading] = useState(false);
  const [exportedCardUrl, setExportedCardUrl] = useState<string | null>(null);
  const [exportedCardBlob, setExportedCardBlob] = useState<Blob | null>(null);

  // Quick edit for Address / Gender / DOB
  const [editing, setEditing] = useState(false);
  const [addressInput, setAddressInput] = useState('');
  const [genderInput, setGenderInput] = useState<GenderOption>('male');
  const [dobInput, setDobInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    if (!user) {
      setDriver(null);
      setDocsRecord(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsubDriver = onSnapshot(
      doc(db, 'drivers', user.uid),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data() as DriverProfile;
          setDriver(d);
          setAddressInput(d.address || '');
          if (d.gender) setGenderInput(d.gender);
          if (d.date_of_birth) setDobInput(d.date_of_birth);
        } else {
          setDriver(null);
        }
        setLoading(false);
      },
      (err) => {
        setLoading(false);
        handleFirestoreError(err, OperationType.GET, `drivers/${user.uid}`);
      }
    );

    const unsubDocs = onSnapshot(
      doc(db, 'driver_documents', user.uid),
      (snap) => {
        setDocsRecord(snap.exists() ? (snap.data() as DriverDocumentRecord) : null);
      },
      (err) => handleFirestoreError(err, OperationType.GET, `driver_documents/${user.uid}`)
    );

    return () => {
      unsubDriver();
      unsubDocs();
    };
  }, [user]);

  const appRegNo = driver
    ? driver.app_registration_number || formatDriverAppRegNo(driver.uid)
    : '';
  const licenseNumber = docsRecord?.driving_license_number || 'Pending KYC';

  useEffect(() => {
    if (!driver) return;
    const verifyPayload = `${window.location.origin}/?verifyDriver=${encodeURIComponent(
      appRegNo
    )}&veh=${encodeURIComponent(driver.vehicle_number)}`;
    void generateQrDataUrl(verifyPayload, 220).then(setQrUrl).catch(() => setQrUrl(''));
  }, [driver, appRegNo]);

  const genderLabel =
    driver?.gender === 'female'
      ? t.genderFemale
      : driver?.gender === 'other'
        ? t.genderOther
        : driver?.gender === 'male'
          ? t.genderMale
          : '—';

  const handleSaveDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !driver) return;
    setFeedback(null);

    const cleanAddress = clampText(addressInput, FIELD_LIMITS.ADDRESS_MAX);
    if (cleanAddress.length < 4) {
      setFeedback({
        type: 'err',
        text:
          language === 'bn'
            ? 'অনুগ্রহ করে কমপক্ষে ৪ অক্ষরের পূর্ণ ঠিকানা লিখুন।'
            : 'Please enter a complete address (min 4 characters).',
      });
      return;
    }

    if (dobInput) {
      const dobCheck = validateDateOfBirth(dobInput, 18);
      if (!dobCheck.valid) {
        setFeedback({ type: 'err', text: dobCheck.message });
        return;
      }
    }

    setSaving(true);
    try {
      await updateDoc(doc(db, 'drivers', user.uid), {
        address: cleanAddress,
        gender: genderInput,
        date_of_birth: dobInput.trim(),
        updated_at: serverTimestamp(),
      });
      setEditing(false);
      setFeedback({
        type: 'ok',
        text:
          language === 'bn'
            ? 'ড্রাইভার আইডি কার্ডের ঠিকানা ও তথ্য সফলভাবে সেভ হয়েছে।'
            : 'Driver ID Card address and details saved.',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `drivers/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDownloadIdCard = async () => {
    if (!driver) return;
    setDownloading(true);
    setFeedback(null);
    try {
      const blob = await renderDriverIdCardBlob({
        appRegNo,
        vehicleNumber: driver.vehicle_number,
        licenseNumber,
        driverName: driver.full_name,
        genderLabel,
        dateOfBirth: driver.date_of_birth || '—',
        address: driver.address || '',
        phoneNumber: driver.phone_number,
        approvalStatus: driver.approval_status,
        photoUrl: driver.profile_image,
        qrTargetUrl: `${window.location.origin}/?verifyDriver=${encodeURIComponent(
          appRegNo
        )}&veh=${encodeURIComponent(driver.vehicle_number)}`,
      });
      const safeVeh = driver.vehicle_number.replace(/[^A-Z0-9]/gi, '') || 'DRIVER';
      const filename = `SmartRide_Driver_ID_${safeVeh}.png`;
      if (exportedCardUrl) URL.revokeObjectURL(exportedCardUrl);
      const previewUrl = URL.createObjectURL(blob);
      setExportedCardUrl(previewUrl);
      setExportedCardBlob(blob);
      downloadBlob(blob, filename);
      setFeedback({
        type: 'ok',
        text:
          language === 'bn'
            ? 'ড্রাইভার আইডি কার্ড (PNG) ডাউনলোড শুরু হয়েছে! ডাউনলোড না হলে নিচের ছবিটি চেপে ধরে Save করুন বা Share বাটনে চাপুন।'
            : 'Driver ID Card PNG generated & download started! If blocked on mobile, long-press or share the saved preview below.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to generate ID Card image.',
      });
    } finally {
      setDownloading(false);
    }
  };

  const handleShareIdCard = async () => {
    if (!exportedCardBlob || !driver) return;
    const safeVeh = driver.vehicle_number.replace(/[^A-Z0-9]/gi, '') || 'DRIVER';
    const file = new File([exportedCardBlob], `SmartRide_Driver_ID_${safeVeh}.png`, {
      type: 'image/png',
    });
    if (navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] }))) {
      try {
        await navigator.share({
          files: [file],
          title: `Smart Ride Driver ID (${driver.full_name})`,
        });
      } catch {
        // User cancelled share sheet
      }
    } else if (exportedCardUrl) {
      downloadBlob(exportedCardBlob, `SmartRide_Driver_ID_${safeVeh}.png`);
    }
  };

  if (!user || (!loading && !driver)) {
    return (
      <div className="max-w-xl mx-auto bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 text-center space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto">
          <IdCard className="w-7 h-7 text-emerald-700" />
        </div>
        <div className="space-y-1.5">
          <h2 className="text-lg font-bold text-neutral-900">{t.menuDriverIdCard}</h2>
          <p className="text-xs text-neutral-600 leading-relaxed">
            {language === 'bn'
              ? 'ড্রাইভার আইডি কার্ড পাওয়ার জন্য অনুগ্রহ করে ড্রাইভার অ্যাকাউন্ট দিয়ে সাইন ইন এবং রেজিস্ট্রেশন সম্পন্ন করুন।'
              : 'Sign in and complete your Electric Rickshaw Driver registration to generate your official Smart Ride Driver ID Card.'}
          </p>
        </div>
        <button
          type="button"
          onClick={onOpenDriverPortal}
          className="min-h-[44px] px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-2 transition-colors"
        >
          <Truck className="w-4 h-4" />
          <span>{t.signUpDriverBtn}</span>
        </button>
      </div>
    );
  }

  if (loading || !driver) {
    return (
      <div className="max-w-3xl mx-auto bg-white border border-neutral-200 rounded-2xl p-8 space-y-4">
        <div className="h-6 w-48 bg-neutral-200 rounded animate-pulse" />
        <div className="h-64 w-full bg-neutral-100 rounded-xl animate-pulse" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium text-emerald-700">
            {t.brandName} · {t.driverTitle}
          </p>
          <h1 className="text-2xl font-bold text-neutral-900 tracking-tight">
            {t.menuDriverIdCard}
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            {language === 'bn'
              ? 'অফিসিয়াল স্মার্ট রাইড ড্রাইভার পরিচয়পত্র — ডাউনলোড বা প্রিন্ট করুন।'
              : 'Official Smart Ride Electric Rickshaw partner identity card with App & Vehicle registration details.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setEditing((prev) => !prev)}
            className="min-h-[44px] px-4 py-2 border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-800 text-xs font-semibold rounded-xl inline-flex items-center gap-1.5"
          >
            <Edit3 className="w-4 h-4 text-emerald-700" />
            <span>{editing ? 'Close Edit' : language === 'bn' ? 'ঠিকানা / তথ্য আপডেট' : 'Update Address'}</span>
          </button>

          <button
            type="button"
            disabled={downloading}
            onClick={() => void handleDownloadIdCard()}
            className="min-h-[44px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>
              {downloading
                ? 'Generating...'
                : language === 'bn'
                  ? 'আইডি কার্ড ডাউনলোড (PNG)'
                  : 'Download ID Card (PNG)'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="min-h-[44px] px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-1.5 print:hidden"
          >
            <Printer className="w-4 h-4" />
            <span>{language === 'bn' ? 'প্রিন্ট' : 'Print'}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3 rounded-xl text-xs border flex items-center gap-2 ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {exportedCardUrl && (
        <div className="bg-white border border-emerald-200 rounded-2xl p-4 space-y-3 print:hidden">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs font-semibold text-emerald-900">
              {language === 'bn'
                ? 'ডাউনলোডযোগ্য আইডি কার্ড ছবি (ফোনে সেভ করতে ছবিতে চেপে ধরুন)'
                : 'Ready-to-Save ID Card PNG (Long-press image on mobile to save)'}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => void handleShareIdCard()}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg"
              >
                {language === 'bn' ? 'সেভ / শেয়ার করুন' : 'Save / Share Image'}
              </button>
              <button
                type="button"
                onClick={() => setExportedCardUrl(null)}
                className="px-2.5 py-1.5 border border-neutral-300 text-neutral-600 text-xs rounded-lg"
              >
                Hide
              </button>
            </div>
          </div>
          <img
            src={exportedCardUrl}
            alt="Exported Driver ID Card"
            className="w-full max-w-xl mx-auto rounded-xl border border-neutral-200"
          />
        </div>
      )}

      {editing && (
        <form
          onSubmit={handleSaveDetails}
          className="bg-white border border-neutral-200 rounded-2xl p-5 space-y-4 print:hidden"
        >
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
            <h2 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-700" />
              <span>
                {language === 'bn'
                  ? 'আইডি কার্ডের ঠিকানা ও তথ্য আপডেট করুন'
                  : 'Update Address & Personal Details on ID Card'}
              </span>
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="block sm:col-span-2">
              <span className="text-xs font-medium text-neutral-700">{t.driverAddressLabel}</span>
              <textarea
                rows={2}
                required
                minLength={4}
                maxLength={300}
                value={addressInput}
                onChange={(e) => setAddressInput(e.target.value)}
                placeholder="Village / Ward, Post Office, District, PIN Code"
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.genderLabel}</span>
              <select
                value={genderInput}
                onChange={(e) => setGenderInput(e.target.value as GenderOption)}
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <option value="male">{t.genderMale}</option>
                <option value="female">{t.genderFemale}</option>
                <option value="other">{t.genderOther}</option>
              </select>
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.dobLabel}</span>
              <input
                type="date"
                min="1920-01-01"
                max={new Date().toISOString().split('T')[0]}
                value={dobInput}
                onChange={(e) => setDobInput(e.target.value)}
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="submit"
              disabled={saving}
              className="min-h-[42px] px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl"
            >
              {saving ? 'Saving...' : t.saveProfile}
            </button>
          </div>
        </form>
      )}

      {/* Official Driver ID Card Surface */}
      <div className="bg-white border-2 border-neutral-200 rounded-3xl overflow-hidden shadow-sm">
        {/* Card Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-800 px-5 sm:px-7 py-5 text-white flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <img
              src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
              alt="Smart Ride"
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-xl object-cover border border-emerald-300/40"
            />
            <div>
              <p className="text-base sm:text-lg font-bold tracking-tight">
                SMART RIDE ELECTRIC RICKSHAW
              </p>
              <p className="text-xs text-emerald-200 font-medium">
                Official Driver Identity Card · India
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-mono font-semibold text-emerald-100">
            {driver.approval_status === 'approved' ? (
              <BadgeCheck className="w-4 h-4 text-emerald-300" />
            ) : (
              <ShieldCheck className="w-4 h-4 text-amber-300" />
            )}
            <span>
              {driver.approval_status === 'approved'
                ? 'VERIFIED PARTNER'
                : driver.approval_status === 'rejected'
                  ? 'REJECTED'
                  : 'PENDING VERIFICATION'}
            </span>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-5 sm:p-7 grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
          {/* Left Column: Portrait + QR */}
          <div className="md:col-span-4 flex flex-row md:flex-col items-center md:items-stretch gap-4">
            <div className="w-28 sm:w-36 md:w-full aspect-[4/4.4] rounded-2xl overflow-hidden border-2 border-emerald-600 bg-neutral-100 shrink-0">
              <img
                src={
                  driver.profile_image ||
                  '/src/assets/images/driver_avatar_sample_1795224014527.jpg'
                }
                alt={driver.full_name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex-1 md:flex-none bg-neutral-50 border border-neutral-200 rounded-2xl p-3 flex flex-col items-center justify-center text-center gap-1.5">
              {qrUrl ? (
                <img
                  src={qrUrl}
                  alt="Driver verification QR"
                  className="w-24 h-24 sm:w-28 sm:h-28 object-contain rounded-lg bg-white p-1"
                />
              ) : (
                <div className="w-24 h-24 bg-neutral-200 rounded-lg animate-pulse" />
              )}
              <span className="text-[11px] font-mono font-semibold text-neutral-700">
                {appRegNo}
              </span>
            </div>
          </div>

          {/* Right Column: Required Identity Details */}
          <div className="md:col-span-8 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4">
              <div>
                <p className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wide">
                  {t.appRegNumberLabel}
                </p>
                <p className="text-lg font-bold font-mono tabular-nums text-emerald-950 mt-0.5">
                  {appRegNo}
                </p>
              </div>
              <div>
                <p className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wide">
                  {t.vehicleRegNumber}
                </p>
                <p className="text-lg font-bold font-mono tabular-nums text-neutral-900 mt-0.5">
                  {driver.vehicle_number}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div className="pb-3 border-b border-neutral-100">
                <p className="text-xs text-neutral-500">Driver Name</p>
                <p className="text-base font-bold text-neutral-900 mt-0.5">{driver.full_name}</p>
              </div>
              <div className="pb-3 border-b border-neutral-100">
                <p className="text-xs text-neutral-500">{t.drivingLicenseNo}</p>
                <p className="text-sm font-bold font-mono tabular-nums text-neutral-900 mt-1">
                  {licenseNumber}
                </p>
              </div>
              <div className="pb-3 border-b border-neutral-100">
                <p className="text-xs text-neutral-500">{t.genderLabel}</p>
                <p className="text-sm font-semibold text-neutral-900 mt-0.5">{genderLabel}</p>
              </div>
              <div className="pb-3 border-b border-neutral-100">
                <p className="text-xs text-neutral-500">{t.dobLabel}</p>
                <p className="text-sm font-semibold font-mono tabular-nums text-neutral-900 mt-0.5">
                  {driver.date_of_birth || '—'}
                </p>
              </div>
            </div>

            <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-4 space-y-1">
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs font-medium text-neutral-500">{t.driverAddressLabel}</p>
                {!driver.address && (
                  <button
                    type="button"
                    onClick={() => setEditing(true)}
                    className="text-xs font-semibold text-emerald-700 hover:underline print:hidden"
                  >
                    + Add Address
                  </button>
                )}
              </div>
              <p className="text-sm font-medium text-neutral-900 leading-relaxed">
                {driver.address ||
                  (language === 'bn'
                    ? 'ঠিকানা যোগ করা হয়নি — উপরের "ঠিকানা / তথ্য আপডেট" বাটনে ট্যাপ করে ঠিকানা লিখুন।'
                    : 'Not added yet — tap "Update Address" above to add your full address.')}
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-neutral-900 text-neutral-200 px-5 sm:px-7 py-3 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span>Smart Ride Electric Rickshaw · Partner Verification ID</span>
          <span className="font-mono text-emerald-300">{driver.phone_number}</span>
        </div>
      </div>
    </div>
  );
}
