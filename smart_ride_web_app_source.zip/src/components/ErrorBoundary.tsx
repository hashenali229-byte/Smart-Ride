import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  State
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      message: error?.message || 'An unexpected error occurred.',
    };
  }

  render() {
    if (this.state.hasError) {
      let parsed: { error?: string; operationType?: string; path?: string } | null = null;
      try {
        parsed = JSON.parse(this.state.message);
      } catch {
        parsed = null;
      }

      return (
        <div className="min-h-[320px] flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-red-700">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h2 className="text-base font-semibold text-neutral-900">
                Data Access Notice
              </h2>
            </div>
            <p className="text-sm text-neutral-600 leading-relaxed">
              {parsed?.error
                ? `${parsed.error} (${parsed.operationType || 'read'} on ${parsed.path || 'database'})`
                : this.state.message}
            </p>
            <button
              type="button"
              onClick={() => this.setState({ hasError: false, message: '' })}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-neutral-900 rounded-lg hover:bg-neutral-800 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              Retry View
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
