import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import {
  AlertCircle,
  BadgeCheck,
  Banknote,
  Bell,
  CheckCircle2,
  Clock,
  CreditCard,
  ExternalLink,
  Flag,
  IndianRupee,
  MapPin,
  MessageSquareWarning,
  Navigation,
  Phone,
  Play,
  Power,
  ShieldAlert,
  ShieldCheck,
  Star,
  Upload,
  XCircle,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType, storage } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import {
  buildUpiPaymentLink,
  calculateSmartRideFare,
  clampText,
  type DrivingLicenceCheckResult,
  FIELD_LIMITS,
  formatDriverAppRegNo,
  formatIndianPhone,
  isValidIndianPhone,
  isValidVehicleNumber,
  normalizeVehicleNumber,
  sanitizeImageUrl,
  validateDateOfBirth,
  type VehicleCheckResult,
  verifyIndianDrivingLicence,
  verifyIndianVehicleNumber,
} from '../lib/validation';
import type {
  ComplaintRecord,
  DriverDocumentRecord,
  DriverProfile,
  FareSettingsRecord,
  GenderOption,
  LanguageCode,
  NotificationRecord,
  PortalSection,
  RatingRecord,
  RideRecord,
  UpiPaymentApp,
  VehicleRecord,
} from '../types/smartride';
import { AuthGateCard } from './AuthGateCard';
import { FirstRideAppRatingBanner } from './FirstRideAppRatingBanner';
import { SmartRideMap, type LatLngPoint } from './maps/SmartRideMap';

interface DriverPortalProps {
  user: User | null;
  language: LanguageCode;
  mapsEnabled: boolean;
  activeSection: PortalSection;
  onSectionChange: (section: PortalSection) => void;
  onOpenIdCard?: () => void;
  onOpenSticker?: () => void;
}

export function DriverPortal({
  user,
  language,
  mapsEnabled,
  activeSection,
  onSectionChange,
  onOpenIdCard,
  onOpenSticker,
}: DriverPortalProps) {
  const t = TRANSLATIONS[language];
  const [driver, setDriver] = useState<DriverProfile | null>(null);
  const [vehicle, setVehicle] = useState<VehicleRecord | null>(null);
  const [docsRecord, setDocsRecord] = useState<DriverDocumentRecord | null>(null);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [fareSettings, setFareSettings] = useState<FareSettingsRecord | null>(null);
  const [myRides, setMyRides] = useState<RideRecord[]>([]);
  const [openRequests, setOpenRequests] = useState<RideRecord[]>([]);
  const [myRatings, setMyRatings] = useState<RatingRecord[]>([]);
  const [myComplaints, setMyComplaints] = useState<ComplaintRecord[]>([]);
  const [dismissedIds, setDismissedIds] = useState<Record<string, boolean>>({});
  const [hasAppRating, setHasAppRating] = useState(false);
  const [appRatingLoaded, setAppRatingLoaded] = useState(false);
  const [appRatingDismissed, setAppRatingDismissed] = useState(false);
  const [loading, setLoading] = useState(false);

  // Live GPS coordinates for driver broadcast
  const [currentGps, setCurrentGps] = useState<LatLngPoint | null>(null);
  const [gpsWatchError, setGpsWatchError] = useState<string | null>(null);
  const lastBroadcastMsRef = useRef<number>(0);

  // Registration form fields
  const [fullName, setFullName] = useState('');
  const [phoneDigits, setPhoneDigits] = useState('');
  const [gender, setGender] = useState<GenderOption>('male');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [address, setAddress] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [manufacturer, setManufacturer] = useState('Mahindra Treo');
  const [modelYear, setModelYear] = useState(2025);
  const [batteryCapacity, setBatteryCapacity] = useState('48V 100Ah Lithium');
  const [dlNumber, setDlNumber] = useState('');
  const [rcNumber, setRcNumber] = useState('');
  const [profilePhotoUrl, setProfilePhotoUrl] = useState(
    '/src/assets/images/driver_avatar_sample_1795224014527.jpg'
  );
  const [dlFileUrl, setDlFileUrl] = useState('');
  const [rcFileUrl, setRcFileUrl] = useState('');
  const [insuranceUrl, setInsuranceUrl] = useState('');

  // Vehicle real/fake check, DL valid/invalid check & Registration Fee state
  const [vehicleCheck, setVehicleCheck] = useState<VehicleCheckResult | null>(null);
  const [dlExpiryDate, setDlExpiryDate] = useState('');
  const [dlCheck, setDlCheck] = useState<DrivingLicenceCheckResult | null>(null);
  const [regFeeApp, setRegFeeApp] = useState<UpiPaymentApp>('phonepe');
  const [regFeeRef, setRegFeeRef] = useState('');
  const [regFeePaid, setRegFeePaid] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);

  const [uploadingField, setUploadingField] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [togglingOnline, setTogglingOnline] = useState(false);
  const [rideBusy, setRideBusy] = useState<string | null>(null);
  const [waitingMinsInput, setWaitingMinsInput] = useState(0);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Driver Complaint state
  const [showComplaintForm, setShowComplaintForm] = useState(false);
  const [complaintSubject, setComplaintSubject] = useState('');
  const [complaintDesc, setComplaintDesc] = useState('');

  useEffect(() => {
    if (!user) {
      setDriver(null);
      setVehicle(null);
      setDocsRecord(null);
      setNotifications([]);
      setMyRides([]);
      setOpenRequests([]);
      setMyRatings([]);
      setMyComplaints([]);
      setHasAppRating(false);
      setAppRatingLoaded(false);
      return;
    }

    try {
      setAppRatingDismissed(
        window.localStorage.getItem(`smart_ride_apprate_dismissed_${user.uid}`) === '1'
      );
    } catch {
      setAppRatingDismissed(false);
    }

    setLoading(true);
    setFullName(user.displayName || '');
    if (user.phoneNumber) {
      setPhoneDigits(user.phoneNumber.replace(/^\+91/, ''));
    }

    const unsubDriver = onSnapshot(
      doc(db, 'drivers', user.uid),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data() as DriverProfile;
          setDriver(d);
          setFullName(d.full_name);
          setPhoneDigits(d.phone_number.replace(/^\+91/, ''));
          setVehicleNumber(d.vehicle_number);
          if (d.gender) setGender(d.gender);
          if (d.date_of_birth) setDateOfBirth(d.date_of_birth);
          if (d.address) setAddress(d.address);
          if (d.profile_image) setProfilePhotoUrl(d.profile_image);
        } else {
          setDriver(null);
        }
        setLoading(false);
      },
      (err) => {
        setLoading(false);
        handleFirestoreError(err, OperationType.GET, `drivers/${user.uid}`);
      }
    );

    const unsubVehicle = onSnapshot(
      doc(db, 'vehicles', user.uid),
      (snap) => {
        if (snap.exists()) {
          const v = snap.data() as VehicleRecord;
          setVehicle(v);
          setManufacturer(v.manufacturer);
          setModelYear(v.model_year);
          setBatteryCapacity(v.battery_capacity);
          setRcNumber(v.rc_number);
        } else {
          setVehicle(null);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `vehicles/${user.uid}`)
    );

    const unsubDocs = onSnapshot(
      doc(db, 'driver_documents', user.uid),
      (snap) => {
        if (snap.exists()) {
          const docData = snap.data() as DriverDocumentRecord;
          setDocsRecord(docData);
          setDlNumber(docData.driving_license_number);
          setRcNumber(docData.rc_number);
          setDlFileUrl(docData.driving_license_url);
          setRcFileUrl(docData.vehicle_rc_url);
          setInsuranceUrl(docData.insurance_url);
        } else {
          setDocsRecord(null);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `driver_documents/${user.uid}`)
    );

    const unsubFare = onSnapshot(
      doc(db, 'fare_settings', 'default'),
      (snap) => {
        setFareSettings(snap.exists() ? (snap.data() as FareSettingsRecord) : null);
      },
      (err) => handleFirestoreError(err, OperationType.GET, 'fare_settings/default')
    );

    const notifQ = query(collection(db, 'notifications'), where('recipient_id', '==', user.uid));
    const unsubNotif = onSnapshot(
      notifQ,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as NotificationRecord);
        list.sort((a, b) => (b.created_at?.toMillis?.() ?? 0) - (a.created_at?.toMillis?.() ?? 0));
        setNotifications(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'notifications')
    );

    const myRidesQ = query(collection(db, 'rides'), where('driver_id', '==', user.uid));
    const unsubMyRides = onSnapshot(
      myRidesQ,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as RideRecord);
        list.sort((a, b) => (b.created_at?.toMillis?.() ?? 0) - (a.created_at?.toMillis?.() ?? 0));
        setMyRides(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'rides')
    );

    const ratingsQ = query(collection(db, 'ratings'), where('driver_id', '==', user.uid));
    const unsubRatings = onSnapshot(
      ratingsQ,
      (snap) => setMyRatings(snap.docs.map((d) => d.data() as RatingRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'ratings')
    );

    const complaintsQ = query(collection(db, 'complaints'), where('reporter_id', '==', user.uid));
    const unsubComplaints = onSnapshot(
      complaintsQ,
      (snap) => setMyComplaints(snap.docs.map((d) => d.data() as ComplaintRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'complaints')
    );

    const unsubAppRating = onSnapshot(
      doc(db, 'app_ratings', user.uid),
      (snap) => {
        setHasAppRating(snap.exists());
        setAppRatingLoaded(true);
      },
      () => {
        setAppRatingLoaded(true);
      }
    );

    return () => {
      unsubDriver();
      unsubVehicle();
      unsubDocs();
      unsubFare();
      unsubNotif();
      unsubMyRides();
      unsubRatings();
      unsubComplaints();
      unsubAppRating();
    };
  }, [user]);

  // Listen to open ride requests ONLY when approved and online
  useEffect(() => {
    if (!user || !driver || driver.approval_status !== 'approved' || !driver.is_online) {
      setOpenRequests([]);
      return;
    }

    const reqQuery = query(collection(db, 'rides'), where('ride_status', '==', 'requested'));
    const unsubReq = onSnapshot(
      reqQuery,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as RideRecord);
        list.sort((a, b) => (b.created_at?.toMillis?.() ?? 0) - (a.created_at?.toMillis?.() ?? 0));
        setOpenRequests(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'rides')
    );

    return () => unsubReq();
  }, [user, driver?.approval_status, driver?.is_online]);

  // Live GPS location watch ONLY while approved + online
  useEffect(() => {
    if (!user || !driver || driver.approval_status !== 'approved' || !driver.is_online) {
      return;
    }
    if (!('geolocation' in navigator)) {
      setGpsWatchError('Geolocation is not supported by this browser.');
      return;
    }

    setGpsWatchError(null);
    const watchId = navigator.geolocation.watchPosition(
      async (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(6));
        const lng = Number(pos.coords.longitude.toFixed(6));
        const heading = pos.coords.heading && !Number.isNaN(pos.coords.heading) ? pos.coords.heading : 0;
        setCurrentGps({ lat, lng, label: `${driver.vehicle_number}` });

        const now = Date.now();
        if (now - lastBroadcastMsRef.current < 5000) return;
        lastBroadcastMsRef.current = now;

        try {
          await setDoc(doc(db, 'driver_locations', user.uid), {
            driver_id: user.uid,
            lat,
            lng,
            heading: Math.min(360, Math.max(0, heading)),
            is_online: true,
            updated_at: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `driver_locations/${user.uid}`);
        }
      },
      (err) => {
        setGpsWatchError(`GPS permission required for live tracking: ${err.message}`);
      },
      { enableHighAccuracy: true, maximumAge: 4000, timeout: 15000 }
    );

    return () => {
      navigator.geolocation.clearWatch(watchId);
    };
  }, [user, driver?.approval_status, driver?.is_online, driver?.vehicle_number]);

  const activeRide = useMemo(() => {
    return (
      myRides.find((r) => ['accepted', 'arrived', 'in_progress'].includes(r.ride_status)) || null
    );
  }, [myRides]);

  const uncollectedCashRide = useMemo(() => {
    return (
      myRides.find(
        (r) => r.ride_status === 'completed' && r.payment_status === 'pending'
      ) || null
    );
  }, [myRides]);

  const completedRidesList = useMemo(
    () => myRides.filter((r) => r.ride_status === 'completed'),
    [myRides]
  );

  const firstCompletedRide = useMemo(() => {
    return completedRidesList.length > 0
      ? completedRidesList[completedRidesList.length - 1]
      : null;
  }, [completedRidesList]);

  useEffect(() => {
    if (!user || !firstCompletedRide || !appRatingLoaded || hasAppRating) return;
    const localNotifKey = `smart_ride_apprate_notif_d_${user.uid}`;
    try {
      if (window.localStorage.getItem(localNotifKey) === '1') return;
    } catch {
      // Ignore storage restrictions
    }

    const notifId = `notif_apprate_d_${user.uid}`;
    const notifRef = doc(db, 'notifications', notifId);
    void getDoc(notifRef)
      .then(async (snap) => {
        if (!snap.exists()) {
          await setDoc(notifRef, {
            notification_id: notifId,
            recipient_id: user.uid,
            title: t.firstRideRateTitle,
            body: t.firstRideRateBody,
            type: 'ride_update',
            is_read: false,
            created_at: serverTimestamp(),
          });
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification(t.firstRideRateTitle, { body: t.firstRideRateBody });
          }
        }
        try {
          window.localStorage.setItem(localNotifKey, '1');
        } catch {
          // Ignore storage restrictions
        }
      })
      .catch(() => {
        // Ignore non-blocking rating notification error
      });
  }, [user, firstCompletedRide, appRatingLoaded, hasAppRating, t.firstRideRateTitle, t.firstRideRateBody]);

  const liveMetrics = useMemo(() => {
    const totalEarnings = completedRidesList.reduce(
      (sum, r) => sum + (r.final_fare > 0 ? r.final_fare : r.estimated_fare),
      0
    );
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEarnings = completedRidesList
      .filter((r) => (r.created_at?.toMillis?.() ?? 0) >= todayStart.getTime())
      .reduce((sum, r) => sum + (r.final_fare > 0 ? r.final_fare : r.estimated_fare), 0);

    const avgRating =
      myRatings.length > 0
        ? myRatings.reduce((sum, item) => sum + item.score, 0) / myRatings.length
        : driver?.rating_avg ?? 5.0;

    return {
      totalEarnings: Math.max(driver?.total_earnings ?? 0, totalEarnings),
      todayEarnings,
      completedCount: Math.max(driver?.total_completed_rides ?? 0, completedRidesList.length),
      avgRating,
    };
  }, [completedRidesList, myRatings, driver]);

  const visibleRequests = useMemo(() => {
    return openRequests.filter((r) => !dismissedIds[r.ride_id]);
  }, [openRequests, dismissedIds]);

  const handleDocumentUpload = async (
    field: 'photo' | 'dl' | 'rc' | 'insurance',
    file: File | undefined
  ) => {
    if (!file || !user) return;
    setUploadingField(field);
    setFeedback(null);
    try {
      const storageRef = ref(storage, `driver_kyc/${user.uid}/${field}_${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      if (field === 'photo') setProfilePhotoUrl(url);
      if (field === 'dl') setDlFileUrl(url);
      if (field === 'rc') setRcFileUrl(url);
      if (field === 'insurance') setInsuranceUrl(url);
      setFeedback({ type: 'ok', text: `${field.toUpperCase()} uploaded to Firebase Storage.` });
    } catch (err) {
      setFeedback({
        type: 'err',
        text:
          err instanceof Error
            ? `Storage upload blocked (${err.message}). Verify Firebase Storage rules or continue.`
            : 'Upload failed.',
      });
    } finally {
      setUploadingField(null);
    }
  };

  const registrationFeeAmount = fareSettings?.driver_registration_fee ?? 199;
  const adminUpiId = fareSettings?.admin_upi_id?.trim() || 'smartride@upi';
  const businessPayeeName =
    fareSettings?.business_payee_name?.trim() || 'Smart Ride Electric Rickshaw';

  const regFeeAppLabel = (app: UpiPaymentApp): string => {
    switch (app) {
      case 'phonepe':
        return 'PhonePe';
      case 'gpay':
        return 'Google Pay (GPay)';
      case 'amazonpay':
        return 'Amazon Pay';
      case 'paytm':
        return 'Paytm';
      case 'cash':
        return 'Office Cash';
      case 'razorpay':
        return 'Razorpay';
      default:
        return 'UPI App';
    }
  };

  const handleCopyUpi = async () => {
    try {
      await navigator.clipboard.writeText(adminUpiId);
      setCopiedUpi(true);
      window.setTimeout(() => setCopiedUpi(false), 1800);
    } catch {
      // Ignore clipboard permission errors
    }
  };

  const handleCheckVehicleNumber = () => {
    const res = verifyIndianVehicleNumber(vehicleNumber);
    setVehicleNumber(res.normalized);
    setVehicleCheck(res);
  };

  const handleCheckDrivingLicence = () => {
    const res = verifyIndianDrivingLicence(dlNumber, dlExpiryDate);
    setDlNumber(res.normalized);
    setDlCheck(res);
  };

  const handlePayRegistrationFee = () => {
    setFeedback(null);
    if (registrationFeeAmount > 0 && regFeeApp !== 'cash' && regFeeRef.trim().length < 4) {
      setFeedback({
        type: 'err',
        text: `Enter your ${regFeeAppLabel(regFeeApp)} UPI UTR / Transaction Reference ID (min 4 chars) to confirm fee payment.`,
      });
      return;
    }
    setRegFeePaid(true);
    setFeedback({
      type: 'ok',
      text: `Driver registration fee of ₹${registrationFeeAmount} confirmed via ${regFeeAppLabel(regFeeApp)}.`,
    });
  };

  const handleRegisterDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setFeedback(null);

    const cleanName = clampText(fullName, FIELD_LIMITS.NAME_MAX);
    const formattedPhone = formatIndianPhone(phoneDigits);
    const dobCheck = validateDateOfBirth(dateOfBirth, 18);
    const cleanVehicleNo = normalizeVehicleNumber(vehicleNumber);
    const cleanDlNo = clampText(dlNumber, FIELD_LIMITS.DOC_NUMBER_MAX);
    const cleanRcNo = clampText(rcNumber, FIELD_LIMITS.DOC_NUMBER_MAX);
    const cleanPhoto =
      sanitizeImageUrl(profilePhotoUrl) ||
      '/src/assets/images/driver_avatar_sample_1795224014527.jpg';
    const cleanDlUrl =
      sanitizeImageUrl(dlFileUrl) || `https://storage.smartride.in/kyc/${user.uid}/dl-submitted`;
    const cleanRcUrl =
      sanitizeImageUrl(rcFileUrl) || `https://storage.smartride.in/kyc/${user.uid}/rc-submitted`;
    const cleanInsUrl =
      sanitizeImageUrl(insuranceUrl) || `https://storage.smartride.in/kyc/${user.uid}/ins-submitted`;

    if (cleanName.length < FIELD_LIMITS.NAME_MIN) {
      setFeedback({ type: 'err', text: 'Driver full name must be at least 2 characters.' });
      return;
    }
    if (!isValidIndianPhone(formattedPhone)) {
      setFeedback({ type: 'err', text: 'Enter a valid 10-digit Indian mobile number (+91).' });
      return;
    }
    const cleanAddress = clampText(address, FIELD_LIMITS.ADDRESS_MAX);
    if (!dobCheck.valid) {
      setFeedback({ type: 'err', text: `Date of Birth: ${dobCheck.message}` });
      return;
    }
    if (cleanAddress.length < 4) {
      setFeedback({ type: 'err', text: 'Enter your residential or stand address (min 4 chars).' });
      return;
    }
    if (!isValidVehicleNumber(cleanVehicleNo)) {
      setFeedback({
        type: 'err',
        text: 'Vehicle registration must be 4–20 uppercase letters/numbers (e.g. AS 01 ER 2048).',
      });
      return;
    }

    const vResult = verifyIndianVehicleNumber(cleanVehicleNo);
    setVehicleCheck(vResult);
    if (!vResult.isValidFormat) {
      setFeedback({
        type: 'err',
        text: `Vehicle Check Failed: ${vResult.message}`,
      });
      return;
    }

    if (cleanDlNo.length < 4 || cleanRcNo.length < 4) {
      setFeedback({ type: 'err', text: 'Enter valid Driving Licence and RC numbers.' });
      return;
    }

    const dlResult = verifyIndianDrivingLicence(cleanDlNo, dlExpiryDate);
    setDlCheck(dlResult);
    if (!dlResult.isValid) {
      setFeedback({
        type: 'err',
        text: `Driving Licence Check Failed: ${dlResult.message}`,
      });
      return;
    }

    if (registrationFeeAmount > 0 && !regFeePaid) {
      setFeedback({
        type: 'err',
        text: `Please complete the ₹${registrationFeeAmount} Driver Registration Fee payment before submitting.`,
      });
      return;
    }

    const storedMethod: 'upi' | 'cash' | 'razorpay' =
      regFeeApp === 'cash' ? 'cash' : regFeeApp === 'razorpay' ? 'razorpay' : 'upi';
    const cleanFeeRef = clampText(
      regFeeRef || `CASH_${user.uid.slice(0, 6).toUpperCase()}_${Date.now().toString().slice(-4)}`,
      80
    );

    setSaving(true);
    try {
      const batch = writeBatch(db);

      batch.set(doc(db, 'users', user.uid), {
        uid: user.uid,
        full_name: cleanName,
        phone_number: formattedPhone,
        email: clampText(user.email || '', FIELD_LIMITS.EMAIL_MAX),
        role: 'driver',
        profile_image: cleanPhoto,
        account_status: 'active',
        preferred_language: language,
        gender,
        date_of_birth: dateOfBirth.trim(),
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      });

      batch.set(doc(db, 'drivers', user.uid), {
        uid: user.uid,
        full_name: cleanName,
        phone_number: formattedPhone,
        profile_image: cleanPhoto,
        vehicle_number: vResult.normalized,
        vehicle_type: 'Electric Rickshaw',
        driving_license: cleanDlUrl,
        vehicle_document: cleanRcUrl,
        approval_status: 'pending',
        rejection_reason: '',
        is_online: false,
        total_completed_rides: 0,
        total_earnings: 0,
        rating_avg: 5.0,
        vehicle_check_status: vResult.status,
        vehicle_rto_state: clampText(vResult.stateName, 60),
        dl_validity_status: dlResult.status,
        registration_fee_amount: registrationFeeAmount,
        registration_fee_status: 'paid',
        registration_fee_method: storedMethod,
        registration_fee_app: regFeeApp,
        registration_fee_ref: cleanFeeRef,
        gender,
        date_of_birth: dateOfBirth.trim(),
        address: cleanAddress,
        app_registration_number: formatDriverAppRegNo(user.uid),
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      });

      batch.set(doc(db, 'vehicles', user.uid), {
        vehicle_id: user.uid,
        driver_id: user.uid,
        vehicle_number: vResult.normalized,
        vehicle_type: 'Electric Rickshaw',
        manufacturer: clampText(manufacturer, 80) || 'Electric Rickshaw',
        model_year: Number(modelYear) || 2025,
        battery_capacity: clampText(batteryCapacity, 40) || '48V 100Ah',
        rc_number: cleanRcNo,
        status: 'pending',
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      });

      batch.set(doc(db, 'driver_documents', user.uid), {
        doc_id: user.uid,
        driver_id: user.uid,
        driving_license_number: dlResult.normalized,
        driving_license_url: cleanDlUrl,
        rc_number: cleanRcNo,
        vehicle_rc_url: cleanRcUrl,
        insurance_url: cleanInsUrl,
        verification_status: 'pending',
        reviewed_by: '',
        notes: `Vehicle Check: ${vResult.status} (${vResult.stateName}) | DL Check: ${dlResult.status}${dlExpiryDate ? ` (Exp: ${dlExpiryDate})` : ''} | Fee: ₹${registrationFeeAmount} (${regFeeAppLabel(regFeeApp)} · ${cleanFeeRef})`,
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      });

      const feePaymentId = `reg_fee_${user.uid}`;
      batch.set(doc(db, 'payments', feePaymentId), {
        payment_id: feePaymentId,
        ride_id: 'registration_fee',
        customer_id: user.uid,
        driver_id: user.uid,
        amount: registrationFeeAmount,
        method: storedMethod,
        status: 'verified',
        created_at: serverTimestamp(),
      });

      await batch.commit();
      setFeedback({
        type: 'ok',
        text: 'Driver application & registration fee submitted! Status is now Pending Admin Verification.',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `drivers/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const handleToggleOnline = async () => {
    if (!user || !driver) return;
    if (driver.approval_status !== 'approved') {
      setFeedback({
        type: 'err',
        text: 'Only admin-approved drivers can go online.',
      });
      return;
    }

    const nextOnline = !driver.is_online;
    setTogglingOnline(true);
    setFeedback(null);

    try {
      await updateDoc(doc(db, 'drivers', user.uid), {
        is_online: nextOnline,
        updated_at: serverTimestamp(),
      });

      if (!nextOnline) {
        await setDoc(doc(db, 'driver_locations', user.uid), {
          driver_id: user.uid,
          lat: currentGps?.lat ?? 0,
          lng: currentGps?.lng ?? 0,
          heading: 0,
          is_online: false,
          updated_at: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `drivers/${user.uid}`);
    } finally {
      setTogglingOnline(false);
    }
  };

  const handleAcceptRide = async (ride: RideRecord) => {
    if (!user || !driver || driver.approval_status !== 'approved') return;
    if (activeRide) {
      setFeedback({ type: 'err', text: 'Complete your active ride before accepting another.' });
      return;
    }

    setRideBusy(`accept_${ride.ride_id}`);
    setFeedback(null);

    try {
      await runTransaction(db, async (tx) => {
        const rideRef = doc(db, 'rides', ride.ride_id);
        const snap = await tx.get(rideRef);
        if (!snap.exists()) {
          throw new Error('Ride no longer exists.');
        }
        const current = snap.data() as RideRecord;
        if (current.ride_status !== 'requested' || current.driver_id !== '') {
          throw new Error('This ride was already accepted by another driver.');
        }

        tx.update(rideRef, {
          driver_id: user.uid,
          driver_name: clampText(driver.full_name, FIELD_LIMITS.NAME_MAX),
          driver_phone: clampText(driver.phone_number, FIELD_LIMITS.PHONE_MAX),
          driver_vehicle_number: clampText(driver.vehicle_number, FIELD_LIMITS.VEHICLE_NUMBER_MAX),
          driver_photo: clampText(driver.profile_image, FIELD_LIMITS.URL_MAX),
          ride_status: 'accepted',
          updated_at: serverTimestamp(),
        });
      });

      const notifId = `notif_accept_${ride.ride_id}_${Date.now()}`;
      await setDoc(doc(db, 'notifications', notifId), {
        notification_id: notifId,
        recipient_id: ride.customer_id,
        title: 'Electric Rickshaw Assigned!',
        body: `${driver.full_name} (${driver.vehicle_number}) accepted your ride and is on the way.`,
        type: 'ride_update',
        is_read: false,
        created_at: serverTimestamp(),
      });

      setWaitingMinsInput(0);
      setFeedback({ type: 'ok', text: `Accepted ride ${ride.ride_id}. Navigate to pickup.` });
      onSectionChange('status');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('already accepted') || msg.includes('no longer exists')) {
        setFeedback({ type: 'err', text: msg });
      } else {
        handleFirestoreError(err, OperationType.UPDATE, `rides/${ride.ride_id}`);
      }
    } finally {
      setRideBusy(null);
    }
  };

  const handleAdvanceRide = async (
    ride: RideRecord,
    nextStatus: 'arrived' | 'in_progress' | 'completed'
  ) => {
    if (!user || !driver) return;
    setRideBusy(`step_${ride.ride_id}`);
    setFeedback(null);

    try {
      const effectiveRates = fareSettings || {
        base_fare: 10,
        price_per_km: 12,
        minimum_fare: 20,
        waiting_charge: 2,
      };

      const finalFare =
        nextStatus === 'completed'
          ? calculateSmartRideFare({
              distanceKm: ride.distance_km,
              waitingMinutes: waitingMinsInput,
              baseFare: effectiveRates.base_fare,
              pricePerKm: effectiveRates.price_per_km,
              minimumFare: effectiveRates.minimum_fare,
              waitingCharge: effectiveRates.waiting_charge,
            })
          : ride.final_fare;

      await updateDoc(doc(db, 'rides', ride.ride_id), {
        ride_status: nextStatus,
        waiting_minutes: nextStatus === 'completed' ? Math.max(0, waitingMinsInput) : ride.waiting_minutes,
        final_fare: finalFare,
        updated_at: serverTimestamp(),
      });

      const notifId = `notif_${nextStatus}_${ride.ride_id}_${Date.now()}`;
      await setDoc(doc(db, 'notifications', notifId), {
        notification_id: notifId,
        recipient_id: ride.customer_id,
        title:
          nextStatus === 'arrived'
            ? 'Driver Arrived at Pickup'
            : nextStatus === 'in_progress'
            ? 'Ride Started'
            : `Ride Completed · ₹${finalFare}`,
        body:
          nextStatus === 'completed'
            ? `Trip completed. Total fare is ₹${finalFare}. Pay via Cash or UPI.`
            : `${driver.full_name} (${driver.vehicle_number}) updated ride to ${nextStatus.replace('_', ' ')}.`,
        type: 'ride_update',
        is_read: false,
        created_at: serverTimestamp(),
      });

      setFeedback({
        type: 'ok',
        text:
          nextStatus === 'completed'
            ? `Ride completed! Final fare ₹${finalFare}.`
            : `Ride status updated to ${nextStatus.replace('_', ' ')}.`,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `rides/${ride.ride_id}`);
    } finally {
      setRideBusy(null);
    }
  };

  const handleConfirmCashCollected = async (ride: RideRecord) => {
    if (!user) return;
    setRideBusy(`cash_${ride.ride_id}`);
    const amount = ride.final_fare > 0 ? ride.final_fare : ride.estimated_fare;
    const paymentId = `pay_${ride.ride_id}`;
    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'rides', ride.ride_id), {
        payment_method: 'cash',
        payment_status: 'paid',
        updated_at: serverTimestamp(),
      });
      batch.set(doc(db, 'payments', paymentId), {
        payment_id: paymentId,
        ride_id: ride.ride_id,
        customer_id: ride.customer_id,
        driver_id: user.uid,
        amount,
        method: 'cash',
        status: 'verified',
        created_at: serverTimestamp(),
      });
      await batch.commit();
      setFeedback({ type: 'ok', text: `Confirmed ₹${amount} Cash received.` });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `payments/${paymentId}`);
    } finally {
      setRideBusy(null);
    }
  };

  const handleSubmitComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !driver) return;
    const cleanSubj = clampText(complaintSubject, FIELD_LIMITS.SUBJECT_MAX);
    const cleanDesc = clampText(complaintDesc, FIELD_LIMITS.DESCRIPTION_MAX);
    if (cleanSubj.length < 3 || cleanDesc.length < 5) return;

    setRideBusy('complaint');
    const complaintId = `cmp_${user.uid.slice(0, 6)}_${Date.now()}`;
    try {
      await setDoc(doc(db, 'complaints', complaintId), {
        complaint_id: complaintId,
        ride_id: activeRide?.ride_id || '',
        reporter_id: user.uid,
        reporter_role: 'driver',
        reporter_name: clampText(driver.full_name, FIELD_LIMITS.NAME_MAX),
        subject: cleanSubj,
        description: cleanDesc,
        status: 'open',
        admin_notes: '',
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      });
      setComplaintSubject('');
      setComplaintDesc('');
      setShowComplaintForm(false);
      setFeedback({ type: 'ok', text: 'Driver support ticket submitted to Admin.' });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `complaints/${complaintId}`);
    } finally {
      setRideBusy(null);
    }
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto py-4 space-y-5">
        <div className="text-center space-y-1">
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
            {t.welcomeHeadline}
          </h1>
          <p className="text-xs text-neutral-500">{t.roleDriverTitle}</p>
        </div>
        <AuthGateCard portalLabel={t.driverTitle} language={language} allowPhoneOtp />
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-white border border-neutral-200 rounded-2xl p-8 space-y-4">
        <div className="h-6 w-56 bg-neutral-200 rounded animate-pulse" />
        <div className="h-40 w-full bg-neutral-100 rounded-xl animate-pulse" />
      </div>
    );
  }

  if (!driver) {
    return (
      <div className="max-w-3xl mx-auto bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 space-y-6">
        <div className="pb-4 border-b border-neutral-100">
          <p className="text-xs font-medium text-emerald-700">{t.driverTitle}</p>
          <h2 className="text-xl font-bold text-neutral-900 mt-1">
            Electric Rickshaw Driver Registration & KYC
          </h2>
          <p className="text-xs text-neutral-500 mt-1">
            New driver accounts start in Pending Verification until reviewed by an Admin.
          </p>
        </div>

        <form onSubmit={handleRegisterDriver} className="space-y-6">
          <div className="flex items-center gap-4">
            <img
              src={profilePhotoUrl}
              alt="Driver portrait"
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-full object-cover border border-neutral-200"
            />
            <div>
              <label className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-neutral-700 bg-neutral-50 border border-neutral-200 rounded-lg cursor-pointer hover:bg-neutral-100">
                <Upload className="w-4 h-4" />
                <span>
                  {uploadingField === 'photo' ? 'Uploading...' : 'Upload Driver Photograph'}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleDocumentUpload('photo', e.target.files?.[0])}
                  className="hidden"
                />
              </label>
              <p className="text-xs text-neutral-500 mt-1">Clear front-facing driver portrait.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.fullName}</span>
              <input
                type="text"
                required
                minLength={2}
                maxLength={100}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Subhash Mondal"
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.phoneNumberLabel}</span>
              <div className="mt-1.5 flex items-center border border-neutral-300 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-emerald-600">
                <span className="px-3 py-2.5 bg-neutral-50 border-r border-neutral-200 text-sm font-mono text-neutral-700">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={phoneDigits}
                  onChange={(e) => setPhoneDigits(e.target.value.replace(/\D/g, ''))}
                  placeholder="9830011223"
                  className="w-full px-3 py-2.5 text-sm font-mono focus:outline-none"
                />
              </div>
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.genderLabel}</span>
              <select
                required
                value={gender}
                onChange={(e) => setGender(e.target.value as GenderOption)}
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <option value="male">{t.genderMale}</option>
                <option value="female">{t.genderFemale}</option>
                <option value="other">{t.genderOther}</option>
              </select>
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">
                {t.dobLabel} (18+ yrs)
              </span>
              <input
                type="date"
                required
                min="1920-01-01"
                max={new Date().toISOString().split('T')[0]}
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <label className="block sm:col-span-2">
              <span className="text-xs font-medium text-neutral-700">{t.driverAddressLabel}</span>
              <input
                type="text"
                required
                minLength={4}
                maxLength={300}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Village / Ward, Post Office, District, PIN"
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <div className="sm:col-span-2 space-y-2">
              <span className="text-xs font-medium text-neutral-700 block">
                {t.vehicleRegNumber} (Real / Fake RTO Check)
              </span>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  required
                  value={vehicleNumber}
                  onChange={(e) => {
                    setVehicleNumber(normalizeVehicleNumber(e.target.value));
                    setVehicleCheck(null);
                  }}
                  placeholder="AS 01 ER 2048"
                  className="flex-1 px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono uppercase focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                <button
                  type="button"
                  onClick={handleCheckVehicleNumber}
                  className="px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors inline-flex items-center justify-center gap-1.5 shrink-0"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{t.verifyVehicleBtn}</span>
                </button>
              </div>
              {vehicleCheck && (
                <div
                  className={`p-2.5 rounded-xl text-xs border flex items-center justify-between gap-2 ${
                    vehicleCheck.isValidFormat
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-red-50 border-red-200 text-red-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {vehicleCheck.isValidFormat ? (
                      <BadgeCheck className="w-4 h-4 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 shrink-0" />
                    )}
                    <span>{vehicleCheck.message}</span>
                  </div>
                  <a
                    href="https://parivahan.gov.in"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline font-semibold shrink-0"
                  >
                    Vahan
                  </a>
                </div>
              )}
            </div>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.vehicleType}</span>
              <input
                type="text"
                readOnly
                value="Electric Rickshaw"
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-200 rounded-xl text-sm bg-neutral-50 text-neutral-700"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">Manufacturer</span>
              <input
                type="text"
                value={manufacturer}
                onChange={(e) => setManufacturer(e.target.value)}
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">Battery & Model Year</span>
              <div className="mt-1.5 grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={batteryCapacity}
                  onChange={(e) => setBatteryCapacity(e.target.value)}
                  className="px-3 py-2.5 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                <input
                  type="number"
                  min={2015}
                  max={2030}
                  value={modelYear}
                  onChange={(e) => setModelYear(Number(e.target.value))}
                  className="px-3 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.rcNumber}</span>
              <input
                type="text"
                required
                value={rcNumber}
                onChange={(e) => setRcNumber(e.target.value.toUpperCase())}
                placeholder="RC-AS01-88912"
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <div className="sm:col-span-2 space-y-2">
              <span className="text-xs font-medium text-neutral-700 block">
                {t.drivingLicenseNo} (Valid / Invalid Check)
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                <input
                  type="text"
                  required
                  value={dlNumber}
                  onChange={(e) => {
                    setDlNumber(e.target.value.toUpperCase());
                    setDlCheck(null);
                  }}
                  placeholder="AS01 20210012345"
                  className="sm:col-span-5 px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                <input
                  type="date"
                  value={dlExpiryDate}
                  onChange={(e) => {
                    setDlExpiryDate(e.target.value);
                    setDlCheck(null);
                  }}
                  aria-label="Driving Licence Expiry Date"
                  className="sm:col-span-4 px-3 py-2.5 border border-neutral-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                <button
                  type="button"
                  onClick={handleCheckDrivingLicence}
                  className="sm:col-span-3 px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors inline-flex items-center justify-center gap-1.5"
                >
                  <BadgeCheck className="w-4 h-4" />
                  <span>{t.verifyDlBtn}</span>
                </button>
              </div>
              {dlCheck && (
                <div
                  className={`p-2.5 rounded-xl text-xs border flex items-center justify-between gap-2 ${
                    dlCheck.isValid
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-red-50 border-red-200 text-red-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {dlCheck.isValid ? (
                      <BadgeCheck className="w-4 h-4 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 shrink-0" />
                    )}
                    <span>{dlCheck.message}</span>
                  </div>
                  <a
                    href="https://sarathi.parivahan.gov.in"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline font-semibold shrink-0"
                  >
                    Sarathi
                  </a>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-neutral-100">
            <label className="p-3.5 border border-dashed border-neutral-300 rounded-xl cursor-pointer hover:bg-neutral-50 space-y-1.5 block">
              <div className="flex items-center justify-between text-xs font-medium text-neutral-800">
                <span>Driving Licence File</span>
                <Upload className="w-3.5 h-3.5 text-neutral-500" />
              </div>
              <p className="text-xs text-neutral-500 truncate">
                {uploadingField === 'dl' ? 'Uploading...' : dlFileUrl ? 'Uploaded' : 'Select image / PDF'}
              </p>
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => handleDocumentUpload('dl', e.target.files?.[0])}
                className="hidden"
              />
            </label>

            <label className="p-3.5 border border-dashed border-neutral-300 rounded-xl cursor-pointer hover:bg-neutral-50 space-y-1.5 block">
              <div className="flex items-center justify-between text-xs font-medium text-neutral-800">
                <span>Vehicle RC Certificate</span>
                <Upload className="w-3.5 h-3.5 text-neutral-500" />
              </div>
              <p className="text-xs text-neutral-500 truncate">
                {uploadingField === 'rc' ? 'Uploading...' : rcFileUrl ? 'Uploaded' : 'Select image / PDF'}
              </p>
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => handleDocumentUpload('rc', e.target.files?.[0])}
                className="hidden"
              />
            </label>

            <label className="p-3.5 border border-dashed border-neutral-300 rounded-xl cursor-pointer hover:bg-neutral-50 space-y-1.5 block">
              <div className="flex items-center justify-between text-xs font-medium text-neutral-800">
                <span>Insurance / Permit</span>
                <Upload className="w-3.5 h-3.5 text-neutral-500" />
              </div>
              <p className="text-xs text-neutral-500 truncate">
                {uploadingField === 'insurance'
                  ? 'Uploading...'
                  : insuranceUrl
                  ? 'Uploaded'
                  : 'Select image / PDF'}
              </p>
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => handleDocumentUpload('insurance', e.target.files?.[0])}
                className="hidden"
              />
            </label>
          </div>

          {/* Driver Registration Fee Payment Box (PhonePe, GPay, Amazon Pay, Paytm) */}
          <div className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-700" />
                <div>
                  <h3 className="text-sm font-bold text-neutral-900">{t.regFeeTitle}</h3>
                  <p className="text-[11px] text-neutral-500">
                    Pay online via PhonePe, Google Pay, Amazon Pay, or Paytm
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 font-mono font-bold text-lg text-emerald-700">
                <IndianRupee className="w-4 h-4" />
                <span>{registrationFeeAmount}</span>
              </div>
            </div>

            {registrationFeeAmount > 0 && !regFeePaid ? (
              <div className="space-y-3.5">
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {(
                    [
                      { id: 'phonepe', label: 'PhonePe', accent: 'bg-purple-700 text-white border-purple-700' },
                      { id: 'gpay', label: 'GPay', accent: 'bg-blue-600 text-white border-blue-600' },
                      { id: 'amazonpay', label: 'Amazon Pay', accent: 'bg-amber-500 text-neutral-950 border-amber-500' },
                      { id: 'paytm', label: 'Paytm', accent: 'bg-sky-600 text-white border-sky-600' },
                      { id: 'cash', label: 'Office Cash', accent: 'bg-neutral-900 text-white border-neutral-900' },
                    ] as const
                  ).map((item) => {
                    const selected = regFeeApp === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setRegFeeApp(item.id)}
                        className={`min-h-[42px] px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                          selected
                            ? item.accent
                            : 'bg-white text-neutral-800 border-neutral-300 hover:bg-neutral-100'
                        }`}
                      >
                        {item.label}
                      </button>
                    );
                  })}
                </div>

                {regFeeApp !== 'cash' && (
                  <div className="p-3.5 rounded-xl bg-white border border-neutral-200 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div>
                        <span className="text-neutral-500">Payee: </span>
                        <span className="font-semibold text-neutral-900">{businessPayeeName}</span>
                        <span className="text-neutral-400 mx-1.5">·</span>
                        <span className="font-mono text-emerald-700">{adminUpiId}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => void handleCopyUpi()}
                        className="px-2.5 py-1 rounded-lg border border-neutral-300 text-[11px] font-medium text-neutral-700 hover:bg-neutral-50"
                      >
                        {copiedUpi ? 'Copied UPI ID' : 'Copy UPI ID'}
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <a
                        href={buildUpiPaymentLink({
                          upiId: adminUpiId,
                          payeeName: businessPayeeName,
                          amount: registrationFeeAmount,
                          note: `Driver Reg Fee`,
                          app:
                            regFeeApp === 'phonepe' ||
                            regFeeApp === 'gpay' ||
                            regFeeApp === 'amazonpay' ||
                            regFeeApp === 'paytm'
                              ? regFeeApp
                              : 'upi',
                        })}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-emerald-600 text-white hover:bg-emerald-700"
                      >
                        <span>
                          Pay ₹{registrationFeeAmount} in {regFeeAppLabel(regFeeApp)}
                        </span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                      <a
                        href={buildUpiPaymentLink({
                          upiId: adminUpiId,
                          payeeName: businessPayeeName,
                          amount: registrationFeeAmount,
                          note: `Driver Reg Fee`,
                          app: 'upi',
                        })}
                        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border border-neutral-300 text-neutral-700 hover:bg-neutral-50"
                      >
                        Other UPI App
                      </a>
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={regFeeRef}
                    onChange={(e) => setRegFeeRef(e.target.value)}
                    placeholder={
                      regFeeApp === 'cash'
                        ? 'Office receipt number (optional)'
                        : `Enter ${regFeeAppLabel(regFeeApp)} UTR / Transaction ID`
                    }
                    className="flex-1 px-3.5 py-2.5 border border-neutral-300 rounded-xl text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                  <button
                    type="button"
                    onClick={handlePayRegistrationFee}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl transition-colors shrink-0"
                  >
                    {t.payRegFeeBtn}
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 font-medium">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>
                    Registration Fee Paid: ₹{registrationFeeAmount} ({regFeeAppLabel(regFeeApp)})
                    {regFeeRef ? ` · Ref: ${regFeeRef}` : ''}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setRegFeePaid(false)}
                  className="text-xs underline font-medium"
                >
                  Edit
                </button>
              </div>
            )}
          </div>

          {feedback && (
            <div
              className={`p-3 rounded-xl text-xs border ${
                feedback.type === 'ok'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-red-50 border-red-200 text-red-800'
              }`}
            >
              {feedback.text}
            </div>
          )}

          <button
            type="submit"
            disabled={saving || (registrationFeeAmount > 0 && !regFeePaid)}
            className="w-full min-h-[48px] px-4 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-medium rounded-xl transition-colors"
          >
            {saving ? 'Submitting to Firestore...' : t.submitVerification}
          </button>
        </form>
      </div>
    );
  }

  const isApproved = driver.approval_status === 'approved';
  const isRejected = driver.approval_status === 'rejected';

  const activePickup: LatLngPoint | null = activeRide
    ? { lat: activeRide.pickup_lat, lng: activeRide.pickup_lng, label: activeRide.pickup_address }
    : null;
  const activeDest: LatLngPoint | null = activeRide
    ? {
        lat: activeRide.destination_lat,
        lng: activeRide.destination_lng,
        label: activeRide.destination_address,
      }
    : null;

  const navOrigin =
    activeRide && activeRide.ride_status === 'accepted' && currentGps
      ? currentGps
      : activePickup;
  const navDest =
    activeRide && activeRide.ride_status === 'accepted' && currentGps
      ? activePickup
      : activeDest;

  const googleMapsNavTarget =
    activeRide && activeRide.ride_status === 'accepted'
      ? `${activeRide.pickup_lat},${activeRide.pickup_lng}`
      : activeRide
      ? `${activeRide.destination_lat},${activeRide.destination_lng}`
      : '';

  return (
    <div className="space-y-5">
      {firstCompletedRide && appRatingLoaded && !hasAppRating && !appRatingDismissed && (
        <FirstRideAppRatingBanner
          userId={user.uid}
          userName={driver.full_name}
          userRole="driver"
          firstCompletedRideId={firstCompletedRide.ride_id}
          language={language}
          onDismiss={() => {
            setAppRatingDismissed(true);
            try {
              window.localStorage.setItem(`smart_ride_apprate_dismissed_${user.uid}`, '1');
            } catch {
              // Ignore storage restrictions
            }
          }}
        />
      )}

      {/* Approval & Online Toggle Banner */}
      <div
        className={`p-4 sm:p-5 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
          isApproved
            ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
            : isRejected
            ? 'bg-red-50 border-red-200 text-red-950'
            : 'bg-amber-50 border-amber-200 text-amber-950'
        }`}
      >
        <div className="flex items-start gap-3">
          {isApproved ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
          ) : isRejected ? (
            <XCircle className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          )}
          <div>
            <p className="text-sm font-semibold">
              {isApproved
                ? t.driverApprovalApproved
                : isRejected
                ? t.driverApprovalRejected
                : t.driverApprovalPending}
            </p>
            <p className="text-xs mt-0.5 opacity-90">
              {isApproved
                ? driver.is_online
                  ? 'You are Online. Live GPS coordinates are sharing for nearby customer bookings.'
                  : 'Your KYC & vehicle documents are verified. Go Online to receive ride requests.'
                : isRejected
                ? driver.rejection_reason || 'Application rejected by administrator.'
                : 'An administrator must approve your Driving Licence & Vehicle RC before you can go online.'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleToggleOnline}
          disabled={!isApproved || togglingOnline}
          className={`min-h-[44px] px-5 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 ${
            !isApproved
              ? 'bg-neutral-200 text-neutral-500 cursor-not-allowed'
              : driver.is_online
              ? 'bg-neutral-900 text-white hover:bg-neutral-800'
              : 'bg-emerald-600 text-white hover:bg-emerald-700'
          }`}
        >
          <Power className="w-4 h-4" />
          <span>{driver.is_online ? t.goOffline : t.goOnline}</span>
        </button>
      </div>

      {gpsWatchError && (
        <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
          {gpsWatchError}
        </div>
      )}

      {feedback && (
        <div
          className={`p-3.5 rounded-xl text-xs border flex items-center justify-between gap-2 ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>{feedback.text}</span>
          </div>
          <button type="button" onClick={() => setFeedback(null)} className="underline">
            Dismiss
          </button>
        </div>
      )}

      {/* 3-Line Navigation Strip (1. Profile · 2. Address · 3. Ride Status) */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-2 grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={() => onSectionChange('profile')}
          className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-2 ${
            activeSection === 'profile'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span className="truncate">{t.menuProfile}</span>
        </button>
        <button
          type="button"
          onClick={() => onSectionChange('address')}
          className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-2 ${
            activeSection === 'address'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <MapPin className="w-4 h-4 shrink-0" />
          <span className="truncate">{t.menuAddress}</span>
        </button>
        <button
          type="button"
          onClick={() => onSectionChange('status')}
          className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-2 relative ${
            activeSection === 'status'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <Navigation className="w-4 h-4 shrink-0" />
          <span className="truncate">{t.menuRideStatus}</span>
          {(activeRide || visibleRequests.length > 0) && (
            <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" aria-label="Pending activity" />
          )}
        </button>
      </div>

      {/* SECTION 1: DRIVER PROFILE & KYC */}
      {activeSection === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 bg-white border border-neutral-200 rounded-2xl p-6 space-y-5">
            <div className="flex items-center gap-4 pb-4 border-b border-neutral-100">
              <img
                src={driver.profile_image || '/src/assets/images/driver_avatar_sample_1795224014527.jpg'}
                alt={driver.full_name}
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-full object-cover border border-neutral-200"
              />
              <div>
                <p className="text-xs font-medium text-emerald-700">{t.driverTitle}</p>
                <h3 className="text-lg font-bold text-neutral-900">{driver.full_name}</h3>
                <p className="text-xs text-neutral-500 font-mono">{driver.phone_number}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-xs text-neutral-500">Vehicle Registration</span>
                <p className="font-mono font-semibold text-neutral-900 mt-0.5">
                  {driver.vehicle_number}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-xs text-neutral-500">Vehicle Type</span>
                <p className="font-medium text-neutral-900 mt-0.5">{driver.vehicle_type}</p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-xs text-neutral-500">Manufacturer & Model</span>
                <p className="font-medium text-neutral-900 mt-0.5">
                  {vehicle ? `${vehicle.manufacturer} (${vehicle.model_year})` : 'Electric Rickshaw'}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-xs text-neutral-500">Driving Licence / RC</span>
                <p className="font-mono text-xs text-neutral-800 mt-0.5">
                  {docsRecord
                    ? `${docsRecord.driving_license_number} · ${docsRecord.rc_number}`
                    : 'Submitted'}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-xs text-neutral-500">{t.genderLabel}</span>
                <p className="font-medium text-neutral-900 mt-0.5">
                  {driver.gender === 'female'
                    ? t.genderFemale
                    : driver.gender === 'other'
                      ? t.genderOther
                      : driver.gender === 'male'
                        ? t.genderMale
                        : '—'}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-xs text-neutral-500">{t.dobLabel}</span>
                <p className="font-mono text-xs font-semibold text-neutral-900 mt-0.5">
                  {driver.date_of_birth || '—'}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-xs text-neutral-500">{t.appRegNumberLabel}</span>
                <p className="font-mono text-xs font-bold text-emerald-800 mt-0.5">
                  {driver.app_registration_number || formatDriverAppRegNo(driver.uid)}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-xs text-neutral-500">{t.driverAddressLabel}</span>
                <p className="text-xs font-medium text-neutral-900 mt-0.5">
                  {driver.address || '—'}
                </p>
              </div>
            </div>

            {(onOpenIdCard || onOpenSticker) && (
              <div className="flex flex-wrap gap-2.5 pt-2 border-t border-neutral-100">
                {onOpenIdCard && (
                  <button
                    type="button"
                    onClick={onOpenIdCard}
                    className="min-h-[42px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl transition-colors"
                  >
                    {t.menuDriverIdCard}
                  </button>
                )}
                {onOpenSticker && (
                  <button
                    type="button"
                    onClick={onOpenSticker}
                    className="min-h-[42px] px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors"
                  >
                    {t.menuAppSticker}
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="lg:col-span-5 bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-900 flex items-center gap-2">
                <MessageSquareWarning className="w-4 h-4 text-neutral-500" />
                <span>{t.complaintsTitle}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowComplaintForm((prev) => !prev)}
                className="text-xs font-medium text-emerald-700 hover:underline"
              >
                {showComplaintForm ? 'Close' : 'Raise Ticket'}
              </button>
            </div>

            {showComplaintForm && (
              <form onSubmit={handleSubmitComplaint} className="space-y-3 pt-2 border-t border-neutral-100">
                <input
                  type="text"
                  required
                  minLength={3}
                  maxLength={120}
                  value={complaintSubject}
                  onChange={(e) => setComplaintSubject(e.target.value)}
                  placeholder="Subject (e.g. Passenger no-show or payment dispute)"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs"
                />
                <textarea
                  rows={2}
                  required
                  minLength={5}
                  maxLength={600}
                  value={complaintDesc}
                  onChange={(e) => setComplaintDesc(e.target.value)}
                  placeholder="Provide trip details..."
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs"
                />
                <button
                  type="submit"
                  disabled={rideBusy === 'complaint'}
                  className="px-4 py-2 bg-neutral-900 text-white text-xs font-medium rounded-lg"
                >
                  {t.submitComplaint}
                </button>
              </form>
            )}

            {myComplaints.length === 0 ? (
              <p className="text-xs text-neutral-500 pt-2 border-t border-neutral-100">
                No support tickets yet. Raise a ticket anytime if you need help.
              </p>
            ) : (
              <div className="divide-y divide-neutral-100 border-t border-neutral-100">
                {myComplaints.map((c) => (
                  <div key={c.complaint_id} className="py-2.5 text-xs space-y-0.5">
                    <div className="flex justify-between">
                      <span className="font-medium text-neutral-900">{c.subject}</span>
                      <span className="capitalize font-mono text-emerald-700">{c.status}</span>
                    </div>
                    {c.admin_notes && <p className="text-neutral-600">Admin: {c.admin_notes}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: ADDRESS, LIVE GPS & NAVIGATION MAP */}
      {activeSection === 'address' && (
        <div className="bg-white border border-neutral-200 rounded-2xl p-5 sm:p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-neutral-900">
                {activeRide ? 'Customer Pickup & Destination Map' : 'Driver Live GPS & Route Map'}
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                {currentGps
                  ? `Live GPS: ${currentGps.lat.toFixed(5)}, ${currentGps.lng.toFixed(5)}`
                  : driver.is_online
                  ? 'Acquiring live GPS coordinates...'
                  : 'Go Online above to broadcast your live location'}
              </p>
            </div>
            {activeRide && googleMapsNavTarget && (
              <a
                href={`https://www.google.com/maps/dir/?api=1&destination=${googleMapsNavTarget}&travelmode=driving`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-medium rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Google Maps Nav</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>

          <SmartRideMap
            apiKeyAvailable={mapsEnabled}
            center={currentGps || activePickup}
            pickup={activePickup}
            destination={activeDest}
            assignedDriver={currentGps}
            routeOrigin={navOrigin}
            routeDestination={navDest}
            heightClassName="h-[340px] sm:h-[420px]"
          />

          {activeRide ? (
            <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-200 text-xs space-y-1.5">
              <p>
                <strong className="text-emerald-700">Customer Pickup:</strong>{' '}
                {activeRide.pickup_address}
              </p>
              <p>
                <strong className="text-neutral-900">Customer Destination:</strong>{' '}
                {activeRide.destination_address}
              </p>
            </div>
          ) : (
            <p className="text-xs text-neutral-500">
              When you accept a booking in <strong>{t.menuRideStatus}</strong>, the passenger pickup and destination route will automatically appear here.
            </p>
          )}
        </div>
      )}

      {/* SECTION 3: DRIVER & CUSTOMER RIDE STATUS */}
      {activeSection === 'status' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-neutral-200 rounded-2xl p-5">
              <p className="text-xs text-neutral-500">{t.dailyEarnings}</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-neutral-900 mt-1">
                ₹{liveMetrics.totalEarnings.toLocaleString('en-IN')}
              </p>
              <p className="text-[11px] text-emerald-700 font-mono tabular-nums mt-0.5">
                Today: ₹{liveMetrics.todayEarnings.toLocaleString('en-IN')}
              </p>
            </div>
            <div className="bg-white border border-neutral-200 rounded-2xl p-5">
              <p className="text-xs text-neutral-500">{t.completedRides}</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-neutral-900 mt-1">
                {liveMetrics.completedCount}
              </p>
            </div>
            <div className="bg-white border border-neutral-200 rounded-2xl p-5">
              <p className="text-xs text-neutral-500">{t.driverRating}</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-neutral-900 mt-1 flex items-center gap-1.5">
                <span>{liveMetrics.avgRating.toFixed(1)}</span>
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              </p>
            </div>
            <div className="bg-white border border-neutral-200 rounded-2xl p-5">
              <p className="text-xs text-neutral-500">Availability</p>
              <p
                className={`text-lg font-bold mt-1 ${
                  driver.is_online ? 'text-emerald-700' : 'text-neutral-700'
                }`}
              >
                {driver.is_online ? 'Online' : 'Offline'}
              </p>
            </div>
          </div>

          {isApproved && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-7 space-y-5">
                {activeRide ? (
                  <div className="p-5 rounded-2xl bg-neutral-900 text-white space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="text-xs font-medium text-emerald-400 uppercase">
                          Active Ride · {activeRide.ride_status.replace('_', ' ')}
                        </p>
                        <p className="text-sm font-semibold mt-0.5">
                          Customer: {activeRide.customer_name || 'Smart Ride Passenger'}
                        </p>
                        <p className="text-xs text-neutral-300 mt-0.5 tabular-nums">
                          {activeRide.distance_km} km · {activeRide.duration_minutes} min est.
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        {activeRide.customer_phone && (
                          <a
                            href={`tel:${activeRide.customer_phone}`}
                            className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded-lg text-xs font-mono text-white inline-flex items-center gap-1.5"
                          >
                            <Phone className="w-3.5 h-3.5 text-emerald-400" />
                            <span>{activeRide.customer_phone}</span>
                          </a>
                        )}
                        <span className="font-mono text-lg font-bold tabular-nums text-emerald-400">
                          ₹{activeRide.estimated_fare}
                        </span>
                      </div>
                    </div>

                    <div className="text-xs text-neutral-300 space-y-1.5 border-t border-neutral-800 pt-3">
                      <p>
                        <span className="text-emerald-400 font-semibold">Pickup:</span>{' '}
                        {activeRide.pickup_address}
                      </p>
                      <p>
                        <span className="text-neutral-400 font-semibold">Destination:</span>{' '}
                        {activeRide.destination_address}
                      </p>
                    </div>

                    {activeRide.ride_status === 'in_progress' && (
                      <label className="flex items-center justify-between gap-3 bg-neutral-800 px-3.5 py-2.5 rounded-xl text-xs">
                        <span className="text-neutral-300">
                          Waiting Minutes (₹{fareSettings?.waiting_charge ?? 2}/min):
                        </span>
                        <input
                          type="number"
                          min={0}
                          max={120}
                          value={waitingMinsInput}
                          onChange={(e) => setWaitingMinsInput(Number(e.target.value))}
                          className="w-20 px-2.5 py-1 bg-neutral-900 border border-neutral-700 rounded-lg text-right font-mono text-white"
                        />
                      </label>
                    )}

                    <div className="flex flex-wrap gap-2.5 pt-1">
                      {googleMapsNavTarget && (
                        <a
                          href={`https://www.google.com/maps/dir/?api=1&destination=${googleMapsNavTarget}&travelmode=driving`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-4 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-medium rounded-xl inline-flex items-center gap-1.5"
                        >
                          <Navigation className="w-3.5 h-3.5" />
                          <span>Navigate</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                      {activeRide.ride_status === 'accepted' && (
                        <button
                          type="button"
                          disabled={rideBusy === `step_${activeRide.ride_id}`}
                          onClick={() => void handleAdvanceRide(activeRide, 'arrived')}
                          className="flex-1 min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5"
                        >
                          <MapPin className="w-4 h-4" />
                          <span>{t.markArrived}</span>
                        </button>
                      )}
                      {(activeRide.ride_status === 'accepted' ||
                        activeRide.ride_status === 'arrived') && (
                        <button
                          type="button"
                          disabled={rideBusy === `step_${activeRide.ride_id}`}
                          onClick={() => void handleAdvanceRide(activeRide, 'in_progress')}
                          className="flex-1 min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5"
                        >
                          <Play className="w-4 h-4" />
                          <span>{t.startRide}</span>
                        </button>
                      )}
                      {activeRide.ride_status === 'in_progress' && (
                        <button
                          type="button"
                          disabled={rideBusy === `step_${activeRide.ride_id}`}
                          onClick={() => void handleAdvanceRide(activeRide, 'completed')}
                          className="flex-1 min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5"
                        >
                          <Flag className="w-4 h-4" />
                          <span>{t.completeRide}</span>
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="bg-white border border-neutral-200 rounded-2xl p-6 text-center space-y-2">
                    <Navigation className="w-5 h-5 text-emerald-600 mx-auto" />
                    <p className="text-sm font-semibold text-neutral-900">No Active Trip Assigned</p>
                    <p className="text-xs text-neutral-500">
                      Accept an incoming passenger booking on the right when Online.
                    </p>
                  </div>
                )}

                {!activeRide && uncollectedCashRide && (
                  <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold text-amber-950">
                        Pending Fare Collection · ₹
                        {uncollectedCashRide.final_fare || uncollectedCashRide.estimated_fare}
                      </p>
                      <p className="text-xs text-amber-800">
                        {uncollectedCashRide.pickup_address} →{' '}
                        {uncollectedCashRide.destination_address}
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={rideBusy === `cash_${uncollectedCashRide.ride_id}`}
                      onClick={() => void handleConfirmCashCollected(uncollectedCashRide)}
                      className="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 shrink-0"
                    >
                      <Banknote className="w-4 h-4" />
                      <span>Confirm Cash Received</span>
                    </button>
                  </div>
                )}

                <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-neutral-900">Driver Trip History</h3>
                    <span className="text-xs font-mono tabular-nums text-neutral-500">
                      {myRides.length} trips
                    </span>
                  </div>
                  {myRides.length === 0 ? (
                    <p className="text-xs text-neutral-500 py-4 border-t border-neutral-100">
                      Accepted and completed rides will appear here.
                    </p>
                  ) : (
                    <div className="divide-y divide-neutral-100 max-h-72 overflow-y-auto">
                      {myRides.map((r) => (
                        <div key={r.ride_id} className="py-3 flex items-center justify-between gap-3">
                          <div className="min-w-0">
                            <p className="text-xs font-medium text-neutral-900 truncate">
                              {r.pickup_address} → {r.destination_address}
                            </p>
                            <p className="text-xs text-neutral-500 mt-0.5 tabular-nums">
                              {r.distance_km} km · {r.ride_status.replace('_', ' ')} ·{' '}
                              {r.payment_status === 'paid'
                                ? `Paid (${(r.payment_method || 'cash').toUpperCase()})`
                                : 'Pending'}
                            </p>
                          </div>
                          <span className="font-mono tabular-nums text-sm font-semibold text-neutral-900">
                            ₹{r.final_fare || r.estimated_fare}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="lg:col-span-5 space-y-6">
                <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-neutral-900 flex items-center gap-2">
                      <Navigation className="w-4 h-4 text-emerald-600" />
                      <span>{t.incomingRequests}</span>
                    </h3>
                    <span className="text-xs font-mono tabular-nums text-neutral-500">
                      {visibleRequests.length} open
                    </span>
                  </div>

                  {!driver.is_online ? (
                    <div className="py-8 text-center border-t border-neutral-100 space-y-1.5">
                      <p className="text-sm font-medium text-neutral-800">You are currently Offline</p>
                      <p className="text-xs text-neutral-500">
                        Switch to Online above to receive live customer booking requests.
                      </p>
                    </div>
                  ) : visibleRequests.length === 0 ? (
                    <div className="py-8 text-center border-t border-neutral-100 space-y-1.5">
                      <Clock className="w-5 h-5 text-neutral-400 mx-auto" />
                      <p className="text-xs text-neutral-500">
                        Listening for nearby customer Electric Rickshaw bookings...
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3 border-t border-neutral-100 pt-3">
                      {visibleRequests.map((req) => (
                        <div
                          key={req.ride_id}
                          className="p-4 rounded-xl border border-neutral-200 bg-neutral-50 space-y-3"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0 space-y-1">
                              <p className="text-xs font-semibold text-neutral-900">
                                {req.customer_name || 'Passenger'} · {req.distance_km} km (
                                {req.duration_minutes} min)
                              </p>
                              <p className="text-xs text-neutral-600 line-clamp-2">
                                <strong className="text-emerald-700">Pickup:</strong>{' '}
                                {req.pickup_address}
                              </p>
                              <p className="text-xs text-neutral-600 line-clamp-2">
                                <strong className="text-neutral-800">Drop:</strong>{' '}
                                {req.destination_address}
                              </p>
                            </div>
                            <span className="font-mono text-base font-bold tabular-nums text-emerald-700 shrink-0">
                              ₹{req.estimated_fare}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                setDismissedIds((prev) => ({ ...prev, [req.ride_id]: true }))
                              }
                              className="px-3 py-2 border border-neutral-300 bg-white hover:bg-neutral-100 text-neutral-700 text-xs font-medium rounded-lg"
                            >
                              {t.rejectRide}
                            </button>
                            <button
                              type="button"
                              disabled={Boolean(activeRide) || rideBusy === `accept_${req.ride_id}`}
                              onClick={() => void handleAcceptRide(req)}
                              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg"
                            >
                              {rideBusy === `accept_${req.ride_id}` ? 'Claiming...' : t.acceptRide}
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-neutral-900 flex items-center gap-2">
                      <Bell className="w-4 h-4 text-neutral-500" />
                      <span>Driver Notifications</span>
                    </h3>
                    <span className="text-xs font-mono tabular-nums text-neutral-500">
                      {notifications.length}
                    </span>
                  </div>

                  {notifications.length === 0 ? (
                    <div className="py-6 text-center border-t border-neutral-100">
                      <p className="text-xs text-neutral-500">
                        Verification updates and ride alerts appear here.
                      </p>
                    </div>
                  ) : (
                    <div className="divide-y divide-neutral-100 max-h-60 overflow-y-auto">
                      {notifications.map((n) => (
                        <div key={n.notification_id} className="py-3 space-y-1">
                          <p className="text-xs font-semibold text-neutral-900">{n.title}</p>
                          <p className="text-xs text-neutral-600 leading-relaxed">{n.body}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
