import React, { useCallback, useEffect, useMemo, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import {
  Banknote,
  Camera,
  CheckCircle2,
  Clock,
  IndianRupee,
  Loader2,
  LocateFixed,
  MapPin,
  MessageSquareWarning,
  Navigation,
  Phone,
  QrCode,
  ShieldAlert,
  Star,
  UserCheck,
  XCircle,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType, storage } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import {
  buildUpiPaymentLink,
  calculateSmartRideFare,
  clampText,
  FIELD_LIMITS,
  formatIndianPhone,
  isValidIndianPhone,
  sanitizeImageUrl,
  validateDateOfBirth,
} from '../lib/validation';
import type {
  ComplaintRecord,
  CustomerProfile,
  DriverLocationRecord,
  FareSettingsRecord,
  GenderOption,
  LanguageCode,
  PortalSection,
  RatingRecord,
  RideRecord,
} from '../types/smartride';
import { AuthGateCard } from './AuthGateCard';
import { FirstRideAppRatingBanner } from './FirstRideAppRatingBanner';
import { PlaceSearchInput, type SelectedPlaceResult } from './maps/PlaceSearchInput';
import {
  SmartRideMap,
  type ComputedRouteResult,
  type LatLngPoint,
} from './maps/SmartRideMap';

interface CustomerPortalProps {
  user: User | null;
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  mapsEnabled: boolean;
  activeSection: PortalSection;
  onSectionChange: (section: PortalSection) => void;
}

const INDIAN_CITIES = [
  'Kolkata',
  'Howrah',
  'Siliguri',
  'Durgapur',
  'Asansol',
  'Patna',
  'Varanasi',
  'Lucknow',
  'Guwahati',
  'Bhubaneswar',
];

export function CustomerPortal({
  user,
  language,
  onLanguageChange: _onLanguageChange,
  mapsEnabled,
  activeSection,
  onSectionChange,
}: CustomerPortalProps) {
  const t = TRANSLATIONS[language];
  const [customerProfile, setCustomerProfile] = useState<CustomerProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [fareSettings, setFareSettings] = useState<FareSettingsRecord | null>(null);
  const [rides, setRides] = useState<RideRecord[]>([]);
  const [onlineDrivers, setOnlineDrivers] = useState<DriverLocationRecord[]>([]);
  const [assignedDriverLoc, setAssignedDriverLoc] = useState<DriverLocationRecord | null>(null);
  const [myRatings, setMyRatings] = useState<RatingRecord[]>([]);
  const [myComplaints, setMyComplaints] = useState<ComplaintRecord[]>([]);
  const [hasAppRating, setHasAppRating] = useState(false);
  const [appRatingLoaded, setAppRatingLoaded] = useState(false);
  const [appRatingDismissed, setAppRatingDismissed] = useState(false);

  // Registration & edit form state
  const [fullName, setFullName] = useState('');
  const [phoneInput, setPhoneInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [city, setCity] = useState('Kolkata');
  const [gender, setGender] = useState<GenderOption>('male');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [photoUrl, setPhotoUrl] = useState(
    '/src/assets/images/customer_avatar_sample_1795224014041.jpg'
  );
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [editingProfile, setEditingProfile] = useState(false);

  // Google Maps Booking State
  const [pickupText, setPickupText] = useState('');
  const [pickupPoint, setPickupPoint] = useState<LatLngPoint | null>(null);
  const [destText, setDestText] = useState('');
  const [destPoint, setDestPoint] = useState<LatLngPoint | null>(null);
  const [mapTapMode, setMapTapMode] = useState<'pickup' | 'destination'>('destination');
  const [gpsStatus, setGpsStatus] = useState('');
  const [routeMetrics, setRouteMetrics] = useState<ComputedRouteResult | null>(null);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [approachMetrics, setApproachMetrics] = useState<ComputedRouteResult | null>(null);
  const [bookingBusy, setBookingBusy] = useState(false);
  const [actionBusy, setActionBusy] = useState<string | null>(null);

  // Rating & Complaint State
  const [ratingScore, setRatingScore] = useState(5);
  const [ratingFeedback, setRatingFeedback] = useState('');
  const [showComplaintForm, setShowComplaintForm] = useState(false);
  const [complaintRideId, setComplaintRideId] = useState('');
  const [complaintSubject, setComplaintSubject] = useState('');
  const [complaintDesc, setComplaintDesc] = useState('');

  useEffect(() => {
    if (!user) {
      setCustomerProfile(null);
      setFareSettings(null);
      setRides([]);
      setOnlineDrivers([]);
      setMyRatings([]);
      setMyComplaints([]);
      setHasAppRating(false);
      setAppRatingLoaded(false);
      return;
    }

    try {
      setAppRatingDismissed(
        window.localStorage.getItem(`smart_ride_apprate_dismissed_${user.uid}`) === '1'
      );
    } catch {
      setAppRatingDismissed(false);
    }

    setProfileLoading(true);
    setFullName(user.displayName || '');
    setEmailInput(user.email || '');
    if (user.phoneNumber) {
      setPhoneInput(user.phoneNumber.replace(/^\+91/, ''));
    }
    if (user.photoURL) {
      setPhotoUrl(user.photoURL);
    }

    const custPath = `customers/${user.uid}`;
    const unsubCust = onSnapshot(
      doc(db, 'customers', user.uid),
      (snap) => {
        if (snap.exists()) {
          const data = snap.data() as CustomerProfile;
          setCustomerProfile(data);
          setFullName(data.full_name);
          setEmailInput(data.email);
          setPhoneInput(data.phone_number.replace(/^\+91/, ''));
          setCity(data.default_city || 'Kolkata');
          if (data.gender) setGender(data.gender);
          if (data.date_of_birth) setDateOfBirth(data.date_of_birth);
          if (data.profile_image) setPhotoUrl(data.profile_image);
        } else {
          setCustomerProfile(null);
        }
        setProfileLoading(false);
      },
      (err) => {
        setProfileLoading(false);
        handleFirestoreError(err, OperationType.GET, custPath);
      }
    );

    const unsubFare = onSnapshot(
      doc(db, 'fare_settings', 'default'),
      (snap) => {
        setFareSettings(snap.exists() ? (snap.data() as FareSettingsRecord) : null);
      },
      (err) => handleFirestoreError(err, OperationType.GET, 'fare_settings/default')
    );

    const ridesQuery = query(collection(db, 'rides'), where('customer_id', '==', user.uid));
    const unsubRides = onSnapshot(
      ridesQuery,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as RideRecord);
        list.sort((a, b) => {
          const at = a.created_at?.toMillis?.() ?? 0;
          const bt = b.created_at?.toMillis?.() ?? 0;
          return bt - at;
        });
        setRides(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'rides')
    );

    const driversLocQuery = query(
      collection(db, 'driver_locations'),
      where('is_online', '==', true)
    );
    const unsubDriverLocs = onSnapshot(
      driversLocQuery,
      (snap) => {
        setOnlineDrivers(snap.docs.map((d) => d.data() as DriverLocationRecord));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'driver_locations')
    );

    const ratingsQ = query(collection(db, 'ratings'), where('customer_id', '==', user.uid));
    const unsubRatings = onSnapshot(
      ratingsQ,
      (snap) => setMyRatings(snap.docs.map((d) => d.data() as RatingRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'ratings')
    );

    const complaintsQ = query(
      collection(db, 'complaints'),
      where('reporter_id', '==', user.uid)
    );
    const unsubComplaints = onSnapshot(
      complaintsQ,
      (snap) => setMyComplaints(snap.docs.map((d) => d.data() as ComplaintRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'complaints')
    );

    const unsubAppRating = onSnapshot(
      doc(db, 'app_ratings', user.uid),
      (snap) => {
        setHasAppRating(snap.exists());
        setAppRatingLoaded(true);
      },
      () => {
        setAppRatingLoaded(true);
      }
    );

    return () => {
      unsubCust();
      unsubFare();
      unsubRides();
      unsubDriverLocs();
      unsubRatings();
      unsubComplaints();
      unsubAppRating();
    };
  }, [user]);

  const activeRide = useMemo(() => {
    return (
      rides.find((r) =>
        ['requested', 'accepted', 'arrived', 'in_progress'].includes(r.ride_status)
      ) || null
    );
  }, [rides]);

  const unratedCompletedRide = useMemo(() => {
    const ratedRideIds = myRatings.reduce<Record<string, boolean>>((acc, item) => {
      acc[item.ride_id] = true;
      return acc;
    }, {});
    return (
      rides.find(
        (r) => r.ride_status === 'completed' && r.driver_id && !ratedRideIds[r.ride_id]
      ) || null
    );
  }, [rides, myRatings]);

  const unpaidCompletedRide = useMemo(() => {
    return (
      rides.find(
        (r) =>
          r.ride_status === 'completed' &&
          r.payment_status === 'pending' &&
          Boolean(r.driver_id)
      ) || null
    );
  }, [rides]);

  const firstCompletedRide = useMemo(() => {
    const completed = rides.filter((r) => r.ride_status === 'completed');
    return completed.length > 0 ? completed[completed.length - 1] : null;
  }, [rides]);

  useEffect(() => {
    if (!user || !firstCompletedRide || !appRatingLoaded || hasAppRating) return;
    const localNotifKey = `smart_ride_apprate_notif_c_${user.uid}`;
    try {
      if (window.localStorage.getItem(localNotifKey) === '1') return;
    } catch {
      // Ignore storage access restrictions
    }

    const notifId = `notif_apprate_c_${user.uid}`;
    const notifRef = doc(db, 'notifications', notifId);
    void getDoc(notifRef)
      .then(async (snap) => {
        if (!snap.exists()) {
          await setDoc(notifRef, {
            notification_id: notifId,
            recipient_id: user.uid,
            title: t.firstRideRateTitle,
            body: t.firstRideRateBody,
            type: 'ride_update',
            is_read: false,
            created_at: serverTimestamp(),
          });
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification(t.firstRideRateTitle, { body: t.firstRideRateBody });
          }
        }
        try {
          window.localStorage.setItem(localNotifKey, '1');
        } catch {
          // Ignore storage restrictions
        }
      })
      .catch(() => {
        // Ignore duplicate/network errors for non-blocking rating notification
      });
  }, [user, firstCompletedRide, appRatingLoaded, hasAppRating, t.firstRideRateTitle, t.firstRideRateBody]);

  // Subscribe to assigned driver's live location when ride is accepted/arrived/in_progress
  useEffect(() => {
    if (!user || !activeRide || !activeRide.driver_id) {
      setAssignedDriverLoc(null);
      setApproachMetrics(null);
      return;
    }

    const unsubLoc = onSnapshot(
      doc(db, 'driver_locations', activeRide.driver_id),
      (snap) => {
        if (snap.exists()) {
          setAssignedDriverLoc(snap.data() as DriverLocationRecord);
        } else {
          setAssignedDriverLoc(null);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `driver_locations/${activeRide.driver_id}`)
    );

    return () => unsubLoc();
  }, [user, activeRide?.ride_id, activeRide?.driver_id]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploadingPhoto(true);
    setFeedback(null);
    try {
      const storageRef = ref(storage, `customer_profiles/${user.uid}/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      setPhotoUrl(url);
      setFeedback({ type: 'ok', text: 'Profile photo uploaded to Firebase Storage.' });
    } catch (err) {
      setFeedback({
        type: 'err',
        text:
          err instanceof Error
            ? `Storage upload unavailable (${err.message}). Verify Firebase Storage rules or keep default avatar.`
            : 'Photo upload failed.',
      });
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSaveCustomerProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setFeedback(null);

    const cleanName = clampText(fullName, FIELD_LIMITS.NAME_MAX);
    const formattedPhone = formatIndianPhone(phoneInput);
    const cleanEmail = clampText(emailInput || user.email || '', FIELD_LIMITS.EMAIL_MAX);
    const cleanCity = clampText(city, FIELD_LIMITS.CITY_MAX);
    const cleanPhoto =
      sanitizeImageUrl(photoUrl) || '/src/assets/images/customer_avatar_sample_1795224014041.jpg';

    const dobCheck = validateDateOfBirth(dateOfBirth, 13);
    if (cleanName.length < FIELD_LIMITS.NAME_MIN) {
      setFeedback({ type: 'err', text: 'Full name must be at least 2 characters.' });
      return;
    }
    if (!isValidIndianPhone(formattedPhone)) {
      setFeedback({ type: 'err', text: 'Enter a valid 10-digit Indian mobile number (+91).' });
      return;
    }
    if (!dobCheck.valid) {
      setFeedback({ type: 'err', text: dobCheck.message });
      return;
    }

    setSaving(true);
    try {
      if (!customerProfile) {
        const batch = writeBatch(db);
        batch.set(doc(db, 'users', user.uid), {
          uid: user.uid,
          full_name: cleanName,
          phone_number: formattedPhone,
          email: cleanEmail,
          role: 'customer',
          profile_image: cleanPhoto,
          account_status: 'active',
          preferred_language: language,
          gender,
          date_of_birth: dateOfBirth.trim(),
          created_at: serverTimestamp(),
          updated_at: serverTimestamp(),
        });
        batch.set(doc(db, 'customers', user.uid), {
          uid: user.uid,
          full_name: cleanName,
          phone_number: formattedPhone,
          email: cleanEmail,
          profile_image: cleanPhoto,
          default_city: cleanCity,
          total_rides: 0,
          account_status: 'active',
          gender,
          date_of_birth: dateOfBirth.trim(),
          created_at: serverTimestamp(),
          updated_at: serverTimestamp(),
        });
        await batch.commit();
        setFeedback({ type: 'ok', text: 'Customer account created in Firestore.' });
      } else {
        await updateDoc(doc(db, 'customers', user.uid), {
          full_name: cleanName,
          phone_number: formattedPhone,
          email: cleanEmail,
          profile_image: cleanPhoto,
          default_city: cleanCity,
          gender,
          date_of_birth: dateOfBirth.trim(),
          updated_at: serverTimestamp(),
        });
        await updateDoc(doc(db, 'users', user.uid), {
          full_name: cleanName,
          phone_number: formattedPhone,
          email: cleanEmail,
          profile_image: cleanPhoto,
          preferred_language: language,
          gender,
          date_of_birth: dateOfBirth.trim(),
          updated_at: serverTimestamp(),
        });
        setEditingProfile(false);
        setFeedback({ type: 'ok', text: 'Customer profile updated.' });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `customers/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDetectGps = () => {
    if (!('geolocation' in navigator)) {
      setGpsStatus('Geolocation is not supported by your browser.');
      return;
    }
    setGpsStatus('Requesting device GPS coordinates...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = {
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
          label: `GPS (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)})`,
        };
        setPickupPoint(coords);
        setPickupText(`Current GPS (${coords.lat}, ${coords.lng})`);
        setGpsStatus('GPS pickup location acquired.');
        setRouteError(null);
      },
      (err) => {
        setGpsStatus(`Location permission needed: ${err.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handlePickupPlaceSelect = useCallback((place: SelectedPlaceResult) => {
    setPickupPoint({ lat: place.lat, lng: place.lng, label: place.address });
    setPickupText(place.address);
    setRouteError(null);
  }, []);

  const handleDestPlaceSelect = useCallback((place: SelectedPlaceResult) => {
    setDestPoint({ lat: place.lat, lng: place.lng, label: place.address });
    setDestText(place.address);
    setRouteError(null);
  }, []);

  const handleMapTap = useCallback(
    (coords: { lat: number; lng: number }) => {
      if (activeRide) return;
      const label = `${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}`;
      if (mapTapMode === 'pickup') {
        setPickupPoint({ ...coords, label: `Pin (${label})` });
        setPickupText(`Map Pin (${label})`);
      } else {
        setDestPoint({ ...coords, label: `Pin (${label})` });
        setDestText(`Map Pin (${label})`);
      }
      setRouteError(null);
    },
    [activeRide, mapTapMode]
  );

  const handleRouteComputed = useCallback(
    (result: ComputedRouteResult) => {
      if (activeRide && activeRide.ride_status === 'accepted') {
        setApproachMetrics(result);
      } else {
        setRouteMetrics(result);
        setRouteError(null);
      }
    },
    [activeRide]
  );

  const effectiveRates = useMemo(() => {
    return (
      fareSettings || {
        base_fare: 10,
        price_per_km: 12,
        minimum_fare: 20,
        waiting_charge: 2,
        platform_commission: 10,
        currency: 'INR' as const,
      }
    );
  }, [fareSettings]);

  const estimatedFare = useMemo(() => {
    if (!routeMetrics) return 0;
    return calculateSmartRideFare({
      distanceKm: routeMetrics.distanceKm,
      baseFare: effectiveRates.base_fare,
      pricePerKm: effectiveRates.price_per_km,
      minimumFare: effectiveRates.minimum_fare,
      waitingCharge: effectiveRates.waiting_charge,
    });
  }, [routeMetrics, effectiveRates]);

  const handleBookRide = async () => {
    if (!user || !customerProfile) return;
    if (customerProfile.account_status === 'suspended') {
      setFeedback({ type: 'err', text: 'Account suspended. Cannot book rides.' });
      return;
    }
    if (!pickupPoint || !destPoint || !routeMetrics) {
      setFeedback({
        type: 'err',
        text: 'Select both Pickup and Destination so Google Routes API can compute road distance.',
      });
      return;
    }

    setBookingBusy(true);
    setFeedback(null);
    const rideId = `ride_${user.uid.slice(0, 8)}_${Date.now()}`;

    try {
      await setDoc(doc(db, 'rides', rideId), {
        ride_id: rideId,
        customer_id: user.uid,
        customer_name: clampText(customerProfile.full_name, FIELD_LIMITS.NAME_MAX),
        customer_phone: clampText(customerProfile.phone_number, FIELD_LIMITS.PHONE_MAX),
        driver_id: '',
        driver_name: '',
        driver_phone: '',
        driver_vehicle_number: '',
        driver_photo: '',
        pickup_address: clampText(pickupText || pickupPoint.label || 'Pickup', FIELD_LIMITS.ADDRESS_MAX),
        destination_address: clampText(destText || destPoint.label || 'Destination', FIELD_LIMITS.ADDRESS_MAX),
        pickup_lat: pickupPoint.lat,
        pickup_lng: pickupPoint.lng,
        destination_lat: destPoint.lat,
        destination_lng: destPoint.lng,
        distance_km: routeMetrics.distanceKm,
        duration_minutes: routeMetrics.durationMinutes,
        waiting_minutes: 0,
        estimated_fare: estimatedFare,
        final_fare: 0,
        ride_status: 'requested',
        payment_status: 'pending',
        payment_method: '',
        cancelled_by: '',
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      });
      setFeedback({
        type: 'ok',
        text: `Booking ${rideId} sent to nearby approved Electric Rickshaw drivers.`,
      });
      onSectionChange('status');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `rides/${rideId}`);
    } finally {
      setBookingBusy(false);
    }
  };

  const handleCancelRide = async (ride: RideRecord) => {
    if (!user) return;
    setActionBusy(`cancel_${ride.ride_id}`);
    try {
      await updateDoc(doc(db, 'rides', ride.ride_id), {
        ride_status: 'cancelled',
        cancelled_by: 'customer',
        updated_at: serverTimestamp(),
      });
      setFeedback({ type: 'ok', text: 'Ride cancelled.' });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `rides/${ride.ride_id}`);
    } finally {
      setActionBusy(null);
    }
  };

  const handleConfirmPayment = async (ride: RideRecord, method: 'cash' | 'upi') => {
    if (!user || !ride.driver_id) return;
    setActionBusy(`pay_${ride.ride_id}`);
    const amount = ride.final_fare > 0 ? ride.final_fare : ride.estimated_fare;
    const paymentId = `pay_${ride.ride_id}`;
    const notifId = `notif_pay_${ride.ride_id}_${Date.now()}`;

    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'rides', ride.ride_id), {
        payment_method: method,
        payment_status: 'paid',
        updated_at: serverTimestamp(),
      });
      batch.set(doc(db, 'payments', paymentId), {
        payment_id: paymentId,
        ride_id: ride.ride_id,
        customer_id: user.uid,
        driver_id: ride.driver_id,
        amount,
        method,
        status: 'verified',
        created_at: serverTimestamp(),
      });
      batch.set(doc(db, 'notifications', notifId), {
        notification_id: notifId,
        recipient_id: ride.driver_id,
        title: `Payment Received (₹${amount})`,
        body: `${ride.customer_name || 'Customer'} paid ₹${amount} via ${method.toUpperCase()} for ride ${ride.ride_id}.`,
        type: 'payment',
        is_read: false,
        created_at: serverTimestamp(),
      });
      await batch.commit();
      setFeedback({
        type: 'ok',
        text: `Payment of ₹${amount} recorded via ${method.toUpperCase()}.`,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `payments/${paymentId}`);
    } finally {
      setActionBusy(null);
    }
  };

  const handleSubmitRating = async (ride: RideRecord) => {
    if (!user || !ride.driver_id) return;
    setActionBusy(`rate_${ride.ride_id}`);
    const ratingId = `rat_${ride.ride_id}`;
    try {
      await setDoc(doc(db, 'ratings', ratingId), {
        rating_id: ratingId,
        ride_id: ride.ride_id,
        customer_id: user.uid,
        driver_id: ride.driver_id,
        score: ratingScore,
        feedback: clampText(ratingFeedback || 'Smooth e-rickshaw trip.', FIELD_LIMITS.FEEDBACK_MAX),
        created_at: serverTimestamp(),
      });
      setRatingFeedback('');
      setRatingScore(5);
      setFeedback({ type: 'ok', text: 'Thank you for rating your driver!' });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `ratings/${ratingId}`);
    } finally {
      setActionBusy(null);
    }
  };

  const handleSubmitComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !customerProfile) return;
    const cleanSubj = clampText(complaintSubject, FIELD_LIMITS.SUBJECT_MAX);
    const cleanDesc = clampText(complaintDesc, FIELD_LIMITS.DESCRIPTION_MAX);
    if (cleanSubj.length < 3 || cleanDesc.length < 5) {
      setFeedback({ type: 'err', text: 'Enter a valid subject and complaint description.' });
      return;
    }

    setActionBusy('complaint');
    const complaintId = `cmp_${user.uid.slice(0, 6)}_${Date.now()}`;
    try {
      await setDoc(doc(db, 'complaints', complaintId), {
        complaint_id: complaintId,
        ride_id: clampText(complaintRideId, FIELD_LIMITS.UID_MAX),
        reporter_id: user.uid,
        reporter_role: 'customer',
        reporter_name: clampText(customerProfile.full_name, FIELD_LIMITS.NAME_MAX),
        subject: cleanSubj,
        description: cleanDesc,
        status: 'open',
        admin_notes: '',
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      });
      setComplaintSubject('');
      setComplaintDesc('');
      setComplaintRideId('');
      setShowComplaintForm(false);
      setFeedback({ type: 'ok', text: 'Support ticket submitted to Smart Ride Admin.' });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `complaints/${complaintId}`);
    } finally {
      setActionBusy(null);
    }
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto py-4 space-y-5">
        <div className="text-center space-y-1">
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
            {t.welcomeHeadline}
          </h1>
          <p className="text-xs text-neutral-500">{t.roleCustomerTitle}</p>
        </div>
        <AuthGateCard portalLabel={t.customerTitle} language={language} allowPhoneOtp />
      </div>
    );
  }

  if (profileLoading) {
    return (
      <div className="bg-white border border-neutral-200 rounded-2xl p-8 space-y-4">
        <div className="h-6 w-48 bg-neutral-200 rounded animate-pulse" />
        <div className="h-4 w-72 bg-neutral-100 rounded animate-pulse" />
        <div className="h-32 w-full bg-neutral-100 rounded-xl animate-pulse" />
      </div>
    );
  }

  if (!customerProfile || editingProfile) {
    return (
      <div className="max-w-2xl mx-auto bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-neutral-100">
          <div>
            <p className="text-xs font-medium text-emerald-700">{t.customerTitle}</p>
            <h2 className="text-xl font-bold text-neutral-900">
              {customerProfile ? 'Update Customer Profile' : 'Complete Customer Registration'}
            </h2>
          </div>
          {customerProfile && (
            <button
              type="button"
              onClick={() => setEditingProfile(false)}
              className="px-3 py-1.5 text-xs font-medium text-neutral-600 border border-neutral-200 rounded-lg hover:bg-neutral-50"
            >
              Cancel
            </button>
          )}
        </div>

        <form onSubmit={handleSaveCustomerProfile} className="space-y-5">
          <div className="flex items-center gap-4">
            <img
              src={photoUrl || '/src/assets/images/customer_avatar_sample_1795224014041.jpg'}
              alt="Customer avatar"
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-full object-cover border border-neutral-200"
            />
            <div>
              <label className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-neutral-700 bg-neutral-50 border border-neutral-200 rounded-lg cursor-pointer hover:bg-neutral-100">
                <Camera className="w-4 h-4" />
                <span>{uploadingPhoto ? 'Uploading...' : 'Upload Photo'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>
              <p className="text-xs text-neutral-500 mt-1">
                Stored securely for driver pickup verification.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.fullName}</span>
              <input
                type="text"
                required
                minLength={2}
                maxLength={100}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Arjun Chatterjee"
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.phoneNumberLabel}</span>
              <div className="mt-1.5 flex items-center border border-neutral-300 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-emerald-600">
                <span className="px-3 py-2.5 bg-neutral-50 border-r border-neutral-200 text-sm font-mono text-neutral-700">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="9876543210"
                  className="w-full px-3 py-2.5 text-sm font-mono focus:outline-none"
                />
              </div>
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.genderLabel}</span>
              <select
                required
                value={gender}
                onChange={(e) => setGender(e.target.value as GenderOption)}
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <option value="male">{t.genderMale}</option>
                <option value="female">{t.genderFemale}</option>
                <option value="other">{t.genderOther}</option>
              </select>
            </label>

            <label className="block">
              <span className="text-xs font-medium text-neutral-700">{t.dobLabel}</span>
              <input
                type="date"
                required
                min="1920-01-01"
                max={new Date().toISOString().split('T')[0]}
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>

            <label className="block sm:col-span-2">
              <span className="text-xs font-medium text-neutral-700">{t.defaultCity}</span>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                {INDIAN_CITIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </label>
          </div>

          {feedback && (
            <div
              className={`p-3 rounded-xl text-xs border ${
                feedback.type === 'ok'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-red-50 border-red-200 text-red-800'
              }`}
            >
              {feedback.text}
            </div>
          )}

          <button
            type="submit"
            disabled={saving}
            className="w-full min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-medium rounded-xl transition-colors"
          >
            {saving ? 'Saving to Firestore...' : t.saveProfile}
          </button>
        </form>
      </div>
    );
  }

  // Decide map markers & route points depending on whether customer has an active ride
  const mapPickup: LatLngPoint | null = activeRide
    ? { lat: activeRide.pickup_lat, lng: activeRide.pickup_lng, label: activeRide.pickup_address }
    : pickupPoint;
  const mapDest: LatLngPoint | null = activeRide
    ? {
        lat: activeRide.destination_lat,
        lng: activeRide.destination_lng,
        label: activeRide.destination_address,
      }
    : destPoint;
  const mapDriverPoint: LatLngPoint | null =
    activeRide &&
    activeRide.driver_id &&
    assignedDriverLoc &&
    assignedDriverLoc.lat !== 0 &&
    assignedDriverLoc.lng !== 0
      ? {
          lat: assignedDriverLoc.lat,
          lng: assignedDriverLoc.lng,
          label: `${activeRide.driver_name || 'Driver'} · ${activeRide.driver_vehicle_number || ''}`,
        }
      : null;

  const routeOrigin =
    activeRide && activeRide.ride_status === 'accepted' && mapDriverPoint
      ? mapDriverPoint
      : mapPickup;
  const routeDest =
    activeRide && activeRide.ride_status === 'accepted' && mapDriverPoint ? mapPickup : mapDest;

  const completedRidesCount = Math.max(
    customerProfile.total_rides,
    rides.filter((r) => r.ride_status === 'completed').length
  );

  return (
    <div className="space-y-5">
      {firstCompletedRide && appRatingLoaded && !hasAppRating && !appRatingDismissed && (
        <FirstRideAppRatingBanner
          userId={user.uid}
          userName={customerProfile.full_name}
          userRole="customer"
          firstCompletedRideId={firstCompletedRide.ride_id}
          language={language}
          onDismiss={() => {
            setAppRatingDismissed(true);
            try {
              window.localStorage.setItem(`smart_ride_apprate_dismissed_${user.uid}`, '1');
            } catch {
              // Ignore storage restrictions
            }
          }}
        />
      )}

      {customerProfile.account_status === 'suspended' && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex items-center gap-3 text-sm text-red-900">
          <ShieldAlert className="w-5 h-5 text-red-700 shrink-0" />
          <span>
            Your customer account is currently suspended by an administrator. Contact support for assistance.
          </span>
        </div>
      )}

      {feedback && (
        <div
          className={`p-3.5 rounded-xl text-xs border flex items-center justify-between gap-2 ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{feedback.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="text-xs font-medium underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* 3-Line Navigation Strip (1. Profile · 2. Address · 3. Ride Status) */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-2 grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={() => onSectionChange('profile')}
          className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-2 ${
            activeSection === 'profile'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <UserCheck className="w-4 h-4 shrink-0" />
          <span className="truncate">{t.menuProfile}</span>
        </button>
        <button
          type="button"
          onClick={() => onSectionChange('address')}
          className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-2 ${
            activeSection === 'address'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <MapPin className="w-4 h-4 shrink-0" />
          <span className="truncate">{t.menuAddress}</span>
        </button>
        <button
          type="button"
          onClick={() => onSectionChange('status')}
          className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-2 relative ${
            activeSection === 'status'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <Navigation className="w-4 h-4 shrink-0" />
          <span className="truncate">{t.menuRideStatus}</span>
          {activeRide && (
            <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" aria-label="Active ride" />
          )}
        </button>
      </div>

      {/* SECTION 1: CUSTOMER PROFILE */}
      {activeSection === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 bg-white border border-neutral-200 rounded-2xl p-6 space-y-5">
            <div className="flex items-center gap-4">
              <img
                src={
                  customerProfile.profile_image ||
                  '/src/assets/images/customer_avatar_sample_1795224014041.jpg'
                }
                alt={customerProfile.full_name}
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-full object-cover border border-neutral-200"
              />
              <div className="min-w-0">
                <p className="text-xs font-medium text-emerald-700">{t.customerTitle}</p>
                <h2 className="text-lg font-bold text-neutral-900 truncate">
                  {customerProfile.full_name}
                </h2>
                <p className="text-xs text-neutral-500 font-mono truncate">
                  {customerProfile.phone_number}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-neutral-100 text-xs">
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-neutral-500">Account Status</span>
                <p className="font-semibold text-emerald-700 capitalize mt-0.5">
                  {customerProfile.account_status}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-neutral-500">Completed Rides</span>
                <p className="font-mono tabular-nums font-bold text-neutral-900 text-base mt-0.5">
                  {completedRidesCount}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-neutral-500">City</span>
                <p className="font-semibold text-neutral-900 mt-0.5">
                  {customerProfile.default_city}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-neutral-500">{t.languageLabel}</span>
                <p className="font-semibold text-neutral-900 mt-0.5">
                  {language === 'as' ? 'অসমীয়া' : language === 'bn' ? 'বাংলা' : 'English'}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-neutral-500">{t.genderLabel}</span>
                <p className="font-semibold text-neutral-900 capitalize mt-0.5">
                  {customerProfile.gender === 'female'
                    ? t.genderFemale
                    : customerProfile.gender === 'other'
                      ? t.genderOther
                      : customerProfile.gender === 'male'
                        ? t.genderMale
                        : '—'}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <span className="text-neutral-500">{t.dobLabel}</span>
                <p className="font-mono font-semibold text-neutral-900 mt-0.5">
                  {customerProfile.date_of_birth || '—'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setEditingProfile(true)}
              className="w-full min-h-[44px] px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors"
            >
              Edit Profile / Upload Photo
            </button>
          </div>

          {/* Support & Complaints inside Profile */}
          <div className="lg:col-span-7 bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-900 flex items-center gap-2">
                <MessageSquareWarning className="w-4 h-4 text-neutral-500" />
                <span>{t.complaintsTitle}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowComplaintForm((prev) => !prev)}
                className="text-xs font-medium text-emerald-700 hover:underline"
              >
                {showComplaintForm ? 'Close' : 'Report Issue'}
              </button>
            </div>

            {showComplaintForm && (
              <form onSubmit={handleSubmitComplaint} className="space-y-3 pt-2 border-t border-neutral-100">
                <input
                  type="text"
                  value={complaintRideId}
                  onChange={(e) => setComplaintRideId(e.target.value)}
                  placeholder="Ride ID (optional)"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs font-mono"
                />
                <input
                  type="text"
                  required
                  minLength={3}
                  maxLength={120}
                  value={complaintSubject}
                  onChange={(e) => setComplaintSubject(e.target.value)}
                  placeholder="Subject (e.g. Overcharged fare or lost item)"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs"
                />
                <textarea
                  rows={2}
                  required
                  minLength={5}
                  maxLength={600}
                  value={complaintDesc}
                  onChange={(e) => setComplaintDesc(e.target.value)}
                  placeholder="Describe the issue clearly..."
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs"
                />
                <button
                  type="submit"
                  disabled={actionBusy === 'complaint'}
                  className="px-4 py-2 bg-neutral-900 text-white text-xs font-medium rounded-lg"
                >
                  {t.submitComplaint}
                </button>
              </form>
            )}

            {myComplaints.length === 0 ? (
              <p className="text-xs text-neutral-500 pt-2 border-t border-neutral-100">
                No complaints raised. Report an issue anytime if you need assistance.
              </p>
            ) : (
              <div className="divide-y divide-neutral-100 border-t border-neutral-100">
                {myComplaints.map((c) => (
                  <div key={c.complaint_id} className="py-2.5 text-xs space-y-0.5">
                    <div className="flex justify-between gap-2">
                      <span className="font-medium text-neutral-900">{c.subject}</span>
                      <span className="capitalize font-mono text-emerald-700">{c.status}</span>
                    </div>
                    {c.admin_notes && <p className="text-neutral-600">Admin: {c.admin_notes}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: ADDRESS & BOOKING MAP */}
      {activeSection === 'address' && (
        <div className="bg-white border border-neutral-200 rounded-2xl p-5 sm:p-6 space-y-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-xs font-medium text-emerald-700">
                {t.menuAddress} · {customerProfile.default_city}
              </p>
              <h2 className="text-xl font-bold text-neutral-900 mt-0.5">
                {t.pickupLocation} & {t.destinationSearch}
              </h2>
            </div>
            <span className="text-xs text-neutral-500 font-mono tabular-nums">
              {onlineDrivers.filter((d) => d.lat !== 0).length} e-rickshaws online
            </span>
          </div>

          {activeRide && (
            <div className="p-4 rounded-xl bg-neutral-900 text-white flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs">
                <p className="font-semibold text-emerald-400">
                  Active Ride: {activeRide.ride_status.replace('_', ' ').toUpperCase()}
                </p>
                <p className="text-neutral-300 mt-0.5 truncate">
                  {activeRide.pickup_address} → {activeRide.destination_address}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onSectionChange('status')}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg"
              >
                Open Ride Status
              </button>
            </div>
          )}

          <SmartRideMap
            apiKeyAvailable={mapsEnabled}
            center={mapDriverPoint || mapPickup}
            pickup={mapPickup}
            destination={mapDest}
            assignedDriver={mapDriverPoint}
            onlineDrivers={activeRide ? [] : onlineDrivers}
            routeOrigin={routeOrigin}
            routeDestination={routeDest}
            routeStrokeColor={
              activeRide && activeRide.ride_status === 'accepted' ? '#0f172a' : '#16a34a'
            }
            onMapClick={handleMapTap}
            onRouteComputed={handleRouteComputed}
            onRouteError={setRouteError}
          />

          {!activeRide && (
            <div className="space-y-3.5">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-neutral-500">
                  Search via Google Places or tap directly on the map:
                </span>
                <div className="inline-flex items-center gap-1 p-0.5 bg-neutral-100 rounded-lg border border-neutral-200">
                  <button
                    type="button"
                    onClick={() => setMapTapMode('pickup')}
                    className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                      mapTapMode === 'pickup'
                        ? 'bg-white text-emerald-700 shadow-sm'
                        : 'text-neutral-600'
                    }`}
                  >
                    Tap sets Pickup
                  </button>
                  <button
                    type="button"
                    onClick={() => setMapTapMode('destination')}
                    className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                      mapTapMode === 'destination'
                        ? 'bg-white text-neutral-900 shadow-sm'
                        : 'text-neutral-600'
                    }`}
                  >
                    Tap sets Drop
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <PlaceSearchInput
                  value={pickupText}
                  onChange={setPickupText}
                  onPlaceSelect={handlePickupPlaceSelect}
                  placeholder={t.pickupLocation}
                  mapsEnabled={mapsEnabled}
                  icon={<MapPin className="w-4 h-4 text-emerald-600 shrink-0" />}
                />
                <button
                  type="button"
                  onClick={handleDetectGps}
                  className="min-h-[44px] px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-medium rounded-xl flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <LocateFixed className="w-4 h-4" />
                  <span>GPS</span>
                </button>
              </div>

              <PlaceSearchInput
                value={destText}
                onChange={setDestText}
                onPlaceSelect={handleDestPlaceSelect}
                placeholder={t.destinationSearch}
                mapsEnabled={mapsEnabled}
                icon={<Navigation className="w-4 h-4 text-neutral-700 shrink-0" />}
              />

              {gpsStatus && <p className="text-xs text-neutral-500 font-mono">{gpsStatus}</p>}
              {routeError && <p className="text-xs text-red-600">{routeError}</p>}

              {routeMetrics && (
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 grid grid-cols-3 gap-3 text-center">
                  <div>
                    <p className="text-[11px] text-emerald-800">{t.distanceLabel}</p>
                    <p className="text-base font-bold font-mono tabular-nums text-neutral-900 mt-0.5">
                      {routeMetrics.distanceKm} km
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-emerald-800">{t.etaLabel}</p>
                    <p className="text-base font-bold font-mono tabular-nums text-neutral-900 mt-0.5">
                      {routeMetrics.durationMinutes} min
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-emerald-800">{t.estimatedFareLabel}</p>
                    <p className="text-base font-bold font-mono tabular-nums text-emerald-700 mt-0.5">
                      ₹{estimatedFare}
                    </p>
                  </div>
                </div>
              )}

              <button
                type="button"
                disabled={
                  bookingBusy ||
                  customerProfile.account_status === 'suspended' ||
                  !pickupPoint ||
                  !destPoint ||
                  !routeMetrics
                }
                onClick={() => void handleBookRide()}
                className="w-full min-h-[48px] px-4 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                <IndianRupee className="w-4 h-4" />
                <span>
                  {bookingBusy
                    ? 'Sending Request...'
                    : routeMetrics
                    ? `${t.bookRideBtn} · ₹${estimatedFare}`
                    : t.bookRideBtn}
                </span>
              </button>
            </div>
          )}

          {/* Live Admin-Controlled Fare Rates */}
          <div className="pt-3 border-t border-neutral-100 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-900">{t.liveRatesTitle}</h3>
              <span className="text-xs text-neutral-500">
                {fareSettings ? 'Synced from Admin Console' : 'Standard INR Tariff'}
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <p className="text-xs text-neutral-500">{t.baseFare}</p>
                <p className="text-lg font-bold font-mono tabular-nums text-neutral-900 mt-0.5">
                  ₹{effectiveRates.base_fare}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <p className="text-xs text-neutral-500">{t.perKm}</p>
                <p className="text-lg font-bold font-mono tabular-nums text-emerald-700 mt-0.5">
                  ₹{effectiveRates.price_per_km}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <p className="text-xs text-neutral-500">{t.minFare}</p>
                <p className="text-lg font-bold font-mono tabular-nums text-neutral-900 mt-0.5">
                  ₹{effectiveRates.minimum_fare}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                <p className="text-xs text-neutral-500">{t.waitingCharge}</p>
                <p className="text-lg font-bold font-mono tabular-nums text-neutral-900 mt-0.5">
                  ₹{effectiveRates.waiting_charge}/m
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: CUSTOMER & DRIVER RIDE STATUS */}
      {activeSection === 'status' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 space-y-5">
            {activeRide ? (
              <div className="bg-white border border-neutral-200 rounded-2xl p-5 space-y-4">
                <SmartRideMap
                  apiKeyAvailable={mapsEnabled}
                  center={mapDriverPoint || mapPickup}
                  pickup={mapPickup}
                  destination={mapDest}
                  assignedDriver={mapDriverPoint}
                  routeOrigin={routeOrigin}
                  routeDestination={routeDest}
                  routeStrokeColor={activeRide.ride_status === 'accepted' ? '#0f172a' : '#16a34a'}
                  heightClassName="h-[280px] sm:h-[340px]"
                  onRouteComputed={handleRouteComputed}
                />

                <div className="p-4 sm:p-5 rounded-2xl bg-neutral-900 text-white space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-medium text-emerald-400 uppercase tracking-wide">
                        Ride Status: {activeRide.ride_status.replace('_', ' ')}
                      </p>
                      <p className="text-sm font-semibold mt-0.5">
                        {activeRide.ride_status === 'requested' &&
                          'Finding nearby approved Electric Rickshaw drivers...'}
                        {activeRide.ride_status === 'accepted' &&
                          'Driver accepted! Heading to your pickup point.'}
                        {activeRide.ride_status === 'arrived' &&
                          'Your Electric Rickshaw has arrived at pickup.'}
                        {activeRide.ride_status === 'in_progress' &&
                          'Ride in progress towards destination.'}
                      </p>
                    </div>
                    <span className="font-mono text-lg font-bold tabular-nums text-emerald-400">
                      ₹{activeRide.estimated_fare}
                    </span>
                  </div>

                  {activeRide.driver_id ? (
                    <div className="p-3.5 rounded-xl bg-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={
                            activeRide.driver_photo ||
                            '/src/assets/images/driver_avatar_sample_1795224014527.jpg'
                          }
                          alt={activeRide.driver_name}
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded-full object-cover border border-neutral-700"
                        />
                        <div>
                          <p className="text-sm font-semibold text-white">
                            {activeRide.driver_name}
                          </p>
                          <p className="text-xs font-mono text-emerald-300 mt-0.5">
                            {activeRide.driver_vehicle_number} · Electric Rickshaw
                          </p>
                          {approachMetrics && activeRide.ride_status === 'accepted' && (
                            <p className="text-xs text-neutral-300 mt-0.5 tabular-nums">
                              Driver arrival: {approachMetrics.durationMinutes} min (
                              {approachMetrics.distanceKm} km away)
                            </p>
                          )}
                        </div>
                      </div>

                      {activeRide.driver_phone && (
                        <a
                          href={`tel:${activeRide.driver_phone}`}
                          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium rounded-lg inline-flex items-center justify-center gap-1.5 whitespace-nowrap"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>{activeRide.driver_phone}</span>
                        </a>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2.5 text-xs text-neutral-300 bg-neutral-800/80 px-3.5 py-2.5 rounded-xl">
                      <Loader2 className="w-4 h-4 text-emerald-400 animate-spin shrink-0" />
                      <span>
                        Broadcasting to {onlineDrivers.length} online approved drivers ·{' '}
                        {activeRide.distance_km} km ({activeRide.duration_minutes} mins)
                      </span>
                    </div>
                  )}

                  <div className="text-xs text-neutral-300 space-y-1 pt-1 border-t border-neutral-800">
                    <p className="truncate">
                      <span className="text-neutral-400">Pickup:</span> {activeRide.pickup_address}
                    </p>
                    <p className="truncate">
                      <span className="text-neutral-400">Drop:</span>{' '}
                      {activeRide.destination_address}
                    </p>
                  </div>

                  {(activeRide.ride_status === 'requested' ||
                    activeRide.ride_status === 'accepted') && (
                    <button
                      type="button"
                      disabled={actionBusy === `cancel_${activeRide.ride_id}`}
                      onClick={() => void handleCancelRide(activeRide)}
                      className="w-full min-h-[42px] px-4 py-2 bg-red-600/20 hover:bg-red-600/30 border border-red-500/40 text-red-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>{t.cancelRide}</span>
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-white border border-neutral-200 rounded-2xl p-6 text-center space-y-3">
                <Navigation className="w-6 h-6 text-emerald-600 mx-auto" />
                <h3 className="text-base font-bold text-neutral-900">
                  No Active Ride Right Now
                </h3>
                <p className="text-xs text-neutral-600 max-w-md mx-auto">
                  Go to <strong>{t.menuAddress}</strong> to set your pickup & destination address and book an Electric Rickshaw.
                </p>
                <button
                  type="button"
                  onClick={() => onSectionChange('address')}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl"
                >
                  Open {t.menuAddress}
                </button>
              </div>
            )}

            {unpaidCompletedRide && (
              <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-semibold text-amber-900">
                      Complete Payment for Ride {unpaidCompletedRide.ride_id}
                    </p>
                    <p className="text-xs text-amber-800 mt-0.5">
                      Driver: {unpaidCompletedRide.driver_name} (
                      {unpaidCompletedRide.driver_vehicle_number})
                    </p>
                  </div>
                  <span className="text-xl font-bold font-mono tabular-nums text-neutral-900">
                    ₹{unpaidCompletedRide.final_fare || unpaidCompletedRide.estimated_fare}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    disabled={actionBusy === `pay_${unpaidCompletedRide.ride_id}`}
                    onClick={() => void handleConfirmPayment(unpaidCompletedRide, 'cash')}
                    className="min-h-[44px] px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2"
                  >
                    <Banknote className="w-4 h-4" />
                    <span>{t.payCash}</span>
                  </button>
                  <button
                    type="button"
                    disabled={actionBusy === `pay_${unpaidCompletedRide.ride_id}`}
                    onClick={() => void handleConfirmPayment(unpaidCompletedRide, 'upi')}
                    className="min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>{t.payUpi}</span>
                  </button>
                </div>

                <a
                  href={buildUpiPaymentLink({
                    upiId: fareSettings?.admin_upi_id || 'smartride@upi',
                    payeeName:
                      fareSettings?.business_payee_name || 'Smart Ride Electric Rickshaw',
                    amount:
                      unpaidCompletedRide.final_fare || unpaidCompletedRide.estimated_fare,
                    note: unpaidCompletedRide.ride_id,
                    app: 'upi',
                  })}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-800 underline"
                >
                  Open installed UPI app (PhonePe / GPay / Amazon Pay / Paytm)
                </a>
              </div>
            )}

            {unratedCompletedRide && !unpaidCompletedRide && (
              <div className="p-5 rounded-2xl bg-white border border-neutral-200 space-y-3">
                <p className="text-sm font-semibold text-neutral-900">{t.rateRideTitle}</p>
                <p className="text-xs text-neutral-600">
                  {unratedCompletedRide.driver_name} ({unratedCompletedRide.driver_vehicle_number}) ·{' '}
                  {unratedCompletedRide.pickup_address} → {unratedCompletedRide.destination_address}
                </p>
                <div className="flex items-center gap-1.5">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRatingScore(star)}
                      className="p-1"
                      aria-label={`Rate ${star} stars`}
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= ratingScore
                            ? 'text-amber-500 fill-amber-500'
                            : 'text-neutral-300'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="ml-2 text-xs font-mono text-neutral-700">{ratingScore}/5</span>
                </div>
                <textarea
                  rows={2}
                  maxLength={500}
                  value={ratingFeedback}
                  onChange={(e) => setRatingFeedback(e.target.value)}
                  placeholder="Share feedback about ride comfort, punctuality, and safety..."
                  className="w-full px-3 py-2 border border-neutral-300 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                <button
                  type="button"
                  disabled={actionBusy === `rate_${unratedCompletedRide.ride_id}`}
                  onClick={() => void handleSubmitRating(unratedCompletedRide)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl"
                >
                  {t.submitRating}
                </button>
              </div>
            )}
          </div>

          <div className="lg:col-span-5 bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-900">{t.bookingHistory}</h3>
              <span className="text-xs font-mono tabular-nums text-neutral-500">
                {rides.length} rides
              </span>
            </div>

            {rides.length === 0 ? (
              <div className="py-6 text-center space-y-2 border-t border-neutral-100">
                <Clock className="w-5 h-5 text-neutral-400 mx-auto" />
                <p className="text-xs text-neutral-500">
                  No electric rickshaw rides booked yet.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-neutral-100 max-h-96 overflow-y-auto">
                {rides.map((r) => (
                  <div key={r.ride_id} className="py-3 flex items-start justify-between gap-3">
                    <div className="min-w-0 space-y-0.5">
                      <p className="text-xs font-medium text-neutral-900 truncate">
                        {r.pickup_address} → {r.destination_address}
                      </p>
                      <p className="text-xs text-neutral-500 tabular-nums">
                        {r.distance_km} km · {r.ride_status.replace('_', ' ')} ·{' '}
                        {r.payment_status === 'paid'
                          ? `Paid (${(r.payment_method || 'cash').toUpperCase()})`
                          : 'Unpaid'}
                      </p>
                      {r.driver_vehicle_number && (
                        <p className="text-[11px] font-mono text-neutral-600">
                          {r.driver_name} · {r.driver_vehicle_number}
                        </p>
                      )}
                    </div>
                    <span className="font-mono tabular-nums text-sm font-semibold text-neutral-900 shrink-0">
                      ₹{r.final_fare || r.estimated_fare}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
