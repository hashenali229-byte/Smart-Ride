import React, { useEffect, useRef, useState } from 'react';
import {
  ConfirmationResult,
  createUserWithEmailAndPassword,
  RecaptchaVerifier,
  sendEmailVerification,
  sendPasswordResetEmail,
  sendSignInLinkToEmail,
  signInWithEmailAndPassword,
  signInWithEmailLink,
  signInWithPhoneNumber,
  signInWithPopup,
} from 'firebase/auth';
import { Clock, Eye, EyeOff, Fingerprint, KeyRound, Mail, Phone, ShieldCheck } from 'lucide-react';
import {
  getRegisteredFingerprintMeta,
  verifyDeviceFingerprint,
} from '../lib/biometrics';
import {
  ADMIN_OTP_EMAIL_STORAGE_KEY,
  ADMIN_SESSION_EXPIRED_KEY,
  auth,
  googleProvider,
} from '../lib/firebase';
import { formatIndianPhone, isValidIndianPhone } from '../lib/validation';
import type { LanguageCode } from '../types/smartride';
import { TRANSLATIONS } from '../lib/i18n';

interface AuthGateCardProps {
  portalLabel: string;
  language: LanguageCode;
  allowPhoneOtp?: boolean;
  adminOnlyNotice?: boolean;
  sessionExpiredNotice?: boolean;
  pendingEmailLink?: string | null;
  onClearPendingEmailLink?: () => void;
}

export function AuthGateCard({
  portalLabel,
  language,
  allowPhoneOtp = true,
  adminOnlyNotice = false,
  sessionExpiredNotice = false,
  pendingEmailLink = null,
  onClearPendingEmailLink,
}: AuthGateCardProps) {
  const t = TRANSLATIONS[language];
  const [phoneDigits, setPhoneDigits] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [confirmation, setConfirmation] = useState<ConfirmationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [phoneConfigGuide, setPhoneConfigGuide] = useState(false);
  const [emailPasswordConfigGuide, setEmailPasswordConfigGuide] = useState(false);
  const [useVisibleCaptcha, setUseVisibleCaptcha] = useState(false);
  const [otpSentNotice, setOtpSentNotice] = useState<string | null>(null);
  const recaptchaContainerRef = useRef<HTMLDivElement | null>(null);
  const verifierRef = useRef<RecaptchaVerifier | null>(null);

  // Admin Gmail OTP / Email & Password + Fingerprint state (only shown when adminOnlyNotice is true)
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [emailAuthMode, setEmailAuthMode] = useState<'otp' | 'signin' | 'signup' | 'reset'>('otp');
  const [gmailOtpSent, setGmailOtpSent] = useState(false);
  const [gmailOtpLinkInput, setGmailOtpLinkInput] = useState(pendingEmailLink || '');
  const [adminAuthNotice, setAdminAuthNotice] = useState<string | null>(null);
  const [bioChecking, setBioChecking] = useState(false);
  const registeredBioMeta = adminOnlyNotice ? getRegisteredFingerprintMeta() : null;

  const hasExpiredFlag = (() => {
    if (sessionExpiredNotice) return true;
    try {
      return adminOnlyNotice && window.localStorage.getItem(ADMIN_SESSION_EXPIRED_KEY) === '1';
    } catch {
      return false;
    }
  })();

  useEffect(() => {
    if (pendingEmailLink) {
      setEmailAuthMode('otp');
      setGmailOtpSent(true);
      setGmailOtpLinkInput(pendingEmailLink);
    }
  }, [pendingEmailLink]);

  const cleanupVerifier = () => {
    if (verifierRef.current) {
      try {
        verifierRef.current.clear();
      } catch {
        // ignore cleanup
      }
      verifierRef.current = null;
    }
    if (recaptchaContainerRef.current) {
      recaptchaContainerRef.current.innerHTML = '';
    }
  };

  useEffect(() => {
    return () => {
      cleanupVerifier();
    };
  }, []);

  useEffect(() => {
    cleanupVerifier();
  }, [useVisibleCaptcha]);

  const [googleDomainHelp, setGoogleDomainHelp] = useState(false);

  const formatGoogleAuthError = (raw: string): string => {
    const isBn = language === 'bn';
    const isAs = language === 'as';
    if (raw.includes('popup-blocked')) {
      return isAs
        ? 'ব্ৰাউজাৰে Google লগইন পপ-আপ ব্লক কৰিছে। পপ-আপ অনুমতি দিয়ক বা নতুন ব্ৰাউজাৰ টেবত খোলক।'
        : isBn
          ? 'ব্রাউজার Google লগইন পপ-আপ ব্লক করেছে। অনুগ্রহ করে Pop-up Allow করুন বা নতুন ব্রাউজার ট্যাবে অ্যাপটি খুলুন।'
          : 'Your browser blocked the Google Sign-In popup. Please allow popups for this site and tap the button again.';
    }
    if (raw.includes('popup-closed-by-user') || raw.includes('cancelled-popup-request')) {
      return isAs
        ? 'Google লগইন পপ-আপ সম্পূৰ্ণ হোৱাৰ আগতেই বন্ধ কৰা হৈছে। অনুগ্ৰহ কৰি পুনৰ চেষ্টা কৰক।'
        : isBn
          ? 'Google লগইন পপ-আপ সম্পূর্ণ হওয়ার আগেই বন্ধ হয়ে গেছে। আবার ট্যাপ করে আপনার Google অ্যাকাউন্ট নির্বাচন করুন।'
          : 'The Google Sign-In window was closed before completing sign-in. Please tap again and choose your Google account.';
    }
    if (raw.includes('unauthorized-domain')) {
      setGoogleDomainHelp(true);
      return isAs
        ? `এই ডোমেইন (${window.location.hostname}) Firebase Authorized Domains-ত যোগ কৰা নাই।`
        : isBn
          ? `এই ডোমেইন (${window.location.hostname}) Firebase Authorized Domains-এ যোগ করা নেই।`
          : `Domain "${window.location.hostname}" is not listed under Firebase Authentication → Settings → Authorized domains.`;
    }
    if (raw.includes('operation-not-allowed')) {
      return isBn
        ? 'Firebase Console-এ Google Sign-In চালু করা নেই (Authentication → Sign-in method → Google Enable করুন)।'
        : 'Google Sign-In provider is disabled in Firebase Console (Authentication → Sign-in method → Google).';
    }
    if (raw.includes('network-request-failed')) {
      return isBn
        ? 'ইন্টারনেট সংযোগ ব্যর্থ হয়েছে। নেটওয়ার্ক চেক করে আবার চেষ্টা করুন।'
        : 'Network request failed. Check your internet connection and retry.';
    }
    return raw;
  };

  const formatEmailAuthError = (raw: string): string => {
    const isBn = language === 'bn';
    const isAs = language === 'as';
    if (raw.includes('operation-not-allowed') || raw.includes('admin-restricted-operation')) {
      setEmailPasswordConfigGuide(true);
      return isAs
        ? 'Firebase Console-ত Email/Password আৰু Email link (passwordless sign-in) অন কৰা নাই। তলৰ লিংকেৰে অন কৰক।'
        : isBn
          ? 'Firebase Console-এ Email/Password ও Email link (passwordless sign-in) এখনো চালু করা হয়নি। নিচের লিংকে গিয়ে চালু করুন।'
          : 'Email/Password & Email link (passwordless sign-in) must be enabled in Firebase Console first.';
    }
    if (raw.includes('invalid-action-code') || raw.includes('expired-action-code')) {
      return isBn
        ? 'Gmail OTP লিংকটির মেয়াদ শেষ বা আগেই ব্যবহৃত হয়েছে। অনুগ্রহ করে নতুন লিংক পাঠান।'
        : 'This Gmail OTP link has expired or was already used. Send a fresh Gmail OTP link.';
    }
    if (raw.includes('invalid-credential') || raw.includes('wrong-password') || raw.includes('user-not-found')) {
      return isAs
        ? 'ইমেইল বা পাছৱৰ্ড ভুল হৈছে। প্ৰথমবাৰ পাছৱৰ্ড লগইন কৰিলে "Set Pass" ট্যাব বাছনি কৰক।'
        : isBn
          ? 'Gmail বা Password সঠিক নয়। প্রথমবার Password তৈরি করতে চাইলে "Set Pass" মোড বেছে নিন, অথবা "Gmail OTP" দিয়ে ঢুকুন।'
          : 'Invalid Gmail or password. Use "Set Pass" if creating a password for the first time, or use "Gmail OTP".';
    }
    if (raw.includes('email-already-in-use')) {
      return isAs
        ? 'এই Gmail ত আগৰে পৰা একাউণ্ট আছে। এতিয়া "Password" বা "Gmail OTP" দি লগইন কৰক।'
        : isBn
          ? 'এই Gmail দিয়ে আগেই অ্যাকাউন্ট তৈরি আছে। এখন "Password" বা "Gmail OTP" দিয়ে লগইন করুন।'
          : 'An account already exists with this Gmail. Use "Password" or "Gmail OTP" to sign in.';
    }
    if (raw.includes('weak-password')) {
      return isBn
        ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।'
        : 'Password must be at least 6 characters long.';
    }
    if (raw.includes('too-many-requests')) {
      return isBn
        ? 'অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন বা Google দিয়ে লগইন করুন।'
        : 'Too many attempts. Wait a few minutes or use Admin Google Sign-In.';
    }
    return raw;
  };

  const clearExpiredFlag = () => {
    try {
      window.localStorage.removeItem(ADMIN_SESSION_EXPIRED_KEY);
    } catch {
      // Ignore storage access errors
    }
  };

  const handleAdminEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setAdminAuthNotice(null);
    setEmailPasswordConfigGuide(false);
    const cleanEmail = adminEmail.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setErrorMsg(
        language === 'bn' ? 'সঠিক Gmail ঠিকানা লিখুন।' : 'Enter a valid Gmail address.'
      );
      return;
    }

    setLoading(true);
    try {
      if (emailAuthMode === 'otp') {
        await sendSignInLinkToEmail(auth, cleanEmail, {
          url: `${window.location.origin}/?adminOtp=1`,
          handleCodeInApp: true,
        });
        try {
          window.localStorage.setItem(ADMIN_OTP_EMAIL_STORAGE_KEY, cleanEmail);
        } catch {
          // Ignore storage restrictions
        }
        setGmailOtpSent(true);
        setAdminAuthNotice(
          language === 'as'
            ? `${cleanEmail} লৈ Gmail OTP লগইন লিংক পঠিওৱা হৈছে। Gmail খুলি লিংকত টেপ কৰক বা লিংক কপি কৰি তলত পেষ্ট কৰক।`
            : language === 'bn'
              ? `${cleanEmail}-এ একটি Gmail OTP লগইন লিংক পাঠানো হয়েছে! Gmail ইনবক্স (বা Spam) খুলে লিংকটিতে ট্যাপ করুন, অথবা লিংক কপি করে নিচে পেস্ট করুন।`
              : `One-time Gmail OTP link sent to ${cleanEmail}! Tap the link in your Gmail inbox, or copy & paste it below.`
        );
        return;
      }

      if (emailAuthMode === 'reset') {
        await sendPasswordResetEmail(auth, cleanEmail);
        setAdminAuthNotice(
          language === 'as'
            ? `${cleanEmail} লৈ পাছৱৰ্ড ৰিছেট লিংক পঠিওৱা হৈছে।`
            : language === 'bn'
              ? `${cleanEmail}-এ পাসওয়ার্ড রিসেট লিংক পাঠানো হয়েছে। Gmail ইনবক্স বা Spam ফোল্ডার দেখুন।`
              : `Password reset email sent to ${cleanEmail}. Check your Gmail inbox.`
        );
        return;
      }

      if (adminPassword.length < 6) {
        setErrorMsg(
          language === 'bn'
            ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।'
            : 'Password must be at least 6 characters.'
        );
        return;
      }

      if (emailAuthMode === 'signup') {
        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, adminPassword);
        clearExpiredFlag();
        try {
          await sendEmailVerification(cred.user);
        } catch {
          // Ignore verification email rate-limit if already triggered
        }
        setAdminAuthNotice(
          language === 'bn'
            ? 'অ্যাকাউন্ট তৈরি হয়েছে এবং ভেরিফিকেশন ইমেইল পাঠানো হয়েছে। অনুগ্রহ করে Gmail ভেরিফাই করুন।'
            : 'Admin password account created and verification email sent to your Gmail.'
        );
      } else {
        await signInWithEmailAndPassword(auth, cleanEmail, adminPassword);
        clearExpiredFlag();
      }
    } catch (err) {
      const raw = err instanceof Error ? err.message : String(err);
      setErrorMsg(formatEmailAuthError(raw));
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteGmailOtpLink = async () => {
    setErrorMsg(null);
    setAdminAuthNotice(null);
    const cleanEmail = adminEmail.trim().toLowerCase();
    const cleanLink = gmailOtpLinkInput.trim();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setErrorMsg(
        language === 'bn'
          ? 'প্রথমে উপরে আপনার Admin Gmail লিখুন।'
          : 'Enter your Admin Gmail address above first.'
      );
      return;
    }
    if (!cleanLink) {
      setErrorMsg(
        language === 'bn'
          ? 'Gmail থেকে পাওয়া OTP লগইন লিংকটি পেস্ট করুন।'
          : 'Paste the one-time login link received in your Gmail.'
      );
      return;
    }

    setLoading(true);
    try {
      await signInWithEmailLink(auth, cleanEmail, cleanLink);
      clearExpiredFlag();
      try {
        window.localStorage.removeItem(ADMIN_OTP_EMAIL_STORAGE_KEY);
      } catch {
        // Ignore storage errors
      }
      onClearPendingEmailLink?.();
    } catch (err) {
      const raw = err instanceof Error ? err.message : String(err);
      setErrorMsg(formatEmailAuthError(raw));
    } finally {
      setLoading(false);
    }
  };

  const handleTestFingerprintQuick = async () => {
    setErrorMsg(null);
    setAdminAuthNotice(null);
    setBioChecking(true);
    try {
      const res = await verifyDeviceFingerprint();
      if (res.ok) {
        setAdminAuthNotice(
          language === 'as'
            ? 'ফিঙ্গাৰপ্ৰিণ্ট যাচাই সফল! এতিয়া Admin Gmail/Password, Gmail OTP বা Google এৰে ছাইন-ইন কৰক।'
            : language === 'bn'
              ? 'ফিঙ্গারপ্রিন্ট যাচাই সফল হয়েছে! সেশন নিশ্চিত করতে আপনার Admin Gmail OTP, Password অথবা Google দিয়ে সাইন ইন করুন।'
              : 'Device fingerprint verified! Complete sign-in with Gmail OTP, Password, or Google account.'
        );
      } else if (res.error) {
        setErrorMsg(res.error);
      }
    } finally {
      setBioChecking(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMsg(null);
    setPhoneConfigGuide(false);
    setEmailPasswordConfigGuide(false);
    setGoogleDomainHelp(false);
    setOtpSentNotice(null);
    setAdminAuthNotice(null);
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
      clearExpiredFlag();
    } catch (err) {
      const raw = err instanceof Error ? err.message : 'Google sign-in failed.';
      setErrorMsg(formatGoogleAuthError(raw));
    } finally {
      setLoading(false);
    }
  };

  const formatPhoneAuthError = (raw: string): string => {
    const isBn = language === 'bn';
    const isAs = language === 'as';
    if (raw.includes('operation-not-allowed') || raw.includes('configuration-not-found')) {
      return isAs
        ? 'Firebase Console-ত Phone OTP সক্ৰিয় কৰা নাই। তলৰ পদক্ষেপসমূহ অনুসৰণ কৰক বা ওপৰৰ Google ছাইন-আপ ব্যৱহাৰ কৰক।'
        : isBn
          ? 'Firebase Console-এ Phone OTP চালু করা নেই। নিচের ধাপ অনুসরণ করে Authentication → Sign-in method → Phone Enable করুন, অথবা "Continue with Google" ব্যবহার করুন।'
          : 'Firebase Phone Authentication is not enabled yet in Firebase Console (Authentication → Sign-in method → Phone). Enable it or use Google Sign-In above.';
    }
    if (raw.includes('billing-not-enabled') || raw.includes('quota-exceeded')) {
      return isAs
        ? 'SMS OTP পঠাবলৈ নিজস্ব Blaze Firebase প্ৰজেক্টৰ প্ৰয়োজন, নহ’লে ওপৰৰ Google বুটাম ব্যৱহাৰ কৰক।'
        : isBn
          ? 'রিয়েল SMS OTP পাঠাতে Firebase প্রজেক্টে Blaze প্ল্যান লাগে, অথবা বিনামূল্যে টেস্ট করতে Firebase Console → Phone → "Phone numbers for testing"-এ টেস্ট নম্বর যোগ করুন।'
          : 'Real SMS OTP requires a Firebase Blaze plan (or free testing via Authentication → Phone → "Phone numbers for testing" in Firebase Console).';
    }
    if (raw.includes('unauthorized-domain')) {
      return isBn
        ? `এই ডোমেইনটি (${window.location.hostname}) Firebase Authorized Domains-এ যোগ করা নেই।`
        : `Domain "${window.location.hostname}" is not listed under Firebase Authentication → Settings → Authorized domains.`;
    }
    if (raw.includes('captcha-check-failed') || raw.includes('invalid-app-credential')) {
      return isBn
        ? 'reCAPTCHA যাচাই ব্যর্থ হয়েছে। নিচের "Use visible reCAPTCHA checkbox" চালু করে আবার চেষ্টা করুন এবং Authorized Domains চেক করুন।'
        : 'reCAPTCHA verification failed. Enable "Use visible reCAPTCHA checkbox" below and verify your domain is in Firebase Authorized domains.';
    }
    if (raw.includes('too-many-requests')) {
      return isBn
        ? 'অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ অপেক্ষা করুন অথবা Google Sign-In ব্যবহার করুন।'
        : 'Too many OTP attempts. Please wait a few minutes or sign in with Google.';
    }
    return raw;
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setPhoneConfigGuide(false);
    setOtpSentNotice(null);

    const formatted = formatIndianPhone(phoneDigits);
    if (!isValidIndianPhone(formatted)) {
      setErrorMsg(
        language === 'as'
          ? '৬–৯ ৰে আৰম্ভ হোৱা সঠিক ১০টা অংকৰ ভাৰতীয় মোবাইল নম্বৰ দিয়ক।'
          : language === 'bn'
            ? '৬–৯ দিয়ে শুরু হওয়া সঠিক ১০ ডিজিটের ভারতীয় মোবাইল নম্বর দিন।'
            : 'Enter a valid 10-digit Indian mobile number starting with 6–9.'
      );
      return;
    }

    setLoading(true);
    try {
      cleanupVerifier();
      if (!recaptchaContainerRef.current) {
        throw new Error('reCAPTCHA container could not be initialized.');
      }
      verifierRef.current = new RecaptchaVerifier(
        auth,
        recaptchaContainerRef.current,
        { size: useVisibleCaptcha ? 'normal' : 'invisible' }
      );
      await verifierRef.current.render();
      const result = await signInWithPhoneNumber(auth, formatted, verifierRef.current);
      setConfirmation(result);
      setOtpSentNotice(
        language === 'as'
          ? `${formatted} নম্বৰলৈ ৬ অংকৰ OTP পঠিওৱা হৈছে।`
          : language === 'bn'
            ? `${formatted} নম্বরে ৬ ডিজিটের OTP পাঠানো হয়েছে।`
            : `6-digit OTP sent to ${formatted}.`
      );
    } catch (err) {
      const raw = err instanceof Error ? err.message : String(err);
      if (
        raw.includes('operation-not-allowed') ||
        raw.includes('configuration-not-found') ||
        raw.includes('invalid-app-credential') ||
        raw.includes('captcha-check-failed') ||
        raw.includes('billing-not-enabled') ||
        raw.includes('unauthorized-domain') ||
        raw.includes('quota-exceeded')
      ) {
        setPhoneConfigGuide(true);
      }
      setErrorMsg(formatPhoneAuthError(raw));
      cleanupVerifier();
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmation) return;
    setErrorMsg(null);
    setLoading(true);
    try {
      await confirmation.confirm(otpCode.trim());
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Invalid OTP code.');
    } finally {
      setLoading(false);
    }
  };

  const [showPhoneForm, setShowPhoneForm] = useState(false);

  return (
    <div className="bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 max-w-md w-full mx-auto space-y-5">
      <div className="flex items-center gap-3.5">
        <img
          src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
          alt="Smart Ride Logo"
          referrerPolicy="no-referrer"
          className="w-12 h-12 rounded-xl object-cover border border-neutral-200 shrink-0"
        />
        <div>
          <p className="text-xs font-medium text-emerald-700">{t.welcomeHeadline}</p>
          <h2 className="text-xl font-bold text-neutral-900 tracking-tight">
            {portalLabel} · {t.signIn}
          </h2>
        </div>
      </div>

      {adminOnlyNotice && hasExpiredFlag && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-2.5 text-amber-950">
          <Clock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <p className="text-xs leading-relaxed">
            {language === 'as'
              ? 'আপোনাৰ ১২ ঘণ্টীয়া Admin লগইন ম্যাদ শেষ হোৱা বাবে স্বয়ংক্ৰিয়ভাৱে লগআউট কৰা হৈছে। অনুগ্ৰহ কৰি পুনৰ ছাইন-ইন কৰক।'
              : language === 'bn'
                ? 'আপনার ১২ ঘণ্টার Admin লগইন মেয়াদ শেষ হওয়ায় নিরাপত্তার জন্য স্বয়ংক্রিয়ভাবে লগআউট করা হয়েছে। অনুগ্রহ করে আবার সাইন-ইন করুন।'
                : 'Your 12-hour Admin session expired and was automatically logged out for security. Please sign in again.'}
          </p>
        </div>
      )}

      {adminOnlyNotice && (
        <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
          <p className="text-xs text-neutral-600 leading-relaxed">
            {language === 'as'
              ? 'Admin পেনেলত সোমাবলৈ আপোনাৰ অনুমোদিত Admin Gmail OTP, Password বা Google একাউণ্টেৰে ছাইন-ইন কৰক। প্ৰতি ১২ ঘণ্টা পাছত স্বয়ংক্ৰিয়ভাৱে লগআউট হ’ব।'
              : language === 'bn'
                ? 'Admin প্যানেলে প্রবেশ করতে আপনার অনুমোদিত Admin Gmail OTP, Password অথবা Google অ্যাকাউন্ট দিয়ে সাইন-ইন করুন। লগইন প্রতি ১২ ঘণ্টা পর স্বয়ংক্রিয়ভাবে লগআউট হবে।'
                : 'Sign in using Admin Gmail OTP, Gmail & Password, or Admin Google Account. Admin sessions automatically log out after 12 hours.'}
          </p>
        </div>
      )}

      <div className="space-y-2">
        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full min-h-[48px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-sm font-semibold rounded-xl transition-colors flex items-center justify-center gap-2.5 shadow-sm"
        >
          <KeyRound className="w-4 h-4" />
          <span>
            {loading
              ? language === 'bn'
                ? 'সাইন ইন হচ্ছে...'
                : 'Signing in...'
              : adminOnlyNotice
                ? language === 'as'
                  ? 'Admin Google একাউণ্টেৰে ছাইন ইন কৰক'
                  : language === 'bn'
                    ? 'Admin Google অ্যাকাউন্ট দিয়ে সাইন ইন করুন'
                    : 'Sign In with Admin Google Account'
                : language === 'as'
                  ? `${t.continueGoogle}`
                  : language === 'bn'
                    ? `${t.continueGoogle} (OTP ছাড়াই দ্রুত সাইন আপ)`
                    : `${t.continueGoogle} (Instant Sign Up)`}
          </span>
        </button>
        {!adminOnlyNotice && (
          <p className="text-[11px] text-neutral-500 text-center leading-relaxed">
            {language === 'as'
              ? 'ছাইন আপ কৰাৰ পিছত আপোনাৰ +৯১ মোবাইল নম্বৰ যোগ কৰিব পাৰিব।'
              : language === 'bn'
                ? 'সাইন আপ করার পর আপনার +91 মোবাইল নম্বর যোগ করতে পারবেন।'
                : 'Sign up in 1 tap and enter your +91 mobile number on your profile.'}
          </p>
        )}
      </div>

      {adminOnlyNotice && (
        <div className="pt-3 border-t border-neutral-200 space-y-3.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-emerald-700" />
              <span>
                {language === 'as'
                  ? 'Admin Gmail OTP / Password'
                  : language === 'bn'
                    ? 'Admin Gmail OTP ও Password'
                    : 'Admin Gmail OTP & Password'}
              </span>
            </span>

            <div className="inline-flex items-center p-0.5 bg-neutral-100 rounded-lg border border-neutral-200 text-[11px]">
              <button
                type="button"
                onClick={() => {
                  setEmailAuthMode('otp');
                  setErrorMsg(null);
                  setAdminAuthNotice(null);
                }}
                className={`px-2 py-1 rounded-md font-medium ${
                  emailAuthMode === 'otp'
                    ? 'bg-white text-emerald-700 shadow-sm'
                    : 'text-neutral-600'
                }`}
              >
                Gmail OTP
              </button>
              <button
                type="button"
                onClick={() => {
                  setEmailAuthMode('signin');
                  setErrorMsg(null);
                  setAdminAuthNotice(null);
                }}
                className={`px-2 py-1 rounded-md font-medium ${
                  emailAuthMode === 'signin'
                    ? 'bg-white text-neutral-900 shadow-sm'
                    : 'text-neutral-600'
                }`}
              >
                Password
              </button>
              <button
                type="button"
                onClick={() => {
                  setEmailAuthMode('signup');
                  setErrorMsg(null);
                  setAdminAuthNotice(null);
                }}
                className={`px-2 py-1 rounded-md font-medium ${
                  emailAuthMode === 'signup'
                    ? 'bg-white text-neutral-900 shadow-sm'
                    : 'text-neutral-600'
                }`}
              >
                Set Pass
              </button>
              <button
                type="button"
                onClick={() => {
                  setEmailAuthMode('reset');
                  setErrorMsg(null);
                  setAdminAuthNotice(null);
                }}
                className={`px-2 py-1 rounded-md font-medium ${
                  emailAuthMode === 'reset'
                    ? 'bg-white text-neutral-900 shadow-sm'
                    : 'text-neutral-600'
                }`}
              >
                Reset
              </button>
            </div>
          </div>

          <form onSubmit={handleAdminEmailAuth} className="space-y-2.5">
            <input
              type="email"
              required
              autoComplete="email"
              value={adminEmail}
              onChange={(e) => setAdminEmail(e.target.value)}
              placeholder="Authorized Admin Gmail"
              className="w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm text-neutral-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />

            {(emailAuthMode === 'signin' || emailAuthMode === 'signup') && (
              <div className="relative">
                <input
                  type={showAdminPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  autoComplete={emailAuthMode === 'signup' ? 'new-password' : 'current-password'}
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder={
                    emailAuthMode === 'signup'
                      ? 'Create Admin Password (min 6 chars)'
                      : 'Admin Password'
                  }
                  className="w-full pl-3.5 pr-10 py-2.5 border border-neutral-300 rounded-xl text-sm text-neutral-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                <button
                  type="button"
                  onClick={() => setShowAdminPassword((p) => !p)}
                  aria-label={showAdminPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-neutral-500 hover:text-neutral-900"
                >
                  {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[44px] px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 text-white text-xs font-semibold rounded-xl transition-colors"
            >
              {loading
                ? 'Processing...'
                : emailAuthMode === 'otp'
                  ? language === 'as'
                    ? 'Gmail লৈ OTP লগইন লিংক পঠাওক'
                    : language === 'bn'
                      ? 'Gmail-এ OTP লগইন লিংক পাঠান'
                      : 'Send Gmail OTP Login Link'
                  : emailAuthMode === 'reset'
                    ? language === 'bn'
                      ? 'পাসওয়ার্ড রিসেট লিংক পাঠান'
                      : 'Send Password Reset Link'
                    : emailAuthMode === 'signup'
                      ? language === 'bn'
                        ? 'পাসওয়ার্ড সেট করুন ও ভেরিফাই ইমেইল পাঠান'
                        : 'Create Admin Password & Send Verification'
                      : language === 'bn'
                        ? 'Gmail ও Password দিয়ে লগইন করুন'
                        : 'Sign In with Gmail & Password'}
            </button>
          </form>

          {emailAuthMode === 'otp' && (
            <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[11px] font-medium text-neutral-700">
                  {language === 'bn'
                    ? 'Gmail থেকে লিংকটি কপি করে এখানে পেস্ট করেও লগইন করতে পারবেন:'
                    : 'Or paste the Gmail OTP link received in your inbox:'}
                </p>
                {!gmailOtpSent && (
                  <button
                    type="button"
                    onClick={() => setGmailOtpSent(true)}
                    className="text-[11px] font-semibold text-emerald-700 hover:underline shrink-0"
                  >
                    Paste Link
                  </button>
                )}
              </div>

              {(gmailOtpSent || gmailOtpLinkInput.length > 0) && (
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="url"
                    value={gmailOtpLinkInput}
                    onChange={(e) => setGmailOtpLinkInput(e.target.value)}
                    placeholder="https://...?apiKey=...&oobCode=..."
                    className="flex-1 px-3 py-2 border border-neutral-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                  <button
                    type="button"
                    disabled={loading || !gmailOtpLinkInput.trim()}
                    onClick={() => void handleCompleteGmailOtpLink()}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg whitespace-nowrap"
                  >
                    {language === 'bn' ? 'OTP যাচাই করুন' : 'Verify Gmail OTP'}
                  </button>
                </div>
              )}
            </div>
          )}

          {registeredBioMeta && (
            <button
              type="button"
              disabled={bioChecking}
              onClick={() => void handleTestFingerprintQuick()}
              className="w-full min-h-[42px] px-4 py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <Fingerprint className="w-4 h-4 text-emerald-700" />
              <span>
                {bioChecking
                  ? 'Scanning Fingerprint...'
                  : language === 'bn'
                    ? 'ডিভাইস ফিঙ্গারপ্রিন্ট যাচাই করুন'
                    : 'Verify Registered Fingerprint'}
              </span>
            </button>
          )}
        </div>
      )}

      {adminAuthNotice && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 leading-relaxed">
          {adminAuthNotice}
        </div>
      )}

      {allowPhoneOtp && (
        <div className="pt-2 border-t border-neutral-200 space-y-3">
          <button
            type="button"
            onClick={() => setShowPhoneForm((prev) => !prev)}
            className="w-full text-left text-xs font-medium text-neutral-600 hover:text-neutral-900 flex items-center justify-between py-1"
          >
            <span className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-neutral-500" />
              <span>
                {language === 'as'
                  ? '+91 Phone OTP লগইন (Blaze Firebase প্ৰজেক্টৰ বাবে)'
                  : language === 'bn'
                    ? '+91 Phone OTP লগইন (শুধু নিজস্ব Blaze Firebase প্রজেক্টের জন্য)'
                    : '+91 Phone OTP Sign Up (Requires Blaze Firebase project)'}
              </span>
            </span>
            <span className="text-[11px] text-emerald-700 font-semibold">
              {showPhoneForm ? 'Hide' : 'Open'}
            </span>
          </button>

          {showPhoneForm && (
            <>
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-950 leading-relaxed">
                {language === 'as'
                  ? 'বিনামূলীয়া Starter Firebase প্ৰজেক্টত Phone OTP উপলব্ধ নহয়। ওপৰৰ Google বুটাম ব্যৱহাৰ কৰক।'
                  : language === 'bn'
                    ? 'ফ্রি AI Studio Firebase প্রজেক্টে Phone OTP / Test Number সেভ করা যায় না। Phone OTP ব্যবহার করতে চাইলে আপনার নিজের Google Cloud Blaze বিলিং-সহ একটি Firebase প্রজেক্টে Phone চালু থাকতে হবে; নাহলে উপরের Google বাটন দিয়ে লগইন করুন।'
                    : 'Free AI Studio Starter Firebase projects only enable Google Sign-In and do not permit saving Phone OTP / Test Numbers. Use your own Blaze-billed Firebase project for live SMS OTP, or use Google Sign Up above.'}
              </div>

              {!confirmation ? (
                <form onSubmit={handleSendOtp} className="space-y-3">
                  <label className="block">
                    <span className="text-xs font-medium text-neutral-700">
                      {t.phoneNumberLabel}
                    </span>
                    <div className="mt-1.5 flex items-center border border-neutral-300 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-emerald-600 focus-within:border-emerald-600">
                      <span className="px-3 py-2.5 bg-neutral-50 border-r border-neutral-200 text-sm font-mono font-medium text-neutral-700">
                        +91
                      </span>
                      <input
                        type="tel"
                        inputMode="numeric"
                        maxLength={10}
                        value={phoneDigits}
                        onChange={(e) => setPhoneDigits(e.target.value.replace(/\D/g, ''))}
                        placeholder="9876543210"
                        className="w-full px-3 py-2.5 text-sm font-mono text-neutral-900 bg-white focus:outline-none"
                        required
                      />
                    </div>
                  </label>

                  <label className="flex items-center gap-2 text-xs text-neutral-600 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={useVisibleCaptcha}
                      onChange={(e) => setUseVisibleCaptcha(e.target.checked)}
                      className="rounded border-neutral-300 text-emerald-600 focus:ring-emerald-600"
                    />
                    <span>
                      {language === 'bn'
                        ? 'ভিজিবল reCAPTCHA বক্স ব্যবহার করুন (OTP না এলে টিক দিন)'
                        : 'Use visible reCAPTCHA checkbox (check if OTP fails)'}
                    </span>
                  </label>

                  <div ref={recaptchaContainerRef} className="overflow-x-auto" />

                  <button
                    type="submit"
                    disabled={loading || phoneDigits.length !== 10}
                    className="w-full min-h-[44px] px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 text-white text-sm font-medium rounded-xl transition-colors flex items-center justify-center gap-2"
                  >
                    <Phone className="w-4 h-4" />
                    <span>{loading ? (language === 'bn' ? 'পাঠানো হচ্ছে...' : 'Sending OTP...') : t.sendOtp}</span>
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-3">
                  {otpSentNotice && (
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
                      {otpSentNotice}
                    </div>
                  )}
                  <label className="block">
                    <span className="text-xs font-medium text-neutral-700">
                      Enter 6-digit OTP sent to +91{phoneDigits}
                    </span>
                    <input
                      type="text"
                      inputMode="numeric"
                      maxLength={6}
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                      placeholder="123456"
                      className="mt-1.5 w-full px-3 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono tracking-widest text-neutral-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                      required
                    />
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setConfirmation(null);
                        setOtpCode('');
                        setOtpSentNotice(null);
                        cleanupVerifier();
                      }}
                      className="px-4 py-2.5 border border-neutral-300 text-neutral-700 text-sm font-medium rounded-xl hover:bg-neutral-50"
                    >
                      Change
                    </button>
                    <button
                      type="submit"
                      disabled={loading || otpCode.length !== 6}
                      className="flex-1 min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-medium rounded-xl transition-colors"
                    >
                      {loading ? 'Verifying...' : t.verifyOtp}
                    </button>
                  </div>
                </form>
              )}
            </>
          )}
        </div>
      )}

      {errorMsg && (
        <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 space-y-1.5">
          <p className="font-medium">Authentication Notice</p>
          <p className="break-words">{errorMsg}</p>
        </div>
      )}

      {googleDomainHelp && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-1.5 leading-relaxed">
          <p className="font-semibold">Authorized Domain Setup (Google Sign-In):</p>
          <p>
            Open{' '}
            <a
              href="https://console.firebase.google.com/project/round-dreamer-3q7xb/authentication/settings"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold"
            >
              Firebase Authentication → Settings → Authorized domains
            </a>{' '}
            and add <span className="font-mono">{window.location.hostname}</span>.
          </p>
        </div>
      )}

      {emailPasswordConfigGuide && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-1.5 leading-relaxed">
          <p className="font-semibold">
            {language === 'bn'
              ? 'Email/Password ও Gmail OTP লিংক চালু করার নিয়ম (Firebase Console):'
              : 'Enable Email/Password & Gmail OTP Link in Firebase Console:'}
          </p>
          <p>
            1. Open{' '}
            <a
              href="https://console.firebase.google.com/project/round-dreamer-3q7xb/authentication/providers"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold"
            >
              Firebase Authentication → Sign-in method
            </a>{' '}
            for project <span className="font-mono">round-dreamer-3q7xb</span>.
          </p>
          <p>
            2. Click <strong>Email/Password</strong> → Toggle <strong>Enable</strong> ON and also toggle{' '}
            <strong>Email link (passwordless sign-in)</strong> ON → click <strong>Save</strong>.
          </p>
        </div>
      )}

      {phoneConfigGuide && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-1.5 leading-relaxed">
          <p className="font-semibold">Firebase Console Setup for +91 Phone OTP:</p>
          <p>
            1. Open{' '}
            <a
              href="https://console.firebase.google.com/project/round-dreamer-3q7xb/authentication/providers"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold"
            >
              Firebase Authentication Providers
            </a>{' '}
            for project <span className="font-mono">round-dreamer-3q7xb</span>.
          </p>
          <p>2. Click <strong>Phone</strong> → Enable it and Save. (Note: free AI Studio Starter Tier projects without a Blaze billing account cannot enable Phone SMS or Test Numbers.)</p>
          <p>
            3. Under{' '}
            <a
              href="https://console.firebase.google.com/project/round-dreamer-3q7xb/authentication/settings"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold"
            >
              Authentication → Settings → Authorized domains
            </a>
            , ensure <span className="font-mono">{window.location.hostname}</span> is listed.
          </p>
        </div>
      )}
    </div>
  );
}
