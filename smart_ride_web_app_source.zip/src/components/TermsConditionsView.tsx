import React, { useState } from 'react';
import { CheckCircle2, FileText, ShieldCheck } from 'lucide-react';
import type { LanguageCode } from '../types/smartride';

interface TermsConditionsViewProps {
  language: LanguageCode;
  userRoleLabel: 'Customer' | 'Driver';
}

const TERMS_ACCEPT_KEY = 'smart_ride_terms_accepted_v1';

export function TermsConditionsView({ language, userRoleLabel }: TermsConditionsViewProps) {
  const [accepted, setAccepted] = useState<boolean>(() => {
    try {
      return window.localStorage.getItem(TERMS_ACCEPT_KEY) === 'true';
    } catch {
      return false;
    }
  });

  const handleAccept = () => {
    setAccepted(true);
    try {
      window.localStorage.setItem(TERMS_ACCEPT_KEY, 'true');
    } catch {
      // Ignore storage errors
    }
  };

  const isBn = language === 'bn';
  const isAs = language === 'as';

  const title = isAs
    ? 'স্মাৰ্ট ৰাইড এপৰ চৰ্তাৱলী আৰু নিয়মাৱলী'
    : isBn
      ? 'স্মার্ট রাইড অ্যাপের শর্তাবলী ও নিয়মকানুন'
      : 'Smart Ride App Terms & Conditions';

  const subtitle = isAs
    ? 'গ্ৰাহক আৰু চালক দুয়োৰে নিৰাপদ যাত্ৰাৰ বাবে এই নিয়মসমূহ প্ৰযোজ্য।'
    : isBn
      ? 'কাস্টমার এবং ড্রাইভার উভয়ের নিরাপদ ও স্বচ্ছ পরিষেবার জন্য এই শর্তাবলী প্রযোজ্য।'
      : 'These terms govern safe bookings, verified driving, INR fares, and privacy for all Customers & Drivers.';

  const clauses = isAs
    ? [
        {
          heading: '১. সঠিক তথ্য আৰু বয়সৰ নিয়ম',
          body: 'ৰেজিস্ট্ৰেচনৰ সময়ত গ্ৰাহক (ন্যূনতম ১৩ বছৰ) আৰু চালকে (ন্যূনতম ১৮ বছৰ) নিজৰ সঠিক নাম, লিংগ, জন্ম তাৰিখ আৰু ভাৰতীয় মোবাইল নম্বৰ (+৯১) দিব লাগিব।',
        },
        {
          heading: '২. চালকৰ নথিপত্ৰ আৰু বাহন যাচাই',
          body: 'চালকৰ বাবে বৈধ ভাৰতীয় বাহন নম্বৰ, বৈধ ড্ৰাইভিং লাইচেঞ্চ (DL) আৰু পঞ্জীয়ন পত্ৰ (RC) বাধ্যতামূলক। ভুৱা নথিপত্ৰ দিলে একাউণ্ট বাতিল কৰা হ’ব।',
        },
        {
          heading: '৩. পঞ্জীয়ন মাচুল আৰু ভাড়াৰ নিয়ম',
          body: 'চালকে নিৰ্ধাৰিত পঞ্জীয়ন মাচুল PhonePe, GPay, Amazon Pay, Paytm বা কাৰ্যালয়ত নগদ পৰিশোধ কৰিব পাৰিব। সকলো যাত্ৰাৰ ভাড়া চৰকাৰী বা এডমিন নিৰ্ধাৰিত ₹ হাৰত হিচাপ কৰা হয়।',
        },
        {
          heading: '৪. নিৰাপত্তা, আচৰণ আৰু গোপনীয়তা',
          body: 'যাত্ৰী আৰু চালক উভয়ে শালীন আচৰণ বজাই ৰাখিব লাগিব। কোনো ব্যক্তিগত বা গোপন বেংক/ইমেইল তথ্য অনাহকত শ্বেয়াৰ কৰা নহয়। সমস্যা হ’লে Customer Support ব্যৱহাৰ কৰক।',
        },
      ]
    : isBn
      ? [
          {
            heading: '১. সঠিক তথ্য ও বয়সের শর্ত',
            body: 'রেজিস্ট্রেশনের সময় কাস্টমার (ন্যূনতম ১৩ বছর) এবং ড্রাইভারকে (ন্যূনতম ১৮ বছর) অবশ্যই নিজের সঠিক নাম, Gender, Date of Birth এবং +91 মোবাইল নম্বর প্রদান করতে হবে।',
          },
          {
            heading: '২. ড্রাইভারের গাড়ি ও লাইসেন্স যাচাই',
            body: 'প্রতিটি ইলেকট্রিক রিকশা চালকের আসল গাড়ির নম্বর, বৈধ ড্রাইভিং লাইসেন্স (DL) এবং RC নম্বর থাকা বাধ্যতামূলক। ভুয়া বা মেয়াদোত্তীর্ণ কাগজপত্র দিলে অ্যাকাউন্ট বাতিল করা হবে।',
          },
          {
            heading: '৩. রেজিস্ট্রেশন ফি ও নির্ধারিত ভাড়া (₹)',
            body: 'ড্রাইভার রেজিস্ট্রেশন ফি PhonePe, GPay, Amazon Pay, Paytm অথবা অফিসে নগদ জমা করা যাবে। রাইডের ভাড়া অ্যাডমিন নির্ধারিত বেস ভাড়া, প্রতি কিমি ও ওয়েটিং চার্জ অনুযায়ী স্বয়ংক্রিয়ভাবে হিসাব হবে।',
          },
          {
            heading: '৪. নিরাপত্তা, শৃঙ্খলা ও ডেটা সুরক্ষা',
            body: 'যাত্রা চলাকালীন কাস্টমার ও ড্রাইভার উভয়কে ভদ্র আচরণ এবং ট্রাফিক আইন মেনে চলতে হবে। অ্যাপ ব্যবহারকারীর ব্যক্তিগত তথ্য সুরক্ষিত রাখা হয় এবং কোনো অভিযোগ থাকলে মেনু থেকে Customer Support ব্যবহার করা যাবে।',
          },
        ]
      : [
          {
            heading: '1. Accurate Profile & Age Eligibility',
            body: 'Customers (minimum age 13) and Drivers (minimum age 18) must provide accurate Full Name, Gender, Date of Birth, and Indian +91 contact details during sign-up.',
          },
          {
            heading: '2. Authentic Vehicle & Driving Licence Compliance',
            body: 'Drivers must register a genuine Electric Rickshaw registration number, valid Driving Licence (DL), and RC document. Invalid or counterfeit records lead to account rejection or suspension.',
          },
          {
            heading: '3. Registration Fee & Regulated INR (₹) Fares',
            body: 'Driver onboarding fees may be paid via PhonePe, GPay, Amazon Pay, Paytm, or Office Cash with a valid transaction reference. Ride fares follow transparent base, per-km, minimum, and waiting rates.',
          },
          {
            heading: '4. Ride Safety, Conduct & Privacy',
            body: 'Both Customers and Drivers agree to respectful conduct and Indian road safety rules. Personal account details are safeguarded, and disputes can be submitted anytime via Customer Support in the menu.',
          },
        ];

  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-5 shadow-sm">
        <div className="flex items-start gap-4 pb-4 border-b border-neutral-200">
          <img
            src="/src/assets/images/smart_ride_logo_1795224013713.jpg"
            alt="Smart Ride"
            referrerPolicy="no-referrer"
            className="w-14 h-14 rounded-2xl object-cover border border-neutral-200 shrink-0"
          />
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs text-emerald-700 font-semibold">
              <FileText className="w-3.5 h-3.5" />
              <span>Smart Ride Electric Rickshaw · {userRoleLabel}</span>
            </div>
            <h1 className="text-xl font-bold text-neutral-900 tracking-tight">{title}</h1>
            <p className="text-xs text-neutral-600 leading-relaxed">{subtitle}</p>
          </div>
        </div>

        <div className="space-y-4">
          {clauses.map((item) => (
            <div
              key={item.heading}
              className="p-4 rounded-xl bg-neutral-50 border border-neutral-200 space-y-1.5"
            >
              <h2 className="text-sm font-bold text-neutral-900">{item.heading}</h2>
              <p className="text-xs text-neutral-700 leading-relaxed">{item.body}</p>
            </div>
          ))}
        </div>

        <div className="pt-3 border-t border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-neutral-600">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              {accepted
                ? isAs
                  ? 'আপুনি চৰ্তাৱলী মানি লৈছে।'
                  : isBn
                    ? 'আপনি অ্যাপের শর্তাবলী গ্রহণ করেছেন।'
                    : 'Terms & Conditions accepted on this device.'
                : isAs
                  ? 'সেৱা ব্যৱহাৰ কৰিবলৈ চৰ্তাৱলী গ্ৰহণ কৰক।'
                  : isBn
                    ? 'অ্যাপ ব্যবহারের জন্য শর্তাবলী সম্মতি দিন।'
                    : 'Review and confirm acceptance below.'}
            </span>
          </div>

          <button
            type="button"
            onClick={handleAccept}
            disabled={accepted}
            className={`min-h-[44px] px-5 py-2.5 text-xs font-semibold rounded-xl transition-colors inline-flex items-center justify-center gap-2 ${
              accepted
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>
              {accepted
                ? isAs
                  ? 'সম্মতি দিয়া হৈছে'
                  : isBn
                    ? 'সম্মত হয়েছেন'
                    : 'Accepted'
                : isAs
                  ? 'চৰ্তাৱলী মানি লওক'
                  : isBn
                    ? 'আমি শর্তাবলী মেনে নিচ্ছি'
                    : 'I Accept Terms & Conditions'}
            </span>
          </button>
        </div>
      </div>
    </section>
  );
}
