import React, { useEffect, useMemo, useState } from 'react';
import { sendEmailVerification, signInWithPopup, signOut, type User } from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  Building2,
  CheckCircle2,
  Clock,
  Download,
  Fingerprint,
  IndianRupee,
  Lock,
  Mail,
  MapPin,
  MessageSquareWarning,
  Search,
  ShieldAlert,
  ShieldCheck,
  Star,
  UserCheck,
  Users,
  XCircle,
} from 'lucide-react';
import {
  clearRegisteredFingerprint,
  getRegisteredFingerprintMeta,
  registerDeviceFingerprint,
  verifyDeviceFingerprint,
} from '../lib/biometrics';
import {
  ADMIN_SESSION_EXPIRED_KEY,
  auth,
  db,
  getAdminSessionTiming,
  googleProvider,
  handleFirestoreError,
  OperationType,
  verifyAdminSessionDetailed,
} from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import {
  clampText,
  FIELD_LIMITS,
  isValidIfscCode,
  maskAccountNumber,
} from '../lib/validation';
import type {
  AdminPayoutSettingsRecord,
  AdminUserRecord,
  AppRatingRecord,
  ComplaintRecord,
  CustomerProfile,
  DriverApprovalStatus,
  DriverDocumentRecord,
  DriverLocationRecord,
  DriverProfile,
  FareSettingsRecord,
  LanguageCode,
  PaymentRecord,
  RatingRecord,
  RideRecord,
  VehicleRecord,
} from '../types/smartride';
import { AuthGateCard } from './AuthGateCard';
import { SmartRideMap } from './maps/SmartRideMap';

interface AdminDashboardProps {
  user: User | null;
  language: LanguageCode;
  mapsEnabled: boolean;
  sessionExpiredNotice?: boolean;
  pendingEmailLink?: string | null;
  onClearPendingEmailLink?: () => void;
}

type AdminSection = 'drivers' | 'customers' | 'fares' | 'rides' | 'complaints' | 'admins';
type DriverFilter = 'all' | DriverApprovalStatus;

export function AdminDashboard({
  user,
  language,
  mapsEnabled,
  sessionExpiredNotice = false,
  pendingEmailLink = null,
  onClearPendingEmailLink,
}: AdminDashboardProps) {
  const t = TRANSLATIONS[language];
  const [adminRecord, setAdminRecord] = useState<AdminUserRecord | null>(null);
  const [isAuthorizedAdmin, setIsAuthorizedAdmin] = useState(false);
  const [adminChecked, setAdminChecked] = useState(false);
  const [adminCheckReason, setAdminCheckReason] = useState<
    'not_signed_in' | 'not_admin' | 'network_error' | 'session_expired' | undefined
  >();
  const [adminCheckError, setAdminCheckError] = useState<string | null>(null);
  const [adminSwitchError, setAdminSwitchError] = useState<string | null>(null);
  const [sessionRemainingMs, setSessionRemainingMs] = useState<number | null>(null);

  const [customers, setCustomers] = useState<CustomerProfile[]>([]);
  const [drivers, setDrivers] = useState<DriverProfile[]>([]);
  const [vehicles, setVehicles] = useState<Record<string, VehicleRecord>>({});
  const [driverDocs, setDriverDocs] = useState<Record<string, DriverDocumentRecord>>({});
  const [driverLocations, setDriverLocations] = useState<DriverLocationRecord[]>([]);
  const [rides, setRides] = useState<RideRecord[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [ratings, setRatings] = useState<RatingRecord[]>([]);
  const [appRatings, setAppRatings] = useState<AppRatingRecord[]>([]);
  const [complaints, setComplaints] = useState<ComplaintRecord[]>([]);
  const [admins, setAdmins] = useState<AdminUserRecord[]>([]);
  const [fareSettings, setFareSettings] = useState<FareSettingsRecord | null>(null);

  // Admin Fingerprint Lock & Email Verification state
  const [fingerprintUnlocked, setFingerprintUnlocked] = useState<boolean>(
    () => !getRegisteredFingerprintMeta()
  );
  const [fingerprintRegistered, setFingerprintRegistered] = useState<boolean>(
    () => Boolean(getRegisteredFingerprintMeta())
  );
  const [bioError, setBioError] = useState<string | null>(null);
  const [bioBusy, setBioBusy] = useState(false);
  const [verifyMailBusy, setVerifyMailBusy] = useState(false);
  const [verifyMailMsg, setVerifyMailMsg] = useState<string | null>(null);

  const [section, setSection] = useState<AdminSection>('drivers');
  const [driverFilter, setDriverFilter] = useState<DriverFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [rejectingUid, setRejectingUid] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [complaintNoteMap, setComplaintNoteMap] = useState<Record<string, string>>({});

  // Fare & Owner Bank Payout form state
  const [baseFare, setBaseFare] = useState(10);
  const [pricePerKm, setPricePerKm] = useState(12);
  const [minFare, setMinFare] = useState(20);
  const [waitingCharge, setWaitingCharge] = useState(2);
  const [commissionPct, setCommissionPct] = useState(10);
  const [driverRegistrationFee, setDriverRegistrationFee] = useState(199);
  const [adminUpiId, setAdminUpiId] = useState('smartride@upi');
  const [businessPayeeName, setBusinessPayeeName] = useState('Smart Ride Electric Rickshaw');

  const [payoutSettings, setPayoutSettings] = useState<AdminPayoutSettingsRecord | null>(null);
  const [accountHolderName, setAccountHolderName] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [branchName, setBranchName] = useState('');

  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    let active = true;
    if (!user) {
      setAdminRecord(null);
      setIsAuthorizedAdmin(false);
      setAdminChecked(true);
      return () => {
        active = false;
      };
    }

    setAdminChecked(false);
    setAdminSwitchError(null);
    setAdminCheckError(null);
    void verifyAdminSessionDetailed(user).then((res) => {
      if (active) {
        setIsAuthorizedAdmin(res.allowed);
        setAdminCheckReason(res.reason);
        setAdminCheckError(res.errorMessage || null);
        setAdminChecked(true);
      }
    });

    const unsubAdmin = onSnapshot(
      doc(db, 'admin_users', user.uid),
      (snap) => {
        if (snap.exists()) {
          const rec = snap.data() as AdminUserRecord;
          setAdminRecord(rec);
          if (rec.status === 'active') setIsAuthorizedAdmin(true);
        } else {
          setAdminRecord(null);
        }
      },
      () => {
        setAdminRecord(null);
      }
    );

    return () => {
      active = false;
      unsubAdmin();
    };
  }, [user]);

  // Enforce 12-hour Admin session validity and keep countdown updated
  useEffect(() => {
    if (!user) {
      setSessionRemainingMs(null);
      return;
    }
    if (!isAuthorizedAdmin && adminCheckReason !== 'session_expired') {
      return;
    }

    let cancelled = false;
    let expiryTimeout: number | undefined;
    let countdownInterval: number | undefined;

    const triggerExpiredLogout = () => {
      try {
        window.localStorage.setItem(ADMIN_SESSION_EXPIRED_KEY, '1');
      } catch {
        // Ignore storage errors
      }
      setIsAuthorizedAdmin(false);
      setSessionRemainingMs(0);
      void signOut(auth);
    };

    const syncTiming = async () => {
      const timing = await getAdminSessionTiming(user);
      if (cancelled) return;
      if (!timing.valid || adminCheckReason === 'session_expired') {
        triggerExpiredLogout();
        return;
      }
      setSessionRemainingMs(timing.remainingMs);
      if (expiryTimeout) window.clearTimeout(expiryTimeout);
      expiryTimeout = window.setTimeout(
        triggerExpiredLogout,
        Math.min(timing.remainingMs + 250, 2147483000)
      );
    };

    void syncTiming();
    countdownInterval = window.setInterval(() => {
      void syncTiming();
    }, 30000);

    const onVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        void syncTiming();
      }
    };
    window.addEventListener('focus', onVisibilityOrFocus);
    document.addEventListener('visibilitychange', onVisibilityOrFocus);

    return () => {
      cancelled = true;
      if (expiryTimeout) window.clearTimeout(expiryTimeout);
      if (countdownInterval) window.clearInterval(countdownInterval);
      window.removeEventListener('focus', onVisibilityOrFocus);
      document.removeEventListener('visibilitychange', onVisibilityOrFocus);
    };
  }, [user, isAuthorizedAdmin, adminCheckReason]);

  useEffect(() => {
    if (!user || !isAuthorizedAdmin) return;

    const unsubCustomers = onSnapshot(
      collection(db, 'customers'),
      (snap) => setCustomers(snap.docs.map((d) => d.data() as CustomerProfile)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'customers')
    );

    const unsubDrivers = onSnapshot(
      collection(db, 'drivers'),
      (snap) => setDrivers(snap.docs.map((d) => d.data() as DriverProfile)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'drivers')
    );

    const unsubVehicles = onSnapshot(
      collection(db, 'vehicles'),
      (snap) => {
        const record: Record<string, VehicleRecord> = {};
        snap.docs.forEach((d) => {
          const v = d.data() as VehicleRecord;
          record[v.driver_id] = v;
        });
        setVehicles(record);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'vehicles')
    );

    const unsubDocs = onSnapshot(
      collection(db, 'driver_documents'),
      (snap) => {
        const record: Record<string, DriverDocumentRecord> = {};
        snap.docs.forEach((d) => {
          const docRec = d.data() as DriverDocumentRecord;
          record[docRec.driver_id] = docRec;
        });
        setDriverDocs(record);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'driver_documents')
    );

    const unsubLocs = onSnapshot(
      collection(db, 'driver_locations'),
      (snap) => setDriverLocations(snap.docs.map((d) => d.data() as DriverLocationRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'driver_locations')
    );

    const unsubRides = onSnapshot(
      collection(db, 'rides'),
      (snap) => {
        const list = snap.docs.map((d) => d.data() as RideRecord);
        list.sort((a, b) => (b.created_at?.toMillis?.() ?? 0) - (a.created_at?.toMillis?.() ?? 0));
        setRides(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'rides')
    );

    const unsubPayments = onSnapshot(
      collection(db, 'payments'),
      (snap) => setPayments(snap.docs.map((d) => d.data() as PaymentRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'payments')
    );

    const unsubRatings = onSnapshot(
      collection(db, 'ratings'),
      (snap) => setRatings(snap.docs.map((d) => d.data() as RatingRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'ratings')
    );

    const unsubAppRatings = onSnapshot(
      collection(db, 'app_ratings'),
      (snap) => {
        const list = snap.docs.map((d) => d.data() as AppRatingRecord);
        list.sort((a, b) => (b.created_at?.toMillis?.() ?? 0) - (a.created_at?.toMillis?.() ?? 0));
        setAppRatings(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'app_ratings')
    );

    const unsubComplaints = onSnapshot(
      collection(db, 'complaints'),
      (snap) => {
        const list = snap.docs.map((d) => d.data() as ComplaintRecord);
        list.sort((a, b) => (b.created_at?.toMillis?.() ?? 0) - (a.created_at?.toMillis?.() ?? 0));
        setComplaints(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'complaints')
    );

    const unsubAdmins = onSnapshot(
      collection(db, 'admin_users'),
      (snap) => setAdmins(snap.docs.map((d) => d.data() as AdminUserRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'admin_users')
    );

    const unsubFare = onSnapshot(
      doc(db, 'fare_settings', 'default'),
      (snap) => {
        if (snap.exists()) {
          const f = snap.data() as FareSettingsRecord;
          setFareSettings(f);
          setBaseFare(f.base_fare);
          setPricePerKm(f.price_per_km);
          setMinFare(f.minimum_fare);
          setWaitingCharge(f.waiting_charge);
          setCommissionPct(f.platform_commission);
          setDriverRegistrationFee(f.driver_registration_fee ?? 199);
          setAdminUpiId(f.admin_upi_id || 'smartride@upi');
          setBusinessPayeeName(f.business_payee_name || 'Smart Ride Electric Rickshaw');
        } else {
          setFareSettings(null);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, 'fare_settings/default')
    );

    const unsubPayout = onSnapshot(
      doc(db, 'admin_payout_settings', 'primary'),
      (snap) => {
        if (snap.exists()) {
          const p = snap.data() as AdminPayoutSettingsRecord;
          setPayoutSettings(p);
          setAccountHolderName(p.account_holder_name || '');
          setBankName(p.bank_name || '');
          setAccountNumber(p.account_number || '');
          setIfscCode(p.ifsc_code || '');
          setBranchName(p.branch_name || '');
          if (p.upi_id) setAdminUpiId(p.upi_id);
          if (p.payee_display_name) setBusinessPayeeName(p.payee_display_name);
        } else {
          setPayoutSettings(null);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, 'admin_payout_settings/primary')
    );

    return () => {
      unsubCustomers();
      unsubDrivers();
      unsubVehicles();
      unsubDocs();
      unsubLocs();
      unsubRides();
      unsubPayments();
      unsubRatings();
      unsubAppRatings();
      unsubComplaints();
      unsubAdmins();
      unsubFare();
      unsubPayout();
    };
  }, [user, isAuthorizedAdmin]);

  const handleBootstrapSetup = async () => {
    if (!user || !isAuthorizedAdmin) return;
    setBusyAction('bootstrap');
    setFeedback(null);
    try {
      const batch = writeBatch(db);
      if (!adminRecord) {
        batch.set(doc(db, 'admin_users', user.uid), {
          uid: user.uid,
          email: user.email || '',
          full_name: clampText(user.displayName || 'Smart Ride Admin', 100),
          role: 'super_admin',
          status: 'active',
          created_at: serverTimestamp(),
          updated_at: serverTimestamp(),
        });
        batch.set(doc(db, 'users', user.uid), {
          uid: user.uid,
          full_name: clampText(user.displayName || 'Smart Ride Admin', 100),
          phone_number: user.phoneNumber || '',
          email: user.email || '',
          role: 'admin',
          profile_image: user.photoURL || '',
          account_status: 'active',
          preferred_language: language,
          created_at: serverTimestamp(),
          updated_at: serverTimestamp(),
        });
      }
      if (!fareSettings) {
        batch.set(doc(db, 'fare_settings', 'default'), {
          base_fare: 10,
          price_per_km: 12,
          minimum_fare: 20,
          waiting_charge: 2,
          platform_commission: 10,
          driver_registration_fee: 199,
          admin_upi_id: 'smartride@upi',
          business_payee_name: 'Smart Ride Electric Rickshaw',
          currency: 'INR',
          updated_by: user.uid,
          updated_at: serverTimestamp(),
        });
      }
      await batch.commit();
      setFeedback({
        type: 'ok',
        text: 'Admin record and default INR fare tariff initialized in Firestore.',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'admin_users');
    } finally {
      setBusyAction(null);
    }
  };

  const handleDriverDecision = async (
    targetDriver: DriverProfile,
    decision: 'approved' | 'rejected',
    reason = ''
  ) => {
    if (!user || !isAuthorizedAdmin) return;
    const cleanReason =
      decision === 'rejected'
        ? clampText(reason || 'Document verification failed.', 300)
        : '';

    setBusyAction(targetDriver.uid);
    setFeedback(null);
    try {
      const batch = writeBatch(db);

      batch.update(doc(db, 'drivers', targetDriver.uid), {
        approval_status: decision,
        rejection_reason: cleanReason,
        is_online: decision === 'approved' ? targetDriver.is_online : false,
        updated_at: serverTimestamp(),
      });

      if (vehicles[targetDriver.uid]) {
        batch.update(doc(db, 'vehicles', targetDriver.uid), {
          status: decision === 'approved' ? 'verified' : 'rejected',
          updated_at: serverTimestamp(),
        });
      }

      if (driverDocs[targetDriver.uid]) {
        batch.update(doc(db, 'driver_documents', targetDriver.uid), {
          verification_status: decision,
          reviewed_by: user.uid,
          notes:
            decision === 'approved'
              ? 'KYC & Vehicle RC verified by Smart Ride Admin.'
              : cleanReason,
          updated_at: serverTimestamp(),
        });
      }

      const notifId = `notif_${targetDriver.uid}_${Date.now()}`;
      batch.set(doc(db, 'notifications', notifId), {
        notification_id: notifId,
        recipient_id: targetDriver.uid,
        title:
          decision === 'approved'
            ? 'Driver Account Approved'
            : 'Driver Verification Update',
        body:
          decision === 'approved'
            ? `Your Electric Rickshaw (${targetDriver.vehicle_number}) is verified. You can now go online.`
            : `Application rejected: ${cleanReason}`,
        type: 'driver_approval',
        is_read: false,
        created_at: serverTimestamp(),
      });

      await batch.commit();
      setRejectingUid(null);
      setRejectReason('');
      setFeedback({
        type: 'ok',
        text: `${targetDriver.full_name} marked as ${decision}.`,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `drivers/${targetDriver.uid}`);
    } finally {
      setBusyAction(null);
    }
  };

  const handleAdminToggleDriverOnline = async (targetDriver: DriverProfile) => {
    if (!user || !isAuthorizedAdmin) return;
    setBusyAction(targetDriver.uid);
    try {
      await updateDoc(doc(db, 'drivers', targetDriver.uid), {
        is_online: !targetDriver.is_online,
        updated_at: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `drivers/${targetDriver.uid}`);
    } finally {
      setBusyAction(null);
    }
  };

  const handleToggleCustomerStatus = async (customer: CustomerProfile) => {
    if (!user || !isAuthorizedAdmin) return;
    const nextStatus = customer.account_status === 'active' ? 'suspended' : 'active';
    setBusyAction(customer.uid);
    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'customers', customer.uid), {
        account_status: nextStatus,
        updated_at: serverTimestamp(),
      });
      batch.update(doc(db, 'users', customer.uid), {
        account_status: nextStatus,
        updated_at: serverTimestamp(),
      });
      await batch.commit();
      setFeedback({
        type: 'ok',
        text: `Customer ${customer.full_name} is now ${nextStatus}.`,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `customers/${customer.uid}`);
    } finally {
      setBusyAction(null);
    }
  };

  const handleSaveFareSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !isAuthorizedAdmin) return;
    setBusyAction('fares');
    setFeedback(null);
    try {
      await setDoc(doc(db, 'fare_settings', 'default'), {
        base_fare: Number(baseFare),
        price_per_km: Number(pricePerKm),
        minimum_fare: Number(minFare),
        waiting_charge: Number(waitingCharge),
        platform_commission: Number(commissionPct),
        driver_registration_fee: Number(driverRegistrationFee),
        admin_upi_id: clampText(adminUpiId, 100),
        business_payee_name: clampText(
          businessPayeeName || 'Smart Ride Electric Rickshaw',
          80
        ),
        currency: 'INR',
        updated_by: user.uid,
        updated_at: serverTimestamp(),
      });
      setFeedback({
        type: 'ok',
        text: 'Official INR fare tariff updated in Firestore and synced to Customer & Driver apps.',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'fare_settings/default');
    } finally {
      setBusyAction(null);
    }
  };

  const handleSaveBankSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !isAuthorizedAdmin) return;
    setFeedback(null);

    const cleanHolder = clampText(accountHolderName, 100);
    const cleanBank = clampText(bankName, 100);
    const cleanAcct = accountNumber.replace(/\s+/g, '').slice(0, 30);
    const cleanIfsc = ifscCode.trim().toUpperCase();
    const cleanBranch = clampText(branchName, 100);
    const cleanUpi = clampText(adminUpiId, 100);
    const cleanPayee = clampText(businessPayeeName || 'Smart Ride Electric Rickshaw', 80);

    if (cleanHolder.length < 2 || cleanBank.length < 2) {
      setFeedback({ type: 'err', text: 'Enter Account Holder Name and Bank Name.' });
      return;
    }
    if (cleanAcct.length < 6) {
      setFeedback({ type: 'err', text: 'Enter a valid Bank Account Number (min 6 digits).' });
      return;
    }
    if (!isValidIfscCode(cleanIfsc)) {
      setFeedback({
        type: 'err',
        text: 'Enter a valid 11-character Indian IFSC code (e.g. SBIN0001234).',
      });
      return;
    }

    setBusyAction('bank');
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'admin_payout_settings', 'primary'), {
        account_holder_name: cleanHolder,
        bank_name: cleanBank,
        account_number: cleanAcct,
        ifsc_code: cleanIfsc,
        branch_name: cleanBranch,
        upi_id: cleanUpi,
        payee_display_name: cleanPayee,
        updated_by: user.uid,
        updated_at: serverTimestamp(),
      });
      batch.set(doc(db, 'fare_settings', 'default'), {
        base_fare: Number(baseFare),
        price_per_km: Number(pricePerKm),
        minimum_fare: Number(minFare),
        waiting_charge: Number(waitingCharge),
        platform_commission: Number(commissionPct),
        driver_registration_fee: Number(driverRegistrationFee),
        admin_upi_id: cleanUpi,
        business_payee_name: cleanPayee,
        currency: 'INR',
        updated_by: user.uid,
        updated_at: serverTimestamp(),
      });
      await batch.commit();
      setFeedback({
        type: 'ok',
        text: 'Owner Bank Account saved privately (Admin-only) & Merchant UPI ID synced for Driver fee payments.',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'admin_payout_settings/primary');
    } finally {
      setBusyAction(null);
    }
  };

  const handleResolveComplaint = async (
    complaint: ComplaintRecord,
    nextStatus: 'resolved' | 'dismissed'
  ) => {
    if (!user || !isAuthorizedAdmin) return;
    setBusyAction(complaint.complaint_id);
    const notes = clampText(
      complaintNoteMap[complaint.complaint_id] || `Marked ${nextStatus} by Smart Ride Operations.`,
      FIELD_LIMITS.NOTES_MAX
    );
    try {
      await updateDoc(doc(db, 'complaints', complaint.complaint_id), {
        status: nextStatus,
        admin_notes: notes,
        updated_at: serverTimestamp(),
      });
      setFeedback({ type: 'ok', text: `Complaint ${complaint.complaint_id} marked ${nextStatus}.` });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `complaints/${complaint.complaint_id}`);
    } finally {
      setBusyAction(null);
    }
  };

  const handleExportRidesCsv = () => {
    const header = [
      'RideID',
      'Customer',
      'Driver',
      'Vehicle',
      'Pickup',
      'Destination',
      'DistanceKm',
      'FareINR',
      'RideStatus',
      'PaymentStatus',
      'PaymentMethod',
    ];
    const rows = rides.map((r) => [
      r.ride_id,
      r.customer_name || r.customer_id,
      r.driver_name || r.driver_id || 'Unassigned',
      r.driver_vehicle_number || '',
      `"${r.pickup_address.replace(/"/g, '""')}"`,
      `"${r.destination_address.replace(/"/g, '""')}"`,
      r.distance_km,
      r.final_fare || r.estimated_fare,
      r.ride_status,
      r.payment_status,
      r.payment_method || '',
    ]);
    const csv = [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `smart_ride_report_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  const metrics = useMemo(() => {
    const approved = drivers.filter((d) => d.approval_status === 'approved').length;
    const pending = drivers.filter((d) => d.approval_status === 'pending').length;
    const rejected = drivers.filter((d) => d.approval_status === 'rejected').length;
    const online = drivers.filter((d) => d.is_online).length;
    const activeRides = rides.filter((r) =>
      ['requested', 'accepted', 'arrived', 'in_progress'].includes(r.ride_status)
    ).length;
    const completedRides = rides.filter((r) => r.ride_status === 'completed').length;
    const cancelledRides = rides.filter((r) => r.ride_status === 'cancelled').length;
    const paymentRevenue = payments
      .filter((p) => p.status === 'verified')
      .reduce((sum, p) => sum + p.amount, 0);
    const paidRideRevenue = rides
      .filter((r) => r.ride_status === 'completed' && r.payment_status === 'paid')
      .reduce((sum, r) => sum + (r.final_fare > 0 ? r.final_fare : r.estimated_fare), 0);
    const revenue = Math.max(paymentRevenue, paidRideRevenue);
    const commissionEarned = Number(
      ((revenue * (fareSettings?.platform_commission ?? 10)) / 100).toFixed(2)
    );
    const openComplaints = complaints.filter((c) => c.status === 'open').length;
    const avgPlatformRating =
      ratings.length > 0
        ? (ratings.reduce((s, r) => s + r.score, 0) / ratings.length).toFixed(1)
        : '5.0';

    return {
      totalCustomers: customers.length,
      totalDrivers: drivers.length,
      approved,
      pending,
      rejected,
      online,
      activeRides,
      completedRides,
      cancelledRides,
      revenue,
      commissionEarned,
      openComplaints,
      avgPlatformRating,
    };
  }, [customers, drivers, rides, payments, fareSettings, complaints, ratings]);

  const filteredDrivers = useMemo(() => {
    return drivers.filter((d) => {
      if (driverFilter !== 'all' && d.approval_status !== driverFilter) return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        d.full_name.toLowerCase().includes(q) ||
        d.vehicle_number.toLowerCase().includes(q) ||
        d.phone_number.toLowerCase().includes(q)
      );
    });
  }, [drivers, driverFilter, searchQuery]);

  if (!user) {
    return (
      <div className="py-6">
        <AuthGateCard
          portalLabel="Smart Ride Operations Console"
          language={language}
          allowPhoneOtp={false}
          adminOnlyNotice
          sessionExpiredNotice={sessionExpiredNotice}
          pendingEmailLink={pendingEmailLink}
          onClearPendingEmailLink={onClearPendingEmailLink}
        />
      </div>
    );
  }

  if (!adminChecked) {
    return (
      <div className="bg-white border border-neutral-200 rounded-2xl p-8 space-y-4">
        <div className="h-6 w-60 bg-neutral-200 rounded animate-pulse" />
        <div className="h-32 w-full bg-neutral-100 rounded-xl animate-pulse" />
      </div>
    );
  }

  const handleSwitchAdminAccount = async () => {
    setAdminSwitchError(null);
    setBusyAction('switch_admin');
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      await cred.user.getIdToken(true);
      const res = await verifyAdminSessionDetailed(cred.user);
      setIsAuthorizedAdmin(res.allowed);
      setAdminCheckReason(res.reason);
      setAdminCheckError(res.errorMessage || null);
      setAdminChecked(true);
    } catch (err) {
      const raw = err instanceof Error ? err.message : String(err);
      if (raw.includes('popup-blocked')) {
        setAdminSwitchError(
          language === 'as'
            ? 'ব্ৰাউজাৰে পপ-আপ ব্লক কৰিছে। Pop-up Allow কৰক বা তলৰ ছাইন আউট বুটামত টেপ কৰক।'
            : language === 'bn'
              ? 'ব্রাউজার পপ-আপ ব্লক করেছে। অনুগ্রহ করে Pop-up Allow করুন অথবা নিচের Sign Out বাটনে ট্যাপ করে আবার লগইন করুন।'
              : 'Browser blocked the Google sign-in popup. Allow popups or tap Sign Out below first.'
        );
      } else {
        setAdminSwitchError(raw);
      }
    } finally {
      setBusyAction(null);
    }
  };

  const handleRetryAdminCheck = async () => {
    if (!user) return;
    setAdminSwitchError(null);
    setAdminChecked(false);
    try {
      await user.reload();
      await user.getIdToken(true);
    } catch {
      // Ignore refresh failure and still probe
    }
    const res = await verifyAdminSessionDetailed(user);
    setIsAuthorizedAdmin(res.allowed);
    setAdminCheckReason(res.reason);
    setAdminCheckError(res.errorMessage || null);
    setAdminChecked(true);
  };

  const handleResendAdminVerifyEmail = async () => {
    if (!user) return;
    setVerifyMailBusy(true);
    setVerifyMailMsg(null);
    try {
      await sendEmailVerification(user);
      setVerifyMailMsg(
        language === 'bn'
          ? 'ভেরিফিকেশন লিংক আপনার Gmail-এ পাঠানো হয়েছে। ইনবক্সে লিংকটিতে ক্লিক করে নিচের "I Verified — Refresh" বাটনে চাপুন।'
          : 'Verification link sent to your Gmail. Click it in your inbox, then tap "I Verified — Refresh".'
      );
    } catch (err) {
      setVerifyMailMsg(err instanceof Error ? err.message : String(err));
    } finally {
      setVerifyMailBusy(false);
    }
  };

  const handleUnlockFingerprint = async () => {
    setBioError(null);
    setBioBusy(true);
    try {
      const res = await verifyDeviceFingerprint();
      if (res.ok) {
        setFingerprintUnlocked(true);
      } else if (res.error) {
        setBioError(res.error);
      }
    } finally {
      setBioBusy(false);
    }
  };

  const handleEnableFingerprint = async () => {
    if (!user) return;
    setBioError(null);
    setBioBusy(true);
    try {
      const res = await registerDeviceFingerprint(user.uid);
      if (res.ok) {
        setFingerprintRegistered(true);
        setFingerprintUnlocked(true);
        setFeedback({
          type: 'ok',
          text:
            language === 'bn'
              ? 'এই ডিভাইসে Admin Fingerprint Lock সফলভাবে চালু হয়েছে।'
              : 'Device Fingerprint Lock enabled for Admin Console on this phone.',
        });
      } else if (res.error) {
        setFeedback({ type: 'err', text: res.error });
      }
    } finally {
      setBioBusy(false);
    }
  };

  const handleDisableFingerprint = () => {
    clearRegisteredFingerprint();
    setFingerprintRegistered(false);
    setFingerprintUnlocked(true);
    setFeedback({
      type: 'ok',
      text:
        language === 'bn'
          ? 'এই ডিভাইস থেকে Fingerprint Lock বন্ধ করা হয়েছে।'
          : 'Device Fingerprint Lock disabled on this device.',
    });
  };

  if (user.email && !user.emailVerified) {
    return (
      <div className="max-w-lg mx-auto bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 space-y-5 text-center">
        <Mail className="w-8 h-8 text-emerald-700 mx-auto" />
        <div className="space-y-2">
          <h2 className="text-lg font-bold text-neutral-900">
            {language === 'bn' ? 'Admin Gmail ভেরিফাই করুন' : 'Verify Your Admin Gmail'}
          </h2>
          <p className="text-sm text-neutral-600 leading-relaxed">
            {language === 'bn'
              ? `নিরাপত্তার জন্য ${user.email} ঠিকানায় পাঠানো ভেরিফিকেশন লিংকে ক্লিক করে ইমেইল যাচাই করুন, তারপর নিচের Refresh বাটনে চাপুন।`
              : `For security, click the verification link sent to ${user.email}, then tap "I Verified — Refresh" below.`}
          </p>
        </div>

        {verifyMailMsg && (
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
            {verifyMailMsg}
          </div>
        )}

        <div className="flex flex-col sm:flex-row flex-wrap gap-2.5 justify-center">
          <button
            type="button"
            disabled={verifyMailBusy}
            onClick={() => void handleResendAdminVerifyEmail()}
            className="min-h-[44px] px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 text-white text-xs font-semibold rounded-xl"
          >
            {verifyMailBusy ? 'Sending...' : 'Send / Resend Verification Email'}
          </button>
          <button
            type="button"
            onClick={() => void handleRetryAdminCheck()}
            className="min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl"
          >
            I Verified — Refresh
          </button>
          <button
            type="button"
            onClick={() => void signOut(auth)}
            className="min-h-[44px] px-4 py-2.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold rounded-xl border border-neutral-300"
          >
            {t.signOut}
          </button>
        </div>
      </div>
    );
  }

  if (!isAuthorizedAdmin) {
    const isNetworkErr = adminCheckReason === 'network_error';
    return (
      <div className="max-w-lg mx-auto bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 space-y-5 text-center">
        <ShieldAlert className="w-8 h-8 text-red-600 mx-auto" />
        <div className="space-y-2">
          <h2 className="text-lg font-bold text-neutral-900">
            {isNetworkErr
              ? language === 'as'
                ? 'সংযোগ পৰীক্ষা ব্যৰ্থ হৈছে'
                : language === 'bn'
                  ? 'সংযোগ যাচাই ব্যর্থ হয়েছে'
                  : 'Connection Check Failed'
              : language === 'as'
                ? 'Admin একাউণ্টেৰে লগইন কৰক'
                : language === 'bn'
                  ? 'Admin অ্যাকাউন্ট দিয়ে লগইন করুন'
                  : 'Administrator Access Required'}
          </h2>
          <p className="text-sm text-neutral-600 leading-relaxed">
            {language === 'as'
              ? 'বৰ্তমান লগইন কৰা আছে: '
              : language === 'bn'
                ? 'বর্তমানে লগইন করা আছে: '
                : 'Currently signed in as '}
            <span className="font-mono text-neutral-900 font-medium">
              {user.email || user.phoneNumber || user.uid}
            </span>
            .{' '}
            {isNetworkErr
              ? language === 'as'
                ? 'চাৰ্ভাৰৰ সৈতে সংযোগ হোৱা নাই। ইণ্টাৰনেট পৰীক্ষা কৰি পুনৰ চেষ্টা কৰক।'
                : language === 'bn'
                  ? 'সার্ভারের সাথে সংযোগ হতে সমস্যা হয়েছে। ইন্টারনেট চেক করে আবার চেষ্টা করুন।'
                  : 'Could not reach Firestore to verify admin permissions. Please check your connection and retry.'
              : language === 'as'
                ? 'অনুগ্ৰহ কৰি তলৰ "পুনৰ যাচাই কৰক" বা অনুমোদিত Admin Google একাউণ্ট বাছনি কৰক।'
                : language === 'bn'
                  ? 'অনুগ্রহ করে নিচের "আবার যাচাই করুন" বাটনে ট্যাপ করুন অথবা আপনার অনুমোদিত Admin Google অ্যাকাউন্ট বেছে নিন।'
                  : 'Tap "Verify Admin Access" below to refresh your session, or select your authorized Smart Ride owner/admin Google account.'}
          </p>
          {adminCheckError && (
            <p className="text-[11px] font-mono text-neutral-500 break-words pt-1">
              {adminCheckError}
            </p>
          )}
        </div>

        {adminSwitchError && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 text-left break-words">
            {adminSwitchError}
          </div>
        )}

        <div className="flex flex-col sm:flex-row flex-wrap gap-2.5 justify-center">
          <button
            type="button"
            onClick={() => void handleRetryAdminCheck()}
            className="min-h-[44px] px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors"
          >
            {language === 'as'
              ? 'পুনৰ যাচাই কৰক'
              : language === 'bn'
                ? 'আবার যাচাই করুন'
                : 'Verify Admin Access'}
          </button>
          <button
            type="button"
            disabled={busyAction === 'switch_admin'}
            onClick={() => void handleSwitchAdminAccount()}
            className="min-h-[44px] px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-xs font-semibold rounded-xl transition-colors"
          >
            {busyAction === 'switch_admin'
              ? 'Opening Google...'
              : language === 'as'
                ? 'Admin Google একাউণ্ট বাছনি কৰক'
                : language === 'bn'
                  ? 'Admin Google অ্যাকাউন্ট বেছে নিন'
                  : 'Choose Admin Google Account'}
          </button>
          <button
            type="button"
            onClick={() => void signOut(auth)}
            className="min-h-[44px] px-5 py-2.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold rounded-xl border border-neutral-300 transition-colors"
          >
            {t.signOut}
          </button>
        </div>
      </div>
    );
  }

  if (fingerprintRegistered && !fingerprintUnlocked) {
    return (
      <div className="max-w-md mx-auto bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 space-y-5 text-center">
        <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto">
          <Fingerprint className="w-8 h-8 text-emerald-700" />
        </div>
        <div className="space-y-1.5">
          <h2 className="text-lg font-bold text-neutral-900">
            {language === 'as'
              ? 'Admin Fingerprint Lock'
              : language === 'bn'
                ? 'Admin ফিঙ্গারপ্রিন্ট লক'
                : 'Admin Fingerprint Lock'}
          </h2>
          <p className="text-xs text-neutral-600 leading-relaxed">
            {language === 'bn'
              ? `স্বাগতম (${user.email})। Admin Console খুলতে আপনার ফোনের ফিঙ্গারপ্রিন্ট স্ক্যান করুন।`
              : `Signed in as ${user.email}. Scan your device fingerprint to unlock Admin Console.`}
          </p>
        </div>

        {bioError && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 text-left break-words">
            {bioError}
          </div>
        )}

        <div className="space-y-2.5">
          <button
            type="button"
            disabled={bioBusy}
            onClick={() => void handleUnlockFingerprint()}
            className="w-full min-h-[48px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2"
          >
            <Fingerprint className="w-5 h-5" />
            <span>
              {bioBusy
                ? 'Scanning...'
                : language === 'bn'
                  ? 'ফিঙ্গারপ্রিন্ট দিয়ে আনলক করুন'
                  : 'Unlock with Fingerprint'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleDisableFingerprint}
            className="w-full min-h-[40px] px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-medium rounded-xl border border-neutral-200"
          >
            {language === 'bn'
              ? 'এই ডিভাইসে ফিঙ্গারপ্রিন্ট লক রিসেট করুন'
              : 'Reset Device Fingerprint Lock'}
          </button>
        </div>
      </div>
    );
  }

  const exampleFiveKmFare = Math.max(minFare, baseFare + 5 * pricePerKm + waitingCharge);

  return (
    <div className="space-y-6">
      {/* Header & Bootstrap Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-200">
        <div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <p className="text-xs font-medium text-emerald-700">
              Smart Ride Admin · {user.email}
            </p>
            {sessionRemainingMs !== null && (
              <span className="inline-flex items-center gap-1 text-xs font-mono text-neutral-600">
                <Clock className="w-3.5 h-3.5 text-emerald-700" />
                <span>
                  {(() => {
                    const totalMins = Math.max(0, Math.floor(sessionRemainingMs / 60000));
                    const hrs = Math.floor(totalMins / 60);
                    const mins = totalMins % 60;
                    return language === 'bn'
                      ? `${hrs} ঘণ্টা ${mins} মি. বাকি (১২ ঘণ্টায় অটো লগআউট)`
                      : `${hrs}h ${mins}m left · 12h auto-logout`;
                  })()}
                </span>
              </span>
            )}
          </div>
          <h1 className="text-2xl font-bold text-neutral-900 tracking-tight mt-0.5">
            {t.adminTitle}
          </h1>
          <p className="text-xs text-neutral-500 mt-1">{t.adminSubtitle}</p>
        </div>

        {(!adminRecord || !fareSettings) && (
          <button
            type="button"
            onClick={handleBootstrapSetup}
            disabled={busyAction === 'bootstrap'}
            className="min-h-[40px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0"
          >
            {busyAction === 'bootstrap'
              ? 'Initializing...'
              : 'Initialize Admin & Default ₹ Fares'}
          </button>
        )}
      </div>

      {/* KPI Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white border border-neutral-200 rounded-xl p-4">
          <p className="text-xs text-neutral-500">{t.totalCustomers}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-neutral-900 mt-1">
            {metrics.totalCustomers}
          </p>
        </div>
        <div className="bg-white border border-neutral-200 rounded-xl p-4">
          <p className="text-xs text-neutral-500">{t.totalDrivers}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-neutral-900 mt-1">
            {metrics.totalDrivers}
          </p>
        </div>
        <div className="bg-white border border-neutral-200 rounded-xl p-4">
          <p className="text-xs text-neutral-500">{t.pendingDrivers}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-amber-700 mt-1">
            {metrics.pending}
          </p>
        </div>
        <div className="bg-white border border-neutral-200 rounded-xl p-4">
          <p className="text-xs text-neutral-500">
            {t.approvedDrivers} / {t.onlineDrivers}
          </p>
          <p className="text-xl font-bold font-mono tabular-nums text-emerald-700 mt-1">
            {metrics.approved} / {metrics.online}
          </p>
        </div>
        <div className="bg-white border border-neutral-200 rounded-xl p-4 col-span-2 sm:col-span-1">
          <p className="text-xs text-neutral-500">{t.totalRevenue}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-neutral-900 mt-1">
            ₹{metrics.revenue.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] font-mono text-emerald-700 mt-0.5">
            Fee: ₹{metrics.commissionEarned}
          </p>
        </div>
      </div>

      {/* Secondary Operational Counts */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-neutral-600 px-1">
        <span>
          {t.rejectedDrivers}:{' '}
          <strong className="font-mono tabular-nums text-neutral-900">{metrics.rejected}</strong>
        </span>
        <span aria-hidden="true">·</span>
        <span>
          {t.activeRides}:{' '}
          <strong className="font-mono tabular-nums text-emerald-700">{metrics.activeRides}</strong>
        </span>
        <span aria-hidden="true">·</span>
        <span>
          {t.completedRidesAdmin}:{' '}
          <strong className="font-mono tabular-nums text-neutral-900">
            {metrics.completedRides}
          </strong>
        </span>
        <span aria-hidden="true">·</span>
        <span>
          {t.cancelledRides}:{' '}
          <strong className="font-mono tabular-nums text-neutral-900">
            {metrics.cancelledRides}
          </strong>
        </span>
        <span aria-hidden="true">·</span>
        <span>
          Open Complaints:{' '}
          <strong className="font-mono tabular-nums text-amber-700">
            {metrics.openComplaints}
          </strong>
        </span>
        <span aria-hidden="true">·</span>
        <span>
          Avg Rating:{' '}
          <strong className="font-mono tabular-nums text-neutral-900">
            {metrics.avgPlatformRating}★
          </strong>
        </span>
      </div>

      {/* Segmented Navigation */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 bg-neutral-100 rounded-xl w-fit">
        {(
          [
            { id: 'drivers', label: 'Driver Verification' },
            { id: 'customers', label: 'Customers' },
            { id: 'fares', label: 'Fares & Owner Bank' },
            { id: 'rides', label: 'Live Map, Rides & Reports' },
            { id: 'complaints', label: `Complaints (${metrics.openComplaints})` },
            { id: 'admins', label: 'Admin Access' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setSection(tab.id)}
            className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              section === tab.id
                ? 'bg-white text-neutral-900 shadow-sm'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl text-xs border flex items-center gap-2 ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* SECTION: DRIVER VERIFICATION */}
      {section === 'drivers' && (
        <div className="bg-white border border-neutral-200 rounded-2xl overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 p-1 bg-neutral-100 rounded-lg w-fit">
              {(['all', 'pending', 'approved', 'rejected'] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setDriverFilter(f)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md capitalize transition-colors ${
                    driverFilter === f
                      ? 'bg-white text-neutral-900 shadow-sm'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search name, vehicle, phone..."
                className="w-full pl-9 pr-3 py-2 border border-neutral-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
          </div>

          {filteredDrivers.length === 0 ? (
            <div className="p-10 text-center space-y-2">
              <Users className="w-6 h-6 text-neutral-400 mx-auto" />
              <p className="text-sm font-medium text-neutral-900">No drivers in this view</p>
              <p className="text-xs text-neutral-500">
                Drivers registered via the Driver App portal or Android APK appear here for KYC approval.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-neutral-200">
              {filteredDrivers.map((d) => {
                const v = vehicles[d.uid];
                const docRec = driverDocs[d.uid];
                return (
                  <div key={d.uid} className="p-4 sm:p-5 space-y-4">
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      <div className="flex items-start gap-3.5">
                        <img
                          src={
                            d.profile_image ||
                            '/src/assets/images/driver_avatar_sample_1795224014527.jpg'
                          }
                          alt={d.full_name}
                          referrerPolicy="no-referrer"
                          className="w-11 h-11 rounded-full object-cover border border-neutral-200 shrink-0"
                        />
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2 text-sm">
                            <span className="font-semibold text-neutral-900">{d.full_name}</span>
                            <span className="text-neutral-300">·</span>
                            <span className="font-mono text-xs text-neutral-700">
                              {d.phone_number}
                            </span>
                            <span className="text-neutral-300">·</span>
                            <span
                              className={`text-xs font-semibold capitalize ${
                                d.approval_status === 'approved'
                                  ? 'text-emerald-700'
                                  : d.approval_status === 'rejected'
                                  ? 'text-red-700'
                                  : 'text-amber-700'
                              }`}
                            >
                              {d.approval_status}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-neutral-500">
                            <span className="font-mono text-neutral-800 font-medium">
                              {d.vehicle_number}
                            </span>
                            <span>{d.vehicle_type}</span>
                            {d.gender && (
                              <span className="capitalize">
                                {d.gender}
                                {d.date_of_birth ? ` · DOB ${d.date_of_birth}` : ''}
                              </span>
                            )}
                            {v && (
                              <span>
                                {v.manufacturer} {v.model_year} ({v.battery_capacity})
                              </span>
                            )}
                            {docRec && (
                              <span className="font-mono">
                                DL: {docRec.driving_license_number} · RC: {docRec.rc_number}
                              </span>
                            )}
                          </div>
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] pt-1">
                            <span
                              className={`font-medium ${
                                d.vehicle_check_status === 'valid_format'
                                  ? 'text-emerald-700'
                                  : d.vehicle_check_status === 'invalid_format'
                                    ? 'text-red-700'
                                    : 'text-neutral-500'
                              }`}
                            >
                              Vehicle Check: {d.vehicle_check_status || 'pending'}
                              {d.vehicle_rto_state ? ` (${d.vehicle_rto_state})` : ''}
                            </span>
                            <span className="text-neutral-300">·</span>
                            <span
                              className={`font-medium ${
                                d.dl_validity_status === 'valid'
                                  ? 'text-emerald-700'
                                  : d.dl_validity_status === 'invalid' || d.dl_validity_status === 'expired'
                                    ? 'text-red-700'
                                    : 'text-neutral-500'
                              }`}
                            >
                              DL Status: {d.dl_validity_status || 'pending'}
                            </span>
                            <span className="text-neutral-300">·</span>
                            <span
                              className={`font-medium font-mono ${
                                d.registration_fee_status === 'paid'
                                  ? 'text-emerald-700'
                                  : 'text-amber-700'
                              }`}
                            >
                              Fee: {d.registration_fee_status === 'paid' ? `₹${d.registration_fee_amount ?? 199} PAID (${(d.registration_fee_app || d.registration_fee_method || 'upi').toUpperCase()})` : 'Unpaid'}
                              {d.registration_fee_ref ? ` · Ref: ${d.registration_fee_ref}` : ''}
                            </span>
                            <span className="text-neutral-300">·</span>
                            <a
                              href="https://parivahan.gov.in"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="underline text-neutral-700 hover:text-neutral-900"
                            >
                              Vahan Check
                            </a>
                            <a
                              href="https://sarathi.parivahan.gov.in"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="underline text-neutral-700 hover:text-neutral-900"
                            >
                              Sarathi DL Check
                            </a>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        {d.approval_status !== 'approved' && (
                          <button
                            type="button"
                            disabled={busyAction === d.uid}
                            onClick={() => handleDriverDecision(d, 'approved')}
                            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{t.approve}</span>
                          </button>
                        )}
                        {d.approval_status === 'approved' && (
                          <button
                            type="button"
                            disabled={busyAction === d.uid}
                            onClick={() => handleAdminToggleDriverOnline(d)}
                            className="px-3.5 py-2 border border-neutral-300 text-neutral-800 hover:bg-neutral-50 text-xs font-medium rounded-lg transition-colors"
                          >
                            {d.is_online ? 'Force Offline' : 'Set Online'}
                          </button>
                        )}
                        <button
                          type="button"
                          disabled={busyAction === d.uid}
                          onClick={() => {
                            setRejectingUid(d.uid);
                            setRejectReason(d.rejection_reason || '');
                          }}
                          className="px-3.5 py-2 border border-red-200 text-red-700 hover:bg-red-50 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>{t.reject}</span>
                        </button>
                      </div>
                    </div>

                    {rejectingUid === d.uid && (
                      <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex flex-col sm:flex-row gap-2">
                        <input
                          type="text"
                          value={rejectReason}
                          onChange={(e) => setRejectReason(e.target.value)}
                          placeholder="Reason for rejection (e.g. Blurry RC certificate)"
                          className="flex-1 px-3 py-2 bg-white border border-red-200 rounded-lg text-xs focus:outline-none"
                        />
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setRejectingUid(null)}
                            className="px-3 py-2 text-xs text-neutral-700 bg-white border border-neutral-200 rounded-lg"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDriverDecision(d, 'rejected', rejectReason)}
                            className="px-3 py-2 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg"
                          >
                            Confirm Reject
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SECTION: CUSTOMERS */}
      {section === 'customers' && (
        <div className="bg-white border border-neutral-200 rounded-2xl overflow-hidden">
          {customers.length === 0 ? (
            <div className="p-10 text-center space-y-2">
              <UserCheck className="w-6 h-6 text-neutral-400 mx-auto" />
              <p className="text-sm font-medium text-neutral-900">No customers registered yet</p>
              <p className="text-xs text-neutral-500">
                Customers who sign up in the Customer App appear here immediately.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500">
                  <tr>
                    <th className="py-3 px-4 font-medium">Customer</th>
                    <th className="py-3 px-4 font-medium">Phone (+91)</th>
                    <th className="py-3 px-4 font-medium">Gender / DOB</th>
                    <th className="py-3 px-4 font-medium">City</th>
                    <th className="py-3 px-4 font-medium text-right">Rides</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 font-medium text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {customers.map((c) => (
                    <tr key={c.uid} className="hover:bg-neutral-50">
                      <td className="py-3 px-4 font-medium text-neutral-900">{c.full_name}</td>
                      <td className="py-3 px-4 font-mono text-neutral-700">{c.phone_number}</td>
                      <td className="py-3 px-4 text-neutral-600 capitalize">
                        {c.gender || '—'}
                        {c.date_of_birth ? ` · ${c.date_of_birth}` : ''}
                      </td>
                      <td className="py-3 px-4 text-neutral-600">{c.default_city}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {c.total_rides}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`font-medium capitalize ${
                            c.account_status === 'active' ? 'text-emerald-700' : 'text-red-700'
                          }`}
                        >
                          {c.account_status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          disabled={busyAction === c.uid}
                          onClick={() => handleToggleCustomerStatus(c)}
                          className="px-3 py-1.5 border border-neutral-300 rounded-lg text-xs font-medium hover:bg-white"
                        >
                          {c.account_status === 'active' ? 'Suspend' : 'Reactivate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SECTION: FARE MANAGEMENT */}
      {section === 'fares' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handleSaveFareSettings}
            className="lg:col-span-7 bg-white border border-neutral-200 rounded-2xl p-6 space-y-5"
          >
            <div className="pb-3 border-b border-neutral-100">
              <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                <IndianRupee className="w-4 h-4 text-emerald-600" />
                <span>Admin Fare Configuration (INR ₹)</span>
              </h2>
              <p className="text-xs text-neutral-500 mt-1">
                Only authorized administrators can modify fare parameters. Customers and drivers have read-only access.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="block">
                <span className="text-xs font-medium text-neutral-700">Base Fare (₹)</span>
                <input
                  type="number"
                  min={0}
                  max={5000}
                  step="1"
                  required
                  value={baseFare}
                  onChange={(e) => setBaseFare(Number(e.target.value))}
                  className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </label>

              <label className="block">
                <span className="text-xs font-medium text-neutral-700">
                  Price Per Kilometer (₹)
                </span>
                <input
                  type="number"
                  min={1}
                  max={500}
                  step="1"
                  required
                  value={pricePerKm}
                  onChange={(e) => setPricePerKm(Number(e.target.value))}
                  className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </label>

              <label className="block">
                <span className="text-xs font-medium text-neutral-700">Minimum Ride Fare (₹)</span>
                <input
                  type="number"
                  min={0}
                  max={5000}
                  step="1"
                  required
                  value={minFare}
                  onChange={(e) => setMinFare(Number(e.target.value))}
                  className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </label>

              <label className="block">
                <span className="text-xs font-medium text-neutral-700">
                  Waiting Charges (₹ / min)
                </span>
                <input
                  type="number"
                  min={0}
                  max={500}
                  step="0.5"
                  required
                  value={waitingCharge}
                  onChange={(e) => setWaitingCharge(Number(e.target.value))}
                  className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </label>

              <label className="block">
                <span className="text-xs font-medium text-neutral-700">
                  Platform Commission (%)
                </span>
                <input
                  type="number"
                  min={0}
                  max={50}
                  step="0.5"
                  required
                  value={commissionPct}
                  onChange={(e) => setCommissionPct(Number(e.target.value))}
                  className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </label>

              <label className="block">
                <span className="text-xs font-medium text-neutral-700">
                  Driver Registration Fee (₹)
                </span>
                <input
                  type="number"
                  min={0}
                  max={50000}
                  step="1"
                  required
                  value={driverRegistrationFee}
                  onChange={(e) => setDriverRegistrationFee(Number(e.target.value))}
                  className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </label>

              <label className="block sm:col-span-2">
                <span className="text-xs font-medium text-neutral-700">
                  Admin UPI ID (for Driver Registration Fee)
                </span>
                <input
                  type="text"
                  maxLength={100}
                  value={adminUpiId}
                  onChange={(e) => setAdminUpiId(e.target.value)}
                  placeholder="yourname@okaxis"
                  className="mt-1.5 w-full px-3.5 py-2.5 border border-neutral-300 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </label>
            </div>

            <button
              type="submit"
              disabled={busyAction === 'fares'}
              className="w-full min-h-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-medium rounded-xl transition-colors"
            >
              {busyAction === 'fares' ? 'Publishing...' : t.saveFareSettings}
            </button>
          </form>

          <div className="lg:col-span-5 space-y-6">
            {/* Private Owner Bank Account & Settlement Card */}
            <form
              onSubmit={handleSaveBankSettings}
              className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4"
            >
              <div className="pb-3 border-b border-neutral-100 flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-emerald-700" />
                    <span>Owner Bank Account (Driver Reg Fees)</span>
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                    <span>
                      Private Admin-only storage. Customers & drivers never see your bank account or email.
                    </span>
                  </p>
                </div>
              </div>

              {payoutSettings && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 space-y-0.5">
                  <p className="font-semibold">
                    Saved Bank: {payoutSettings.bank_name} ({maskAccountNumber(payoutSettings.account_number)})
                  </p>
                  <p className="font-mono">
                    IFSC: {payoutSettings.ifsc_code} · Merchant UPI: {payoutSettings.upi_id}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="block sm:col-span-2">
                  <span className="text-xs font-medium text-neutral-700">Account Holder Name</span>
                  <input
                    type="text"
                    required
                    minLength={2}
                    maxLength={100}
                    value={accountHolderName}
                    onChange={(e) => setAccountHolderName(e.target.value)}
                    placeholder="Account Holder Name / Smart Ride"
                    className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </label>

                <label className="block">
                  <span className="text-xs font-medium text-neutral-700">Bank Name</span>
                  <input
                    type="text"
                    required
                    minLength={2}
                    maxLength={100}
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="State Bank of India"
                    className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </label>

                <label className="block">
                  <span className="text-xs font-medium text-neutral-700">IFSC Code</span>
                  <input
                    type="text"
                    required
                    maxLength={11}
                    value={ifscCode}
                    onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                    placeholder="SBIN0001234"
                    className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm font-mono uppercase focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </label>

                <label className="block">
                  <span className="text-xs font-medium text-neutral-700">Bank Account Number</span>
                  <input
                    type="text"
                    required
                    minLength={6}
                    maxLength={30}
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="123456789012"
                    className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </label>

                <label className="block">
                  <span className="text-xs font-medium text-neutral-700">Branch Name</span>
                  <input
                    type="text"
                    maxLength={100}
                    value={branchName}
                    onChange={(e) => setBranchName(e.target.value)}
                    placeholder="Guwahati / Kolkata Main"
                    className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </label>

                <label className="block sm:col-span-2">
                  <span className="text-xs font-medium text-neutral-700">
                    Bank-Linked Merchant UPI ID (PhonePe / GPay / Amazon Pay / Paytm)
                  </span>
                  <input
                    type="text"
                    required
                    maxLength={100}
                    value={adminUpiId}
                    onChange={(e) => setAdminUpiId(e.target.value)}
                    placeholder="smartride@okicici"
                    className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </label>

                <label className="block sm:col-span-2">
                  <span className="text-xs font-medium text-neutral-700">
                    Public Business Payee Name (Shown in UPI Apps)
                  </span>
                  <input
                    type="text"
                    required
                    maxLength={80}
                    value={businessPayeeName}
                    onChange={(e) => setBusinessPayeeName(e.target.value)}
                    placeholder="Smart Ride Electric Rickshaw"
                    className="mt-1 w-full px-3.5 py-2 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </label>
              </div>

              <button
                type="submit"
                disabled={busyAction === 'bank'}
                className="w-full min-h-[44px] px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 text-white text-sm font-medium rounded-xl transition-colors"
              >
                {busyAction === 'bank' ? 'Saving Bank Details...' : 'Save Owner Bank & Payout Settings'}
              </button>
            </form>

            <div className="bg-neutral-900 text-white rounded-2xl p-6 space-y-4">
              <h3 className="text-sm font-semibold text-emerald-400">
                Dynamic Fare Formula Preview
              </h3>
              <p className="text-xs text-neutral-300 leading-relaxed">
                Estimated Fare = Base Fare + (Actual Road Distance KM × Price Per KM) + Waiting Charges
              </p>
              <div className="p-4 rounded-xl bg-neutral-800 space-y-2 text-xs font-mono tabular-nums">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Base Fare</span>
                  <span>₹{baseFare}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">5.0 km × ₹{pricePerKm}/km</span>
                  <span>₹{5 * pricePerKm}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Waiting (1 min)</span>
                  <span>₹{waitingCharge}</span>
                </div>
                <div className="pt-2 border-t border-neutral-700 flex justify-between text-sm font-bold text-emerald-400">
                  <span>5 km Sample Fare</span>
                  <span>₹{exampleFiveKmFare}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Platform Commission ({commissionPct}%)</span>
                  <span>₹{((exampleFiveKmFare * commissionPct) / 100).toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION: LIVE MAP, RIDES & REPORTS */}
      {section === 'rides' && (
        <div className="space-y-6">
          <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>Live Fleet GPS & Active Rides Monitor</span>
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Showing {driverLocations.filter((d) => d.is_online && d.lat !== 0).length} online rickshaws broadcasting GPS
                </p>
              </div>
              <button
                type="button"
                onClick={handleExportRidesCsv}
                disabled={rides.length === 0}
                className="px-3.5 py-2 border border-neutral-300 hover:bg-neutral-50 disabled:opacity-50 text-neutral-800 text-xs font-medium rounded-lg inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV Report</span>
              </button>
            </div>

            <SmartRideMap
              apiKeyAvailable={mapsEnabled}
              onlineDrivers={driverLocations}
              heightClassName="h-[320px]"
            />
          </div>

          <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-neutral-900">
                Live Ride & Payment Ledger
              </h2>
              <span className="text-xs font-mono tabular-nums text-neutral-500">
                {rides.length} rides · {payments.length} payments
              </span>
            </div>
            {rides.length === 0 ? (
              <div className="py-8 text-center border-t border-neutral-100 space-y-1.5">
                <p className="text-sm font-medium text-neutral-900">No rides dispatched yet</p>
                <p className="text-xs text-neutral-500">
                  Booked rides, live driver assignments, and Cash/UPI settlement records appear here immediately.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500">
                    <tr>
                      <th className="py-2.5 px-3">Ride ID</th>
                      <th className="py-2.5 px-3">Customer / Driver</th>
                      <th className="py-2.5 px-3">Route</th>
                      <th className="py-2.5 px-3 text-right">Distance</th>
                      <th className="py-2.5 px-3 text-right">Fare</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3">Payment</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {rides.map((r) => (
                      <tr key={r.ride_id}>
                        <td className="py-2.5 px-3 font-mono">{r.ride_id}</td>
                        <td className="py-2.5 px-3">
                          <div className="font-medium text-neutral-900">
                            {r.customer_name || r.customer_id}
                          </div>
                          <div className="text-neutral-500">
                            {r.driver_name
                              ? `${r.driver_name} (${r.driver_vehicle_number})`
                              : 'Waiting for driver'}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 max-w-xs truncate">
                          {r.pickup_address} → {r.destination_address}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                          {r.distance_km} km
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                          ₹{r.final_fare || r.estimated_fare}
                        </td>
                        <td className="py-2.5 px-3 capitalize">
                          {r.ride_status.replace('_', ' ')}
                        </td>
                        <td className="py-2.5 px-3 uppercase font-mono">
                          {r.payment_status}
                          {r.payment_method ? ` (${r.payment_method})` : ''}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION: COMPLAINTS */}
      {section === 'complaints' && (
        <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
              <MessageSquareWarning className="w-4 h-4 text-amber-600" />
              <span>Customer & Driver Complaints</span>
            </h2>
            <span className="text-xs font-mono tabular-nums text-neutral-500">
              {complaints.length} tickets
            </span>
          </div>

          {complaints.length === 0 ? (
            <p className="text-xs text-neutral-500 py-6 border-t border-neutral-100 text-center">
              No customer or driver complaints filed yet.
            </p>
          ) : (
            <div className="divide-y divide-neutral-200 border-t border-neutral-100">
              {complaints.map((c) => (
                <div key={c.complaint_id} className="py-4 space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold text-neutral-900">{c.subject}</p>
                      <p className="text-xs text-neutral-500">
                        {c.reporter_name} ({c.reporter_role})
                        {c.ride_id ? ` · Ride ${c.ride_id}` : ''}
                      </p>
                    </div>
                    <span
                      className={`text-xs font-mono uppercase font-semibold ${
                        c.status === 'resolved'
                          ? 'text-emerald-700'
                          : c.status === 'dismissed'
                          ? 'text-neutral-500'
                          : 'text-amber-700'
                      }`}
                    >
                      {c.status}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-700 leading-relaxed">{c.description}</p>

                  {c.status === 'open' ? (
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={complaintNoteMap[c.complaint_id] || ''}
                        onChange={(e) =>
                          setComplaintNoteMap((prev) => ({
                            ...prev,
                            [c.complaint_id]: e.target.value,
                          }))
                        }
                        placeholder="Resolution notes for user..."
                        className="flex-1 px-3 py-1.5 border border-neutral-300 rounded-lg text-xs"
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          disabled={busyAction === c.complaint_id}
                          onClick={() => void handleResolveComplaint(c, 'resolved')}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium rounded-lg"
                        >
                          Mark Resolved
                        </button>
                        <button
                          type="button"
                          disabled={busyAction === c.complaint_id}
                          onClick={() => void handleResolveComplaint(c, 'dismissed')}
                          className="px-3 py-1.5 border border-neutral-300 text-neutral-700 hover:bg-neutral-50 text-xs font-medium rounded-lg"
                        >
                          Dismiss
                        </button>
                      </div>
                    </div>
                  ) : (
                    c.admin_notes && (
                      <p className="text-xs text-emerald-800 bg-emerald-50 px-3 py-2 rounded-lg">
                        Admin Note: {c.admin_notes}
                      </p>
                    )
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION: ADMIN ACCESS, BIOMETRIC LOCK & FIRST-RIDE APP RATINGS */}
      {section === 'admins' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Fingerprint / Biometric Lock Security Card */}
            <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Fingerprint className="w-5 h-5 text-emerald-700" />
                  <h2 className="text-base font-bold text-neutral-900">
                    {language === 'bn'
                      ? 'Admin ফিঙ্গারপ্রিন্ট লক'
                      : 'Admin Device Fingerprint Lock'}
                  </h2>
                </div>
                <span
                  className={`text-xs font-semibold ${
                    fingerprintRegistered ? 'text-emerald-700' : 'text-neutral-500'
                  }`}
                >
                  {fingerprintRegistered ? 'Enabled' : 'Not Set'}
                </span>
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                {language === 'bn'
                  ? 'আপনার ফোনের ফিঙ্গারপ্রিন্ট যুক্ত করুন যাতে প্রতিবার Admin Console খোলার আগে বায়োমেট্রিক যাচাই চায়। (সর্বোত্তম অভিজ্ঞতার জন্য Shared App URL সরাসরি Chrome-এ ব্যবহার করুন।)'
                  : 'Enroll this phone or computer fingerprint sensor so Admin Console requires biometric verification before opening.'}
              </p>

              <div className="flex flex-wrap gap-2.5">
                <button
                  type="button"
                  disabled={bioBusy}
                  onClick={() => void handleEnableFingerprint()}
                  className="min-h-[42px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-2"
                >
                  <Fingerprint className="w-4 h-4" />
                  <span>
                    {bioBusy
                      ? 'Waiting for sensor...'
                      : fingerprintRegistered
                        ? 'Re-register Fingerprint'
                        : 'Register Device Fingerprint'}
                  </span>
                </button>
                {fingerprintRegistered && (
                  <button
                    type="button"
                    onClick={handleDisableFingerprint}
                    className="min-h-[42px] px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold rounded-xl border border-neutral-300"
                  >
                    Disable Fingerprint Lock
                  </button>
                )}
              </div>
            </div>

            {/* Authorized Administrators */}
            <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <h2 className="text-base font-bold text-neutral-900">Authorized Administrators</h2>
              </div>
              <p className="text-xs text-neutral-600">
                Admin privileges are strictly enforced by Firestore Security Rules using verified identity checks. Self-registration as admin is blocked.
              </p>
              <div className="divide-y divide-neutral-100 border-t border-neutral-100">
                {admins.map((a) => (
                  <div key={a.uid} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-semibold text-neutral-900">{a.full_name}</p>
                      <p className="font-mono text-neutral-500">{a.email}</p>
                    </div>
                    <span className="font-mono text-emerald-700 font-medium">
                      {a.role} · {a.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* First-Ride App Ratings Overview */}
          <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>Customer & Driver First-Ride App Ratings</span>
              </h2>
              <span className="text-xs font-mono text-neutral-500">
                {appRatings.length} reviews
              </span>
            </div>

            {appRatings.length === 0 ? (
              <p className="text-xs text-neutral-500 py-4 border-t border-neutral-100">
                When a Customer or Driver completes their first ride and submits an app rating, it will appear here.
              </p>
            ) : (
              <div className="divide-y divide-neutral-100 border-t border-neutral-100">
                {appRatings.map((ar) => (
                  <div
                    key={ar.rating_id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                  >
                    <div className="space-y-0.5">
                      <p className="font-semibold text-neutral-900">
                        {ar.user_name}{' '}
                        <span className="font-normal text-neutral-500 capitalize">
                          ({ar.user_role})
                        </span>
                      </p>
                      {ar.feedback && <p className="text-neutral-600">{ar.feedback}</p>}
                    </div>
                    <div className="flex items-center gap-1 font-mono font-bold text-amber-600 shrink-0">
                      <span>{ar.score}/5</span>
                      <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
