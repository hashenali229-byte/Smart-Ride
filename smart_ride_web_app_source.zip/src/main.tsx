import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Tier 1 Case A Google Maps Platform Demo Key Quota Defense
(window as unknown as { gm_authFailure?: () => void }).gm_authFailure = () => {
  window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
};

const origError = console.error;
console.error = (...args: unknown[]) => {
  origError.apply(console, args);
  const msg = args.map((a) => String(a)).join(' ');
  if (msg.includes('OverQuotaMapError') || msg.includes('QuotaExceededError')) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
  }
};

// Prevent app-level zoom-in / zoom-out on Android/iOS browsers & WebViews
if (typeof document !== 'undefined') {
  const isInsideMap = (target: EventTarget | null): boolean =>
    target instanceof Element && Boolean(target.closest('.gm-style'));

  document.addEventListener(
    'touchstart',
    (e) => {
      if (e.touches.length > 1 && !isInsideMap(e.target)) {
        e.preventDefault();
      }
    },
    { passive: false }
  );

  document.addEventListener(
    'touchmove',
    (e) => {
      if (e.touches.length > 1 && !isInsideMap(e.target)) {
        e.preventDefault();
      }
    },
    { passive: false }
  );

  const preventGesture = (e: Event) => {
    if (!isInsideMap(e.target)) {
      e.preventDefault();
    }
  };
  document.addEventListener('gesturestart', preventGesture, { passive: false });
  document.addEventListener('gesturechange', preventGesture, { passive: false });
  document.addEventListener('gestureend', preventGesture, { passive: false });

  window.addEventListener(
    'wheel',
    (e) => {
      if ((e.ctrlKey || e.metaKey) && !isInsideMap(e.target)) {
        e.preventDefault();
      }
    },
    { passive: false }
  );
}

createRoot(document.getElementById('root')!).render(<App />);
