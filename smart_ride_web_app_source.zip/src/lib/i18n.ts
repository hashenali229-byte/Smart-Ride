import type { LanguageCode } from '../types/smartride';

export interface Translations {
  brandName: string;
  tagline: string;
  navCustomer: string;
  navDriver: string;
  navAdmin: string;
  navAndroid: string;
  signIn: string;
  signOut: string;
  languageLabel: string;
  customerTitle: string;
  customerWelcome: string;
  customerSubtitle: string;
  currentLocation: string;
  pickupLocation: string;
  destinationSearch: string;
  bookRideBtn: string;
  bookingHistory: string;
  customerProfile: string;
  phoneNumberLabel: string;
  sendOtp: string;
  verifyOtp: string;
  continueGoogle: string;
  saveProfile: string;
  fullName: string;
  defaultCity: string;
  liveRatesTitle: string;
  baseFare: string;
  perKm: string;
  minFare: string;
  waitingCharge: string;
  driverTitle: string;
  driverSubtitle: string;
  driverApprovalPending: string;
  driverApprovalApproved: string;
  driverApprovalRejected: string;
  goOnline: string;
  goOffline: string;
  vehicleRegNumber: string;
  vehicleType: string;
  drivingLicenseNo: string;
  rcNumber: string;
  submitVerification: string;
  dailyEarnings: string;
  completedRides: string;
  driverRating: string;
  adminTitle: string;
  adminSubtitle: string;
  totalCustomers: string;
  totalDrivers: string;
  approvedDrivers: string;
  pendingDrivers: string;
  rejectedDrivers: string;
  onlineDrivers: string;
  activeRides: string;
  completedRidesAdmin: string;
  cancelledRides: string;
  totalRevenue: string;
  approve: string;
  reject: string;
  saveFareSettings: string;
  phase2NoticeTitle: string;
  phase2NoticeBody: string;
  estimatedFareLabel: string;
  distanceLabel: string;
  etaLabel: string;
  cancelRide: string;
  payCash: string;
  payUpi: string;
  rateRideTitle: string;
  submitRating: string;
  incomingRequests: string;
  acceptRide: string;
  rejectRide: string;
  markArrived: string;
  startRide: string;
  completeRide: string;
  complaintsTitle: string;
  submitComplaint: string;
  chooseRoleTitle: string;
  chooseRoleSubtitle: string;
  roleCustomerTitle: string;
  roleCustomerDesc: string;
  roleDriverTitle: string;
  roleDriverDesc: string;
  switchRole: string;
  menuProfile: string;
  menuAddress: string;
  menuRideStatus: string;
  menuSupport: string;
  welcomeHeadline: string;
  signUpCustomerBtn: string;
  signUpDriverBtn: string;
  verifyVehicleBtn: string;
  verifyDlBtn: string;
  regFeeTitle: string;
  payRegFeeBtn: string;
  genderLabel: string;
  genderMale: string;
  genderFemale: string;
  genderOther: string;
  dobLabel: string;
  menuTerms: string;
  wallpaperLabel: string;
  uploadWallpaper: string;
  resetWallpaper: string;
  firstRideRateTitle: string;
  firstRideRateBody: string;
  submitAppRating: string;
  menuDriverIdCard: string;
  menuAppSticker: string;
  driverAddressLabel: string;
  appRegNumberLabel: string;
}

export const TRANSLATIONS: Record<LanguageCode, Translations> = {
  en: {
    brandName: 'Smart Ride',
    tagline: 'Electric Rickshaw Mobility for India',
    navCustomer: 'Customer App',
    navDriver: 'Driver App',
    navAdmin: 'Admin Console',
    navAndroid: 'Android APKs',
    signIn: 'Sign Up / Sign In',
    signOut: 'Sign Out',
    languageLabel: 'Language',
    customerTitle: 'Smart Ride Customer',
    customerWelcome: 'Welcome to Smart Ride Electric Rickshaw',
    customerSubtitle: 'Detect your GPS pickup, search destinations on Google Maps, and ride across India.',
    currentLocation: 'Current GPS Location',
    pickupLocation: 'Pickup Point',
    destinationSearch: 'Where are you going?',
    bookRideBtn: 'Book Electric Rickshaw',
    bookingHistory: 'Booking History',
    customerProfile: 'Customer Profile',
    phoneNumberLabel: 'Indian Mobile (+91)',
    sendOtp: 'Send Firebase OTP',
    verifyOtp: 'Verify OTP',
    continueGoogle: 'Continue with Google',
    saveProfile: 'Save Profile',
    fullName: 'Full Name',
    defaultCity: 'City / Town',
    liveRatesTitle: 'Live Regulated Fare Rates',
    baseFare: 'Base Fare',
    perKm: 'Per Kilometer',
    minFare: 'Minimum Fare',
    waitingCharge: 'Waiting Charge',
    driverTitle: 'Smart Ride Driver',
    driverSubtitle: 'Register your electric rickshaw, complete KYC, and accept nearby rides.',
    driverApprovalPending: 'Pending Admin Verification',
    driverApprovalApproved: 'Approved Partner',
    driverApprovalRejected: 'Application Rejected',
    goOnline: 'Go Online',
    goOffline: 'Go Offline',
    vehicleRegNumber: 'Vehicle Registration Number',
    vehicleType: 'Vehicle Type',
    drivingLicenseNo: 'Driving Licence Number',
    rcNumber: 'Registration Certificate (RC) Number',
    submitVerification: 'Submit for Admin Verification',
    dailyEarnings: 'Total Earnings',
    completedRides: 'Completed Rides',
    driverRating: 'Driver Rating',
    adminTitle: 'Smart Ride Operations & Admin Console',
    adminSubtitle: 'Verify drivers, monitor live rickshaws, manage complaints, and control INR fares.',
    totalCustomers: 'Total Customers',
    totalDrivers: 'Total Drivers',
    approvedDrivers: 'Approved Drivers',
    pendingDrivers: 'Pending Drivers',
    rejectedDrivers: 'Rejected Drivers',
    onlineDrivers: 'Online Drivers',
    activeRides: 'Active Rides',
    completedRidesAdmin: 'Completed Rides',
    cancelledRides: 'Cancelled Rides',
    totalRevenue: 'Total Revenue',
    approve: 'Approve Driver',
    reject: 'Reject Driver',
    saveFareSettings: 'Publish Fare Settings',
    phase2NoticeTitle: 'Google Maps Live Booking Active',
    phase2NoticeBody: 'Select pickup & destination to compute actual road distance, journey time, and regulated ₹ fare.',
    estimatedFareLabel: 'Estimated Fare',
    distanceLabel: 'Road Distance',
    etaLabel: 'Journey Time',
    cancelRide: 'Cancel Ride',
    payCash: 'Pay Cash to Driver',
    payUpi: 'Pay via UPI',
    rateRideTitle: 'Rate Your Electric Rickshaw Ride',
    submitRating: 'Submit Rating',
    incomingRequests: 'Nearby Ride Requests',
    acceptRide: 'Accept Ride',
    rejectRide: 'Skip',
    markArrived: 'Arrived at Pickup',
    startRide: 'Start Ride',
    completeRide: 'Complete Ride',
    complaintsTitle: 'Customer Support & Complaints',
    submitComplaint: 'Submit Support Ticket',
    chooseRoleTitle: 'Welcome to Smart Ride Electric Rickshaw',
    chooseRoleSubtitle: 'Sign up to continue as a Customer or Driver.',
    roleCustomerTitle: 'Customer Sign Up',
    roleCustomerDesc: 'Sign up to book Electric Rickshaws and track rides.',
    roleDriverTitle: 'Driver Sign Up',
    roleDriverDesc: 'Sign up to register your Electric Rickshaw and earn.',
    switchRole: 'Switch Customer / Driver',
    menuProfile: '1. Profile',
    menuAddress: '2. Address',
    menuRideStatus: '3. Ride Status',
    menuSupport: 'Customer Support',
    welcomeHeadline: 'Welcome to Smart Ride Electric Rickshaw',
    signUpCustomerBtn: 'Customer Sign Up',
    signUpDriverBtn: 'Driver Sign Up',
    verifyVehicleBtn: 'Check Real / Fake',
    verifyDlBtn: 'Check Valid / Invalid',
    regFeeTitle: 'Driver Registration Fee',
    payRegFeeBtn: 'Confirm Fee Payment',
    genderLabel: 'Gender',
    genderMale: 'Male',
    genderFemale: 'Female',
    genderOther: 'Other',
    dobLabel: 'Date of Birth',
    menuTerms: 'Terms & Conditions',
    wallpaperLabel: 'App Wallpaper',
    uploadWallpaper: 'Gallery Photo',
    resetWallpaper: 'Reset',
    firstRideRateTitle: 'First Ride Completed! Rate Smart Ride App',
    firstRideRateBody: 'Congratulations on completing your first Smart Ride! Please rate your experience with our app.',
    submitAppRating: 'Submit App Rating',
    menuDriverIdCard: 'Driver ID Card',
    menuAppSticker: 'App Vehicle Sticker',
    driverAddressLabel: 'Residential / Stand Address',
    appRegNumberLabel: 'App Registration No.',
  },
  bn: {
    brandName: 'স্মার্ট রাইড',
    tagline: 'ভারতের ইলেকট্রিক রিকশা পরিষেবা',
    navCustomer: 'গ্রাহক অ্যাপ',
    navDriver: 'চালক অ্যাপ',
    navAdmin: 'অ্যাডমিন প্যানেল',
    navAndroid: 'অ্যান্ড্রয়েড APK',
    signIn: 'সাইন আপ / সাইন ইন',
    signOut: 'সাইন আউট',
    languageLabel: 'ভাষা',
    customerTitle: 'স্মার্ট রাইড গ্রাহক',
    customerWelcome: 'স্মার্ট রাইড ইলেকট্রিক রিকশায় স্বাগতম',
    customerSubtitle: 'জিপিএস দিয়ে পিকআপ ঠিক করুন, গুগল ম্যাপে গন্তব্য খুঁজুন এবং নিরাপদে যাত্রা করুন।',
    currentLocation: 'বর্তমান জিপিএস অবস্থান',
    pickupLocation: 'পিকআপ লোকেশন',
    destinationSearch: 'আপনি কোথায় যাবেন?',
    bookRideBtn: 'ই-রিকশা বুক করুন',
    bookingHistory: 'রাইডের ইতিহাস',
    customerProfile: 'গ্রাহক প্রোফাইল',
    phoneNumberLabel: 'মোবাইল নম্বর (+৯১)',
    sendOtp: 'ফায়ারবেস OTP পাঠান',
    verifyOtp: 'OTP যাচাই করুন',
    continueGoogle: 'গুগল দিয়ে সাইন আপ করুন',
    saveProfile: 'প্রোফাইল সংরক্ষণ করুন',
    fullName: 'পূর্ণ নাম',
    defaultCity: 'শহর / এলাকা',
    liveRatesTitle: 'সরকারি নির্ধারিত ভাড়ার তালিকা',
    baseFare: 'প্রাথমিক ভাড়া',
    perKm: 'প্রতি কিমি',
    minFare: 'ন্যূনতম ভাড়া',
    waitingCharge: 'ওয়েটিং চার্জ',
    driverTitle: 'স্মার্ট রাইড চালক',
    driverSubtitle: 'আপনার ই-রিকশা নিবন্ধন করুন, কেওয়াইসি সম্পন্ন করুন এবং কাছের রাইড গ্রহণ করুন।',
    driverApprovalPending: 'অ্যাডমিন অনুমোদনের অপেক্ষায়',
    driverApprovalApproved: 'অনুমোদিত চালক',
    driverApprovalRejected: 'আবেদন বাতিল হয়েছে',
    goOnline: 'অনলাইন যান',
    goOffline: 'অফলাইন যান',
    vehicleRegNumber: 'গাড়ির রেজিস্ট্রেশন নম্বর',
    vehicleType: 'গাড়ির ধরন',
    drivingLicenseNo: 'ড্রাইভিং লাইসেন্স নম্বর',
    rcNumber: 'আরসি (RC) নম্বর',
    submitVerification: 'যাচাইয়ের জন্য জমা দিন',
    dailyEarnings: 'মোট আয়',
    completedRides: 'সম্পন্ন রাইড',
    driverRating: 'চালকের রেটিং',
    adminTitle: 'স্মার্ট রাইড অ্যাডমিন ড্যাশবোর্ড',
    adminSubtitle: 'চালকদের নথি যাচাই, লাইভ রাইড পর্যবেক্ষণ, অভিযোগ সমাধান এবং ভাড়া নির্ধারণ করুন।',
    totalCustomers: 'মোট গ্রাহক',
    totalDrivers: 'মোট চালক',
    approvedDrivers: 'অনুমোদিত চালক',
    pendingDrivers: 'অপেক্ষমাণ চালক',
    rejectedDrivers: 'বাতিল চালক',
    onlineDrivers: 'অনলাইন চালক',
    activeRides: 'চলমান রাইড',
    completedRidesAdmin: 'সম্পন্ন রাইড',
    cancelledRides: 'বাতিল রাইড',
    totalRevenue: 'মোট রাজস্ব',
    approve: 'অনুমোদন দিন',
    reject: 'বাতিল করুন',
    saveFareSettings: 'ভাড়ার নিয়ম সেভ করুন',
    phase2NoticeTitle: 'গুগল ম্যাপস লাইভ বুকিং চালু',
    phase2NoticeBody: 'সঠিক দূরত্ব, সময় এবং নির্ধারিত ₹ ভাড়া জানতে পিকআপ ও গন্তব্য নির্বাচন করুন।',
    estimatedFareLabel: 'আনুমানিক ভাড়া',
    distanceLabel: 'রাস্তার দূরত্ব',
    etaLabel: 'সময় লাগবে',
    cancelRide: 'রাইড বাতিল করুন',
    payCash: 'নগদ (Cash) পরিশোধ',
    payUpi: 'UPI দিয়ে পেমেন্ট করুন',
    rateRideTitle: 'আপনার ই-রিকশা যাত্রার রেটিং দিন',
    submitRating: 'রেটিং জমা দিন',
    incomingRequests: 'কাছের রাইড অনুরোধ',
    acceptRide: 'রাইড গ্রহণ করুন',
    rejectRide: 'এড়িয়ে যান',
    markArrived: 'পিকআপে পৌঁছেছি',
    startRide: 'যাত্রা শুরু করুন',
    completeRide: 'যাত্রা সম্পন্ন করুন',
    complaintsTitle: 'গ্রাহক সহায়তা ও অভিযোগ',
    submitComplaint: 'অভিযোগ জমা দিন',
    chooseRoleTitle: 'স্মার্ট রাইড ইলেকট্রিক রিকশায় স্বাগতম',
    chooseRoleSubtitle: 'শুরু করতে কাস্টমার অথবা ড্রাইভার হিসেবে সাইন আপ করুন।',
    roleCustomerTitle: 'কাস্টমার সাইন আপ (Customer)',
    roleCustomerDesc: 'ই-রিকশা বুক করতে সাইন আপ করুন।',
    roleDriverTitle: 'ড্রাইভার সাইন আপ (Driver)',
    roleDriverDesc: 'ই-রিকশা রেজিস্ট্রেশন ও রাইড নিতে সাইন আপ করুন।',
    switchRole: 'কাস্টমার / ড্রাইভার পরিবর্তন করুন',
    menuProfile: '১. প্রোফাইল (Profile)',
    menuAddress: '২. ঠিকানা ও ম্যাপ (Address)',
    menuRideStatus: '৩. রাইড স্ট্যাটাস (Ride Status)',
    menuSupport: 'গ্রাহক সহায়তা (Support)',
    welcomeHeadline: 'স্মার্ট রাইড ইলেকট্রিক রিকশায় স্বাগতম',
    signUpCustomerBtn: 'কাস্টমার সাইন আপ',
    signUpDriverBtn: 'ড্রাইভার সাইন আপ',
    verifyVehicleBtn: 'আসল / নকল যাচাই করুন',
    verifyDlBtn: 'বৈধ / অবৈধ যাচাই করুন',
    regFeeTitle: 'ড্রাইভার রেজিস্ট্রেশন ফি',
    payRegFeeBtn: 'রেজিস্ট্রেশন ফি পরিশোধ নিশ্চিত করুন',
    genderLabel: 'লিঙ্গ (Gender)',
    genderMale: 'পুরুষ (Male)',
    genderFemale: 'মহিলা (Female)',
    genderOther: 'অন্যান্য (Other)',
    dobLabel: 'জন্ম তারিখ (Date of Birth)',
    menuTerms: 'শর্তাবলী (Terms & Conditions)',
    wallpaperLabel: 'অ্যাপ ওয়ালপেপার (Wallpaper)',
    uploadWallpaper: 'গ্যালারি থেকে ছবি',
    resetWallpaper: 'রিসেট',
    firstRideRateTitle: 'প্রথম রাইড সম্পন্ন! Smart Ride অ্যাপ রেটিং দিন',
    firstRideRateBody: 'আপনার প্রথম রাইড সম্পন্ন করার জন্য অভিনন্দন! অনুগ্রহ করে আমাদের অ্যাপটি কেমন লাগল তা রেটিং দিয়ে জানান।',
    submitAppRating: 'অ্যাপ রেটিং জমা দিন',
    menuDriverIdCard: 'ড্রাইভার আইডি কার্ড (ID Card)',
    menuAppSticker: 'অ্যাপ গাড়ির স্টিকার (Sticker)',
    driverAddressLabel: 'ঠিকানা (Address)',
    appRegNumberLabel: 'অ্যাপ রেজিস্ট্রেশন নং',
  },
  as: {
    brandName: 'স্মাৰ্ট ৰাইড',
    tagline: 'ভাৰতৰ ইলেক্ট্ৰিক ৰিক্সা সেৱা',
    navCustomer: 'গ্ৰাহক এপ',
    navDriver: 'চালক এপ',
    navAdmin: 'এডমিন পেনেল',
    navAndroid: 'এণ্ড্ৰইড APK',
    signIn: 'ছাইন আপ / ছাইন ইন',
    signOut: 'ছাইন আউট',
    languageLabel: 'ভাষা',
    customerTitle: 'স্মাৰ্ট ৰাইড গ্ৰাহক',
    customerWelcome: 'স্মাৰ্ট ৰাইড ইলেক্ট্ৰিক ৰিক্সালৈ স্বাগতম',
    customerSubtitle: 'জিপিএছৰ জৰিয়তে পিকআপ ঠিক কৰক, গুগল মেপত গন্তব্য বিচাৰক আৰু নিৰাপদে যাত্ৰা কৰক।',
    currentLocation: 'বৰ্তমান জিপিএছ অৱস্থান',
    pickupLocation: 'পিকআপ পইণ্ট',
    destinationSearch: 'আপুনি ক’লৈ যাব?',
    bookRideBtn: 'ই-ৰিক্সা বুক কৰক',
    bookingHistory: 'ৰাইডৰ ইতিহাস',
    customerProfile: 'গ্ৰাহক প্ৰ’ফাইল',
    phoneNumberLabel: 'মোবাইল নম্বৰ (+৯১)',
    sendOtp: 'ফায়াৰবেচ OTP পঠাওক',
    verifyOtp: 'OTP পৰীক্ষা কৰক',
    continueGoogle: 'গুগলৰ সৈতে ছাইন আপ কৰক',
    saveProfile: 'প্ৰ’ফাইল সংৰক্ষণ কৰক',
    fullName: 'সম্পূৰ্ণ নাম',
    defaultCity: 'চহৰ / নগৰ',
    liveRatesTitle: 'চৰকাৰী নিৰ্ধাৰিত ভাড়াৰ তালিকা',
    baseFare: 'প্ৰাৰম্ভিক ভাড়া',
    perKm: 'প্ৰতি কিমি',
    minFare: 'ন্যূনতম ভাড়া',
    waitingCharge: 'ৱেইটিং চাৰ্জ',
    driverTitle: 'স্মাৰ্ট ৰাইড চালক',
    driverSubtitle: 'আপোনাৰ ই-ৰিক্সা পঞ্জীয়ন কৰক, কেৱাইচি সম্পূৰ্ণ কৰক আৰু ওচৰৰ ৰাইড গ্ৰহণ কৰক।',
    driverApprovalPending: 'এডমিন অনুমোদনৰ অপেক্ষাত',
    driverApprovalApproved: 'অনুমোদিত চালক',
    driverApprovalRejected: 'আবেদন বাতিল হৈছে',
    goOnline: 'অনলাইন হওক',
    goOffline: 'অফলাইন হওক',
    vehicleRegNumber: 'বাহনৰ পঞ্জীয়ন নম্বৰ',
    vehicleType: 'বাহনৰ প্ৰকাৰ',
    drivingLicenseNo: 'ড্ৰাইভিং লাইচেন্স নম্বৰ',
    rcNumber: 'আৰ চি (RC) নম্বৰ',
    submitVerification: 'পৰীক্ষাৰ বাবে দাখিল কৰক',
    dailyEarnings: 'মুঠ উপাৰ্জন',
    completedRides: 'সম্পূৰ্ণ ৰাইড',
    driverRating: 'চালকৰ ৰেটিং',
    adminTitle: 'স্মাৰ্ট ৰাইড এডমিন ডেশ্বব’ৰ্ড',
    adminSubtitle: 'চালকৰ নথিপত্ৰ পৰীক্ষা, লাইভ ৰাইড নিৰীক্ষণ, অভিযোগ সমাধান আৰু ₹ ভাড়া নিয়ন্ত্ৰণ কৰক।',
    totalCustomers: 'মুঠ গ্ৰাহক',
    totalDrivers: 'মুঠ চালক',
    approvedDrivers: 'অনুমোদিত চালক',
    pendingDrivers: 'অপেক্ষাৰত চালক',
    rejectedDrivers: 'বাতিল চালক',
    onlineDrivers: 'অনলাইন চালক',
    activeRides: 'চলন্ত ৰাইড',
    completedRidesAdmin: 'সম্পূৰ্ণ ৰাইড',
    cancelledRides: 'বাতিল ৰাইড',
    totalRevenue: 'মুঠ ৰাজহ',
    approve: 'অনুমোদন দিয়ক',
    reject: 'বাতিল কৰক',
    saveFareSettings: 'ভাড়াৰ নিয়ম সংৰক্ষণ কৰক',
    phase2NoticeTitle: 'গুগল মেপছ লাইভ বুকিং সক্ৰিয়',
    phase2NoticeBody: 'প্ৰকৃত দূৰত্ব, সময় আৰু নিৰ্ধাৰিত ₹ ভাড়া জানিবলৈ পিকআপ আৰু গন্তব্য বাছনি কৰক।',
    estimatedFareLabel: 'আনুমানিক ভাড়া',
    distanceLabel: 'পথৰ দূৰত্ব',
    etaLabel: 'সময় লাগিব',
    cancelRide: 'ৰাইড বাতিল কৰক',
    payCash: 'নগদ (Cash) পৰিশোধ',
    payUpi: 'UPI ৰে পৰিশোধ কৰক',
    rateRideTitle: 'আপোনাৰ ই-ৰিক্সা যাত্ৰাৰ ৰেটিং দিয়ক',
    submitRating: 'ৰেটিং দাখিল কৰক',
    incomingRequests: 'ওচৰৰ ৰাইড অনুৰোধ',
    acceptRide: 'ৰাইড গ্ৰহণ কৰক',
    rejectRide: 'এৰি যাওক',
    markArrived: 'পিকআপত উপস্থিত',
    startRide: 'যাত্ৰা আৰম্ভ কৰক',
    completeRide: 'যাত্ৰা সম্পূৰ্ণ কৰক',
    complaintsTitle: 'গ্ৰাহক সহায়তা আৰু অভিযোগ',
    submitComplaint: 'অভিযোগ দাখিল কৰক',
    chooseRoleTitle: 'স্মাৰ্ট ৰাইড ইলেক্ট্ৰিক ৰিক্সালৈ স্বাগতম',
    chooseRoleSubtitle: 'আৰম্ভ কৰিবলৈ গ্ৰাহক বা চালক হিচাপে ছাইন আপ কৰক।',
    roleCustomerTitle: 'গ্ৰাহক ছাইন আপ (Customer)',
    roleCustomerDesc: 'ই-ৰিক্সা বুক কৰিবলৈ ছাইন আপ কৰক।',
    roleDriverTitle: 'চালক ছাইন আপ (Driver)',
    roleDriverDesc: 'ই-ৰিক্সা পঞ্জীয়ন কৰিবলৈ ছাইন আপ কৰক।',
    switchRole: 'গ্ৰাহক / চালক সলনি কৰক',
    menuProfile: '১. প্ৰ’ফাইল (Profile)',
    menuAddress: '২. ঠিকনা আৰু মেপ (Address)',
    menuRideStatus: '৩. ৰাইড স্থিতি (Ride Status)',
    menuSupport: 'গ্ৰাহক সহায়তা (Support)',
    welcomeHeadline: 'স্মাৰ্ট ৰাইড ইলেক্ট্ৰিক ৰিক্সালৈ স্বাগতম',
    signUpCustomerBtn: 'গ্ৰাহক ছাইন আপ',
    signUpDriverBtn: 'চালক ছাইন আপ',
    verifyVehicleBtn: 'আচল / নকল পৰীক্ষা কৰক',
    verifyDlBtn: 'বৈধ / অবৈধ পৰীক্ষা কৰক',
    regFeeTitle: 'চালক পঞ্জীয়ন মাচুল',
    payRegFeeBtn: 'মাচুল পৰিশোধ নিশ্চিত কৰক',
    genderLabel: 'লিংগ (Gender)',
    genderMale: 'পুৰুষ (Male)',
    genderFemale: 'মহিলা (Female)',
    genderOther: 'অন্যান্য (Other)',
    dobLabel: 'জন্ম তাৰিখ (Date of Birth)',
    menuTerms: 'এপৰ চৰ্তাৱলী (Terms & Conditions)',
    wallpaperLabel: 'এপ ৱালপেপাৰ (Wallpaper)',
    uploadWallpaper: 'গেলাৰী ফটো',
    resetWallpaper: 'ৰিছেট',
    firstRideRateTitle: 'প্ৰথম ৰাইড সম্পূৰ্ণ! Smart Ride এপক ৰেটিং দিয়ক',
    firstRideRateBody: 'আপোনাৰ প্ৰথমটো ৰাইড সম্পূৰ্ণ কৰাৰ বাবে অভিনন্দন! অনুগ্ৰহ কৰি আমাৰ এপটো কেনে লাগিল ৰেটিং দি জনাওক।',
    submitAppRating: 'এপ ৰেটিং দাখিল কৰক',
    menuDriverIdCard: 'ড্ৰাইভাৰ আইডি কাৰ্ড (ID Card)',
    menuAppSticker: 'এপ বাহনৰ ষ্টিকাৰ (Sticker)',
    driverAddressLabel: 'ঠিকনা (Address)',
    appRegNumberLabel: 'এপ পঞ্জীয়ন নং',
  },
};
