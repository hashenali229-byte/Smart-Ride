import { firebaseAppConfig } from './firebase';

export interface FlutterTemplateFile {
  path: string;
  label: string;
  content: string;
}

export function getFlutterPackageFiles(target: 'customer' | 'driver'): FlutterTemplateFile[] {
  const isCustomer = target === 'customer';
  const appName = isCustomer ? 'Smart Ride Customer' : 'Smart Ride Driver';
  const packageId = isCustomer ? 'com.smartride.customer' : 'com.smartride.driver';
  const packagePath = packageId.replace(/\./g, '/');
  const slug = isCustomer ? 'smart_ride_customer' : 'smart_ride_driver';

  const pubspec = `name: ${slug}
description: "${appName} - Electric Rickshaw Mobility for India"
publish_to: "none"
version: 1.0.0+1

environment:
  sdk: ">=3.4.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  firebase_core: ^3.8.0
  firebase_auth: ^5.3.3
  cloud_firestore: ^5.5.0
  firebase_storage: ^12.3.6
  firebase_messaging: ^15.1.5
  google_maps_flutter: ^2.9.0
  geolocator: ^13.0.2
  image_picker: ^1.1.2
  intl: ^0.19.0
  http: ^1.2.2

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^5.0.0

flutter:
  uses-material-design: true
`;

  const firebaseOptions = `import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (defaultTargetPlatform == TargetPlatform.android) {
      return android;
    }
    throw UnsupportedError('Configure iOS/Web options via flutterfire configure.');
  }

  // Register Android app (${packageId}) in Firebase Console (${firebaseAppConfig.projectId})
  // then replace apiKey & appId or run: flutterfire configure --project=${firebaseAppConfig.projectId}
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: '${firebaseAppConfig.apiKey}',
    appId: 'REPLACE_WITH_ANDROID_APP_ID_FROM_GOOGLE_SERVICES_JSON',
    messagingSenderId: '${firebaseAppConfig.messagingSenderId}',
    projectId: '${firebaseAppConfig.projectId}',
    storageBucket: '${firebaseAppConfig.storageBucket}',
  );

  static const String firestoreDatabaseId = '${firebaseAppConfig.firestoreDatabaseId}';
}
`;

  const manifest = `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${packageId}">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    ${!isCustomer ? '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />' : ''}
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:label="${appName}"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher">

        <meta-data
            android:name="com.google.android.geo.API_KEY"
            android:value="\${MAPS_API_KEY}" />

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <meta-data android:name="flutterEmbedding" android:value="2" />
    </application>
</manifest>
`;

  const mainActivityKt = `package ${packageId}

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
`;

  const appBuildGradle = `plugins {
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
    id "com.google.gms.google-services"
}

def localProperties = new Properties()
def localPropertiesFile = rootProject.file("local.properties")
if (localPropertiesFile.exists()) {
    localPropertiesFile.withReader("UTF-8") { reader ->
        localProperties.load(reader)
    }
}

android {
    namespace = "${packageId}"
    compileSdk = 35
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "${packageId}"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        manifestPlaceholders = [
            MAPS_API_KEY: localProperties.getProperty("MAPS_API_KEY", "")
        ]
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.debug
        }
    }
}

flutter {
    source = "../.."
}
`;

  const rootBuildGradle = `allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.buildDir = "../build"
subprojects {
    project.buildDir = "\${rootProject.buildDir}/\${project.name}"
}
subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register("clean", Delete) {
    delete rootProject.buildDir
}
`;

  const settingsGradle = `pluginManagement {
    def flutterSdkPath = {
        def properties = new Properties()
        file("local.properties").withInputStream { properties.load(it) }
        def flutterSdkPath = properties.getProperty("flutter.sdk")
        assert flutterSdkPath != null, "flutter.sdk not set in local.properties"
        return flutterSdkPath
    }()

    includeBuild("\$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id "dev.flutter.flutter-plugin-loader" version "1.0.0"
    id "com.android.application" version "8.5.2" apply false
    id "org.jetbrains.kotlin.android" version "2.0.20" apply false
    id "com.google.gms.google-services" version "4.4.2" apply false
}

include ":app"
`;

  const gradleProperties = `org.gradle.jvmargs=-Xmx4G -XX:MaxMetaspaceSize=2G
android.useAndroidX=true
android.enableJetifier=true
`;

  const mainDart = `import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
import 'screens/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // Connect to the shared Smart Ride Firestore database instance
  FirebaseFirestore.instanceFor(
    app: Firebase.app(),
    databaseId: DefaultFirebaseOptions.firestoreDatabaseId,
  );

  runApp(const SmartRideApp());
}

class SmartRideApp extends StatelessWidget {
  const SmartRideApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '${appName}',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF16A34A),
          primary: const Color(0xFF16A34A),
          surface: Colors.white,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}
`;

  const splashDart = `import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'auth_screen.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      final user = FirebaseAuth.instance.currentUser;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => user == null ? const AuthScreen() : const HomeScreen(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                color: const Color(0xFF16A34A),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Icon(Icons.electric_rickshaw, color: Colors.white, size: 48),
            ),
            const SizedBox(height: 20),
            const Text(
              '${appName}',
              style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            const Text(
              'Electric Rickshaw Mobility · India',
              style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
`;

  const authDart = `import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'home_screen.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _phoneCtrl = TextEditingController();
  final _otpCtrl = TextEditingController();
  String? _verificationId;
  bool _loading = false;
  String? _error;

  Future<void> _sendOtp() async {
    setState(() { _loading = true; _error = null; });
    final phone = '+91\${_phoneCtrl.text.trim()}';
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
        if (mounted) {
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
        }
      },
      verificationFailed: (FirebaseAuthException e) {
        setState(() { _error = e.message; _loading = false; });
      },
      codeSent: (String verificationId, int? resendToken) {
        setState(() { _verificationId = verificationId; _loading = false; });
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        _verificationId = verificationId;
      },
    );
  }

  Future<void> _verifyOtp() async {
    if (_verificationId == null) return;
    setState(() { _loading = true; _error = null; });
    try {
      final cred = PhoneAuthProvider.credential(
        verificationId: _verificationId!,
        smsCode: _otpCtrl.text.trim(),
      );
      await FirebaseAuth.instance.signInWithCredential(cred);
      if (mounted) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
      }
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('${appName}', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('Sign in with your +91 Indian mobile number', style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 24),
              TextField(
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                maxLength: 10,
                decoration: const InputDecoration(
                  prefixText: '+91 ',
                  labelText: 'Mobile Number',
                  border: OutlineInputBorder(),
                ),
              ),
              if (_verificationId != null) ...[
                const SizedBox(height: 12),
                TextField(
                  controller: _otpCtrl,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  decoration: const InputDecoration(labelText: '6-digit OTP', border: OutlineInputBorder()),
                ),
              ],
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
              ],
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _loading ? null : (_verificationId == null ? _sendOtp : _verifyOtp),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF16A34A),
                  minimumSize: const Size.fromHeight(48),
                ),
                child: Text(_verificationId == null ? 'Send OTP' : 'Verify & Continue'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
`;

  const homeDart = isCustomer
    ? `import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../firebase_options.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _nameCtrl = TextEditingController();
  final _cityCtrl = TextEditingController(text: 'Kolkata');
  final _pickupCtrl = TextEditingController(text: 'Current Location');
  final _destCtrl = TextEditingController();
  LatLng _pickupPos = const LatLng(22.5726, 88.3639);
  LatLng? _destPos;
  bool _saving = false;
  bool _booking = false;

  FirebaseFirestore get _db => FirebaseFirestore.instanceFor(
    app: FirebaseFirestore.instance.app,
    databaseId: DefaultFirebaseOptions.firestoreDatabaseId,
  );

  @override
  void initState() {
    super.initState();
    _detectGps();
  }

  Future<void> _detectGps() async {
    final perm = await Geolocator.requestPermission();
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return;
    final pos = await Geolocator.getCurrentPosition();
    if (mounted) {
      setState(() {
        _pickupPos = LatLng(pos.latitude, pos.longitude);
        _pickupCtrl.text = 'GPS (\${pos.latitude.toStringAsFixed(4)}, \${pos.longitude.toStringAsFixed(4)})';
      });
    }
  }

  Future<void> _saveCustomerProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || _nameCtrl.text.trim().length < 2) return;
    setState(() => _saving = true);
    final batch = _db.batch();
    batch.set(_db.collection('users').doc(user.uid), {
      'uid': user.uid,
      'full_name': _nameCtrl.text.trim(),
      'phone_number': user.phoneNumber ?? '',
      'email': user.email ?? '',
      'role': 'customer',
      'profile_image': '',
      'account_status': 'active',
      'preferred_language': 'en',
      'created_at': FieldValue.serverTimestamp(),
      'updated_at': FieldValue.serverTimestamp(),
    });
    batch.set(_db.collection('customers').doc(user.uid), {
      'uid': user.uid,
      'full_name': _nameCtrl.text.trim(),
      'phone_number': user.phoneNumber ?? '',
      'email': user.email ?? '',
      'profile_image': '',
      'default_city': _cityCtrl.text.trim(),
      'total_rides': 0,
      'account_status': 'active',
      'created_at': FieldValue.serverTimestamp(),
      'updated_at': FieldValue.serverTimestamp(),
    });
    await batch.commit();
    if (mounted) setState(() => _saving = false);
  }

  Future<void> _bookRide(Map<String, dynamic> custData, Map<String, dynamic>? fareData) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || _destPos == null || _destCtrl.text.trim().isEmpty) return;
    setState(() => _booking = true);
    final meters = Geolocator.distanceBetween(
      _pickupPos.latitude,
      _pickupPos.longitude,
      _destPos!.latitude,
      _destPos!.longitude,
    );
    final distanceKm = double.parse((meters / 1000.0).clamp(0.5, 200.0).toStringAsFixed(2));
    final durationMinutes = (distanceKm * 3.5).ceil().clamp(3, 240);
    final baseFare = (fareData?['base_fare'] as num?)?.toDouble() ?? 20.0;
    final perKm = (fareData?['price_per_km'] as num?)?.toDouble() ?? 12.0;
    final minFare = (fareData?['minimum_fare'] as num?)?.toDouble() ?? 25.0;
    final estimatedFare = (baseFare + distanceKm * perKm).round().clamp(minFare.round(), 50000);

    final rideId = 'ride_\${DateTime.now().millisecondsSinceEpoch}';
    await _db.collection('rides').doc(rideId).set({
      'ride_id': rideId,
      'customer_id': user.uid,
      'customer_name': custData['full_name'] ?? 'Customer',
      'customer_phone': custData['phone_number'] ?? user.phoneNumber ?? '',
      'driver_id': '',
      'driver_name': '',
      'driver_phone': '',
      'driver_vehicle_number': '',
      'driver_photo': '',
      'pickup_address': _pickupCtrl.text.trim(),
      'destination_address': _destCtrl.text.trim(),
      'pickup_lat': _pickupPos.latitude,
      'pickup_lng': _pickupPos.longitude,
      'destination_lat': _destPos!.latitude,
      'destination_lng': _destPos!.longitude,
      'distance_km': distanceKm,
      'duration_minutes': durationMinutes,
      'waiting_minutes': 0,
      'estimated_fare': estimatedFare,
      'final_fare': 0,
      'ride_status': 'requested',
      'payment_status': 'pending',
      'payment_method': '',
      'cancelled_by': '',
      'created_at': FieldValue.serverTimestamp(),
      'updated_at': FieldValue.serverTimestamp(),
    });
    if (mounted) setState(() => _booking = false);
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const SizedBox.shrink();

    return Scaffold(
      appBar: AppBar(title: const Text('Smart Ride Customer')),
      body: StreamBuilder<DocumentSnapshot>(
        stream: _db.collection('customers').doc(user.uid).snapshots(),
        builder: (context, custSnap) {
          if (!custSnap.hasData || !custSnap.data!.exists) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Complete Your Customer Profile', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(controller: _cityCtrl, decoration: const InputDecoration(labelText: 'City', border: OutlineInputBorder())),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _saving ? null : _saveCustomerProfile,
                    child: Text(_saving ? 'Saving...' : 'Save Profile'),
                  ),
                ],
              ),
            );
          }

          final custData = custSnap.data!.data() as Map<String, dynamic>;
          return StreamBuilder<DocumentSnapshot>(
            stream: _db.collection('fare_settings').doc('default').snapshots(),
            builder: (context, fareSnap) {
              final fareData = fareSnap.data?.data() as Map<String, dynamic>?;
              return SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('Welcome, \${custData['full_name']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 240,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: GoogleMap(
                          initialCameraPosition: CameraPosition(target: _pickupPos, zoom: 14),
                          myLocationEnabled: true,
                          onTap: (latLng) {
                            setState(() {
                              _destPos = latLng;
                              if (_destCtrl.text.trim().isEmpty) {
                                _destCtrl.text = 'Pin (\${latLng.latitude.toStringAsFixed(4)}, \${latLng.longitude.toStringAsFixed(4)})';
                              }
                            });
                          },
                          markers: {
                            Marker(markerId: const MarkerId('pickup'), position: _pickupPos),
                            if (_destPos != null)
                              Marker(markerId: const MarkerId('dest'), position: _destPos!),
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(controller: _pickupCtrl, decoration: const InputDecoration(labelText: 'Pickup Address', border: OutlineInputBorder())),
                    const SizedBox(height: 10),
                    TextField(controller: _destCtrl, decoration: const InputDecoration(labelText: 'Destination (tap map to set pin)', border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: (_booking || _destPos == null) ? null : () => _bookRide(custData, fareData),
                      style: FilledButton.styleFrom(backgroundColor: const Color(0xFF16A34A)),
                      child: Text(_booking ? 'Requesting...' : 'Book Electric Rickshaw'),
                    ),
                    const SizedBox(height: 14),
                    Card(
                      child: ListTile(
                        leading: const Icon(Icons.currency_rupee, color: Color(0xFF16A34A)),
                        title: const Text('Live Regulated Fare Rates'),
                        subtitle: Text(
                          fareData == null
                            ? 'Loading rates...'
                            : 'Base ₹\${fareData['base_fare']} · ₹\${fareData['price_per_km']}/km · Min ₹\${fareData['minimum_fare']}',
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
`
    : `import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import '../firebase_options.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _nameCtrl = TextEditingController();
  final _vehicleCtrl = TextEditingController();
  final _dlCtrl = TextEditingController();
  final _rcCtrl = TextEditingController();
  bool _saving = false;
  StreamSubscription<Position>? _gpsSub;

  FirebaseFirestore get _db => FirebaseFirestore.instanceFor(
    app: FirebaseFirestore.instance.app,
    databaseId: DefaultFirebaseOptions.firestoreDatabaseId,
  );

  @override
  void dispose() {
    _gpsSub?.cancel();
    super.dispose();
  }

  Future<void> _toggleOnline(String uid, bool goOnline) async {
    await _db.collection('drivers').doc(uid).update({
      'is_online': goOnline,
      'updated_at': FieldValue.serverTimestamp(),
    });
    await _gpsSub?.cancel();
    if (goOnline) {
      await Geolocator.requestPermission();
      _gpsSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(distanceFilter: 15),
      ).listen((pos) {
        _db.collection('driver_locations').doc(uid).set({
          'driver_id': uid,
          'lat': pos.latitude,
          'lng': pos.longitude,
          'heading': pos.heading < 0 ? 0 : pos.heading,
          'is_online': true,
          'updated_at': FieldValue.serverTimestamp(),
        });
      });
    } else {
      await _db.collection('driver_locations').doc(uid).set({
        'driver_id': uid,
        'lat': 22.5726,
        'lng': 88.3639,
        'heading': 0,
        'is_online': false,
        'updated_at': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> _acceptRide(String rideId, Map<String, dynamic> driverData) async {
    final rideRef = _db.collection('rides').doc(rideId);
    await _db.runTransaction((tx) async {
      final snap = await tx.get(rideRef);
      if (!snap.exists) return;
      final data = snap.data() as Map<String, dynamic>;
      if (data['ride_status'] != 'requested' || (data['driver_id'] ?? '') != '') return;
      tx.update(rideRef, {
        'driver_id': driverData['uid'],
        'driver_name': driverData['full_name'],
        'driver_phone': driverData['phone_number'],
        'driver_vehicle_number': driverData['vehicle_number'],
        'driver_photo': driverData['profile_image'] ?? '',
        'ride_status': 'accepted',
        'updated_at': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> _registerDriver() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    setState(() => _saving = true);
    final batch = _db.batch();
    batch.set(_db.collection('users').doc(user.uid), {
      'uid': user.uid,
      'full_name': _nameCtrl.text.trim(),
      'phone_number': user.phoneNumber ?? '',
      'email': user.email ?? '',
      'role': 'driver',
      'profile_image': '',
      'account_status': 'active',
      'preferred_language': 'en',
      'created_at': FieldValue.serverTimestamp(),
      'updated_at': FieldValue.serverTimestamp(),
    });
    batch.set(_db.collection('drivers').doc(user.uid), {
      'uid': user.uid,
      'full_name': _nameCtrl.text.trim(),
      'phone_number': user.phoneNumber ?? '',
      'profile_image': '',
      'vehicle_number': _vehicleCtrl.text.trim().toUpperCase(),
      'vehicle_type': 'Electric Rickshaw',
      'driving_license': _dlCtrl.text.trim(),
      'vehicle_document': _rcCtrl.text.trim(),
      'approval_status': 'pending',
      'rejection_reason': '',
      'is_online': false,
      'total_completed_rides': 0,
      'total_earnings': 0,
      'rating_avg': 5.0,
      'created_at': FieldValue.serverTimestamp(),
      'updated_at': FieldValue.serverTimestamp(),
    });
    await batch.commit();
    if (mounted) setState(() => _saving = false);
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('Smart Ride Driver')),
      body: StreamBuilder<DocumentSnapshot>(
        stream: _db.collection('drivers').doc(uid).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Register Electric Rickshaw', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Driver Full Name', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(controller: _vehicleCtrl, decoration: const InputDecoration(labelText: 'Vehicle Number (e.g. WB 04 ER 2048)', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(controller: _dlCtrl, decoration: const InputDecoration(labelText: 'Driving Licence Number', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(controller: _rcCtrl, decoration: const InputDecoration(labelText: 'RC Number', border: OutlineInputBorder())),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _saving ? null : _registerDriver,
                    child: Text(_saving ? 'Submitting...' : 'Submit for Admin Approval'),
                  ),
                ],
              ),
            );
          }

          final data = snapshot.data!.data() as Map<String, dynamic>;
          final approved = data['approval_status'] == 'approved';
          final online = data['is_online'] == true;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                ListTile(
                  tileColor: Colors.grey.shade100,
                  title: Text('Approval: \${data['approval_status']}'),
                  subtitle: Text('Vehicle: \${data['vehicle_number']} · Earnings ₹\${data['total_earnings']}'),
                ),
                const SizedBox(height: 12),
                SwitchListTile(
                  title: Text(online ? 'Online for Rides' : 'Offline'),
                  subtitle: Text(approved ? 'Broadcasting GPS & receiving requests' : 'Only admin-approved drivers can go online'),
                  value: online,
                  onChanged: approved ? (val) => _toggleOnline(uid, val) : null,
                ),
                if (approved && online) ...[
                  const SizedBox(height: 16),
                  const Text('Nearby Ride Requests', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  StreamBuilder<QuerySnapshot>(
                    stream: _db.collection('rides').where('ride_status', isEqualTo: 'requested').snapshots(),
                    builder: (context, reqSnap) {
                      final docs = reqSnap.data?.docs ?? [];
                      if (docs.isEmpty) {
                        return const Text('Waiting for nearby passenger bookings...', style: TextStyle(color: Colors.black54));
                      }
                      return Column(
                        children: docs.map((d) {
                          final r = d.data() as Map<String, dynamic>;
                          return Card(
                            child: ListTile(
                              title: Text('\${r['pickup_address']} -> \${r['destination_address']}'),
                              subtitle: Text('\${r['distance_km']} km · ₹\${r['estimated_fare']}'),
                              trailing: FilledButton(
                                onPressed: () => _acceptRide(d.id, data),
                                child: const Text('Accept'),
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}
`;

  const githubActionYaml = `name: Build ${appName} APK

on:
  workflow_dispatch:
  push:
    branches: [ main ]

jobs:
  build-apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.24.0'
          channel: 'stable'
      - run: flutter create --platforms=android --org=com.smartride .
      - run: flutter pub get
      - run: flutter build apk --debug
      - run: flutter build apk --release
      - uses: actions/upload-artifact@v4
        with:
          name: ${slug}-apks
          path: |
            build/app/outputs/flutter-apk/app-debug.apk
            build/app/outputs/flutter-apk/app-release.apk
`;

  const readmeMd = `# ${appName} (${packageId})

## Prerequisites
1. Add your Android \`google-services.json\` inside \`android/app/google-services.json\` (from Firebase project \`${firebaseAppConfig.projectId}\`).
2. Add your Google Maps Android API Key inside \`android/local.properties\`:
   \`\`\`properties
   MAPS_API_KEY=YOUR_ANDROID_RESTRICTED_MAPS_API_KEY
   \`\`\`
   (Restrict the Android key in Google Cloud Console to your package name \`${packageId}\` and SHA-1 fingerprint.)

## How to Generate the Android APK (.apk)

### Option 1: Build APK in the Cloud for Free (No Android Studio Needed)
1. Upload this extracted folder to a GitHub repository.
2. Open the **Actions** tab on GitHub and run **"Build ${appName} APK"**.
3. Download \`${slug}-apks.zip\` containing \`app-debug.apk\` and \`app-release.apk\`.

### Option 2: Build APK Locally with Flutter
\`\`\`bash
flutter create --platforms=android --org=com.smartride .
flutter pub get
flutter build apk --debug
flutter build apk --release
\`\`\`
Output APK path: \`build/app/outputs/flutter-apk/app-release.apk\`
`;

  return [
    { path: `${slug}/pubspec.yaml`, label: 'pubspec.yaml', content: pubspec },
    { path: `${slug}/android/app/src/main/AndroidManifest.xml`, label: 'AndroidManifest.xml', content: manifest },
    { path: `${slug}/android/app/src/main/kotlin/${packagePath}/MainActivity.kt`, label: 'MainActivity.kt', content: mainActivityKt },
    { path: `${slug}/android/app/build.gradle`, label: 'app/build.gradle', content: appBuildGradle },
    { path: `${slug}/android/build.gradle`, label: 'android/build.gradle', content: rootBuildGradle },
    { path: `${slug}/android/settings.gradle`, label: 'settings.gradle', content: settingsGradle },
    { path: `${slug}/android/gradle.properties`, label: 'gradle.properties', content: gradleProperties },
    { path: `${slug}/lib/firebase_options.dart`, label: 'firebase_options.dart', content: firebaseOptions },
    { path: `${slug}/lib/main.dart`, label: 'main.dart', content: mainDart },
    { path: `${slug}/lib/screens/splash_screen.dart`, label: 'splash_screen.dart', content: splashDart },
    { path: `${slug}/lib/screens/auth_screen.dart`, label: 'auth_screen.dart', content: authDart },
    { path: `${slug}/lib/screens/home_screen.dart`, label: 'home_screen.dart', content: homeDart },
    { path: `${slug}/.github/workflows/build_apk.yml`, label: 'GitHub Actions APK Workflow', content: githubActionYaml },
    { path: `${slug}/README_APK_BUILD.md`, label: 'README_APK_BUILD.md', content: readmeMd },
  ];
}
