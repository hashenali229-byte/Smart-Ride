import QRCode from 'qrcode';

export type StickerTemplateId = 'windshield' | 'side_panel' | 'cabin_fare';

export interface DriverIdCardRenderParams {
  appRegNo: string;
  vehicleNumber: string;
  licenseNumber: string;
  driverName: string;
  genderLabel: string;
  dateOfBirth: string;
  address: string;
  phoneNumber: string;
  approvalStatus: 'pending' | 'approved' | 'rejected';
  photoUrl?: string;
  qrTargetUrl: string;
}

export interface VehicleStickerRenderParams {
  template: StickerTemplateId;
  appRegNo: string;
  vehicleNumber: string;
  driverName: string;
  standArea?: string;
  bookingUrl: string;
  baseFare: number;
  perKmFare: number;
  minFare: number;
}

export async function generateQrDataUrl(text: string, width = 320): Promise<string> {
  return QRCode.toDataURL(text, {
    width,
    margin: 1,
    color: {
      dark: '#0f172a',
      light: '#ffffff',
    },
    errorCorrectionLevel: 'M',
  });
}

function loadImageSafe(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    if (!src) {
      resolve(null);
      return;
    }
    const img = new Image();
    img.crossOrigin = 'anonymous';
    const timer = window.setTimeout(() => resolve(null), 3500);
    img.onload = () => {
      window.clearTimeout(timer);
      resolve(img);
    };
    img.onerror = () => {
      window.clearTimeout(timer);
      resolve(null);
    };
    img.src = src;
  });
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawWrappedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines = 2
) {
  const words = (text || '—').split(/\s+/);
  let line = '';
  let currentY = y;
  let lineCount = 0;

  for (let i = 0; i < words.length; i++) {
    const testLine = line ? `${line} ${words[i]}` : words[i];
    if (ctx.measureText(testLine).width > maxWidth && line) {
      lineCount += 1;
      if (lineCount >= maxLines) {
        ctx.fillText(`${line}...`, x, currentY);
        return;
      }
      ctx.fillText(line, x, currentY);
      line = words[i];
      currentY += lineHeight;
    } else {
      line = testLine;
    }
  }
  if (line) {
    ctx.fillText(line, x, currentY);
  }
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function canvasToPngBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error('Could not export PNG image.'));
    }, 'image/png');
  });
}

export async function renderDriverIdCardBlob(
  params: DriverIdCardRenderParams
): Promise<Blob> {
  const width = 1080;
  const height = 680;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable.');

  // Card Base
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  // Subtle Grid / Surface Border
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 4;
  drawRoundedRect(ctx, 12, 12, width - 24, height - 24, 28);
  ctx.stroke();

  // Top Header Band
  ctx.save();
  drawRoundedRect(ctx, 12, 12, width - 24, 134, 28);
  ctx.clip();
  const headerGrad = ctx.createLinearGradient(0, 0, width, 150);
  headerGrad.addColorStop(0, '#064e3b');
  headerGrad.addColorStop(1, '#047857');
  ctx.fillStyle = headerGrad;
  ctx.fillRect(12, 12, width - 24, 134);
  ctx.restore();
  // Square bottom corners of header
  ctx.fillStyle = '#065f46';
  ctx.fillRect(12, 114, width - 24, 32);

  // Brand Logo in Header
  const logoImg = await loadImageSafe('/src/assets/images/smart_ride_logo_1795224013713.jpg');
  if (logoImg) {
    ctx.save();
    drawRoundedRect(ctx, 42, 34, 88, 88, 18);
    ctx.clip();
    ctx.drawImage(logoImg, 42, 34, 88, 88);
    ctx.restore();
  } else {
    ctx.fillStyle = '#10b981';
    drawRoundedRect(ctx, 42, 34, 88, 88, 18);
    ctx.fill();
  }

  // Header Title
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 34px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('SMART RIDE ELECTRIC RICKSHAW', 152, 72);
  ctx.fillStyle = '#a7f3d0';
  ctx.font = '600 20px "DM Sans", sans-serif';
  ctx.fillText('OFFICIAL DRIVER IDENTITY CARD · INDIA', 152, 108);

  // Approval Status Label on Right of Header
  const statusText =
    params.approvalStatus === 'approved'
      ? 'VERIFIED PARTNER'
      : params.approvalStatus === 'rejected'
        ? 'REJECTED'
        : 'PENDING REVIEW';
  ctx.fillStyle = params.approvalStatus === 'approved' ? '#ecfdf5' : '#fef3c7';
  drawRoundedRect(ctx, width - 270, 48, 224, 52, 12);
  ctx.fill();
  ctx.fillStyle = params.approvalStatus === 'approved' ? '#065f46' : '#92400e';
  ctx.font = 'bold 18px "JetBrains Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(statusText, width - 158, 80);
  ctx.textAlign = 'left';

  // Left Column: Driver Photo + App Reg No + Scannable QR
  const photoImg = await loadImageSafe(
    params.photoUrl || '/src/assets/images/driver_avatar_sample_1795224014527.jpg'
  );
  ctx.save();
  drawRoundedRect(ctx, 46, 178, 210, 232, 20);
  ctx.clip();
  if (photoImg) {
    ctx.drawImage(photoImg, 46, 178, 210, 232);
  } else {
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(46, 178, 210, 232);
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 64px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText((params.driverName || 'D').charAt(0).toUpperCase(), 151, 314);
    ctx.textAlign = 'left';
  }
  ctx.restore();

  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 4;
  drawRoundedRect(ctx, 46, 178, 210, 232, 20);
  ctx.stroke();

  // QR Code Box below Photo
  const qrDataUrl = await generateQrDataUrl(params.qrTargetUrl, 240);
  const qrImg = await loadImageSafe(qrDataUrl);
  ctx.fillStyle = '#f8fafc';
  drawRoundedRect(ctx, 46, 428, 210, 174, 16);
  ctx.fill();
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 2;
  ctx.stroke();
  if (qrImg) {
    ctx.drawImage(qrImg, 86, 438, 130, 130);
  }
  ctx.fillStyle = '#334155';
  ctx.font = 'bold 14px "JetBrains Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText('SCAN TO VERIFY', 151, 588);
  ctx.textAlign = 'left';

  // Right Column: Structured Identity Grid
  const rx = 294;

  // App Registration Number Highlight Block
  ctx.fillStyle = '#ecfdf5';
  drawRoundedRect(ctx, rx, 178, 738, 86, 16);
  ctx.fill();
  ctx.strokeStyle = '#a7f3d0';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = '#047857';
  ctx.font = 'bold 16px "DM Sans", sans-serif';
  ctx.fillText('APP REGISTRATION NUMBER', rx + 22, 208);
  ctx.fillStyle = '#064e3b';
  ctx.font = 'bold 34px "JetBrains Mono", monospace';
  ctx.fillText(params.appRegNo, rx + 22, 248);

  // Vehicle Number inside Highlight Block (right side)
  ctx.fillStyle = '#047857';
  ctx.font = 'bold 16px "DM Sans", sans-serif';
  ctx.fillText('VEHICLE REGISTRATION NO.', rx + 400, 208);
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 32px "JetBrains Mono", monospace';
  ctx.fillText(params.vehicleNumber || '—', rx + 400, 248);

  // Driver Name
  ctx.fillStyle = '#64748b';
  ctx.font = '600 16px "DM Sans", sans-serif';
  ctx.fillText('DRIVER NAME', rx + 6, 304);
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 30px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(params.driverName || '—', rx + 6, 340);

  // Driving Licence Number
  ctx.fillStyle = '#64748b';
  ctx.font = '600 16px "DM Sans", sans-serif';
  ctx.fillText('DRIVING LICENCE NUMBER', rx + 400, 304);
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 24px "JetBrains Mono", monospace';
  ctx.fillText(params.licenseNumber || '—', rx + 400, 340);

  // Horizontal Divider
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(rx, 366);
  ctx.lineTo(1032, 366);
  ctx.stroke();

  // Gender / Date of Birth / Phone Row
  ctx.fillStyle = '#64748b';
  ctx.font = '600 16px "DM Sans", sans-serif';
  ctx.fillText('GENDER', rx + 6, 402);
  ctx.fillText('DATE OF BIRTH', rx + 220, 402);
  ctx.fillText('MOBILE NUMBER', rx + 470, 402);

  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 24px "DM Sans", sans-serif';
  ctx.fillText(params.genderLabel || '—', rx + 6, 438);
  ctx.font = 'bold 24px "JetBrains Mono", monospace';
  ctx.fillText(params.dateOfBirth || '—', rx + 220, 438);
  ctx.fillText(params.phoneNumber || '—', rx + 470, 438);

  // Address Box
  ctx.fillStyle = '#f8fafc';
  drawRoundedRect(ctx, rx, 466, 738, 136, 16);
  ctx.fill();
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = '#64748b';
  ctx.font = '600 16px "DM Sans", sans-serif';
  ctx.fillText('RESIDENTIAL / STAND ADDRESS', rx + 20, 498);
  ctx.fillStyle = '#0f172a';
  ctx.font = '600 22px "DM Sans", sans-serif';
  drawWrappedText(
    ctx,
    params.address || 'Address not updated yet — update in Driver ID Card menu',
    rx + 20,
    534,
    696,
    30,
    2
  );

  // Bottom Footer Strip
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(12, height - 56, width - 24, 44);
  ctx.fillStyle = '#e2e8f0';
  ctx.font = '500 16px "DM Sans", sans-serif';
  ctx.fillText('Smart Ride Electric Rickshaw · Regulated Mobility Partner ID', 42, height - 28);
  ctx.textAlign = 'right';
  ctx.fillStyle = '#6ee7b7';
  ctx.font = '600 16px "JetBrains Mono", monospace';
  ctx.fillText(params.appRegNo, width - 42, height - 28);
  ctx.textAlign = 'left';

  return canvasToPngBlob(canvas);
}

export async function renderVehicleStickerBlob(
  params: VehicleStickerRenderParams
): Promise<Blob> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable.');

  const logoImg = await loadImageSafe('/src/assets/images/smart_ride_logo_1795224013713.jpg');
  const qrDataUrl = await generateQrDataUrl(params.bookingUrl, 480);
  const qrImg = await loadImageSafe(qrDataUrl);

  if (params.template === 'windshield') {
    const w = 1600;
    const h = 620;
    canvas.width = w;
    canvas.height = h;

    // Deep Emerald Transit Banner Background
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, '#022c22');
    grad.addColorStop(0.55, '#065f46');
    grad.addColorStop(1, '#047857');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Outer Safety Border
    ctx.strokeStyle = '#34d399';
    ctx.lineWidth = 10;
    drawRoundedRect(ctx, 20, 20, w - 40, h - 40, 34);
    ctx.stroke();

    // Left Logo Block
    if (logoImg) {
      ctx.save();
      drawRoundedRect(ctx, 64, 72, 160, 160, 28);
      ctx.clip();
      ctx.drawImage(logoImg, 64, 72, 160, 160);
      ctx.restore();
    }

    // Main Typography
    ctx.fillStyle = '#a7f3d0';
    ctx.font = 'bold 26px "JetBrains Mono", monospace';
    ctx.fillText('VERIFIED ELECTRIC RICKSHAW · INDIA', 260, 108);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 82px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('SMART RIDE', 256, 198);

    ctx.fillStyle = '#ecfdf5';
    ctx.font = '600 32px "DM Sans", sans-serif';
    ctx.fillText('Scan QR Code to Book Ride · Safe & Regulated INR Fare', 260, 250);

    // Vehicle Number & App Reg Bar
    ctx.fillStyle = '#ffffff';
    drawRoundedRect(ctx, 64, 326, 1020, 212, 24);
    ctx.fill();

    ctx.fillStyle = '#64748b';
    ctx.font = 'bold 22px "DM Sans", sans-serif';
    ctx.fillText('VEHICLE REG. NO.', 102, 376);
    ctx.fillText('APP REGISTRATION NO.', 570, 376);

    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 54px "JetBrains Mono", monospace';
    ctx.fillText(params.vehicleNumber || 'AS 01 ER 2048', 102, 440);
    ctx.fillStyle = '#047857';
    ctx.font = 'bold 42px "JetBrains Mono", monospace';
    ctx.fillText(params.appRegNo, 570, 440);

    ctx.fillStyle = '#334155';
    ctx.font = '600 26px "DM Sans", sans-serif';
    ctx.fillText(
      `Partner: ${params.driverName}${params.standArea ? ` · ${params.standArea}` : ''}`,
      102,
      504
    );

    // Right QR White Card
    ctx.fillStyle = '#ffffff';
    drawRoundedRect(ctx, 1130, 64, 406, 474, 28);
    ctx.fill();
    if (qrImg) {
      ctx.drawImage(qrImg, 1168, 92, 330, 330);
    }
    ctx.fillStyle = '#064e3b';
    ctx.font = 'bold 28px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('SCAN TO BOOK RIDE', 1333, 466);
    ctx.fillStyle = '#475569';
    ctx.font = 'bold 20px "JetBrains Mono", monospace';
    ctx.fillText(`Base ₹${params.baseFare} · ₹${params.perKmFare}/km`, 1333, 508);
    ctx.textAlign = 'left';

    return canvasToPngBlob(canvas);
  }

  if (params.template === 'side_panel') {
    const w = 1200;
    const h = 1200;
    canvas.width = w;
    canvas.height = h;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);

    // Outer Emerald Decal Frame
    ctx.strokeStyle = '#047857';
    ctx.lineWidth = 22;
    drawRoundedRect(ctx, 26, 26, w - 52, h - 52, 48);
    ctx.stroke();

    // Top Header
    ctx.fillStyle = '#064e3b';
    drawRoundedRect(ctx, 56, 56, w - 112, 230, 34);
    ctx.fill();

    if (logoImg) {
      ctx.save();
      drawRoundedRect(ctx, 94, 96, 150, 150, 28);
      ctx.clip();
      ctx.drawImage(logoImg, 94, 96, 150, 150);
      ctx.restore();
    }

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 74px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('SMART RIDE', 274, 168);
    ctx.fillStyle = '#a7f3d0';
    ctx.font = '600 32px "DM Sans", sans-serif';
    ctx.fillText('Book Verified Electric Rickshaw', 278, 220);

    // Center Huge QR Block
    ctx.fillStyle = '#f8fafc';
    drawRoundedRect(ctx, 270, 326, 660, 520, 36);
    ctx.fill();
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 4;
    ctx.stroke();

    if (qrImg) {
      ctx.drawImage(qrImg, 390, 356, 420, 420);
    }
    ctx.fillStyle = '#047857';
    ctx.font = 'bold 34px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('SCAN QR WITH PHONE CAMERA', 600, 818);

    // Bottom Vehicle Details Plate
    ctx.fillStyle = '#0f172a';
    drawRoundedRect(ctx, 72, 882, w - 144, 238, 28);
    ctx.fill();

    ctx.fillStyle = '#6ee7b7';
    ctx.font = 'bold 24px "DM Sans", sans-serif';
    ctx.fillText('VEHICLE REGISTRATION NUMBER', 600, 932);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 64px "JetBrains Mono", monospace';
    ctx.fillText(params.vehicleNumber || 'AS 01 ER 2048', 600, 1006);

    ctx.fillStyle = '#cbd5e1';
    ctx.font = '600 28px "JetBrains Mono", monospace';
    ctx.fillText(`${params.appRegNo}  ·  ${params.driverName}`, 600, 1072);
    ctx.textAlign = 'left';

    return canvasToPngBlob(canvas);
  }

  // 'cabin_fare' (960 x 1280)
  const w = 960;
  const h = 1280;
  canvas.width = w;
  canvas.height = h;

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth = 10;
  drawRoundedRect(ctx, 24, 24, w - 48, h - 48, 36);
  ctx.stroke();

  // Top Header
  ctx.fillStyle = '#047857';
  drawRoundedRect(ctx, 48, 48, w - 96, 190, 26);
  ctx.fill();

  if (logoImg) {
    ctx.save();
    drawRoundedRect(ctx, 82, 78, 130, 130, 24);
    ctx.clip();
    ctx.drawImage(logoImg, 82, 78, 130, 130);
    ctx.restore();
  }

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 52px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('SMART RIDE', 240, 134);
  ctx.fillStyle = '#d1fae5';
  ctx.font = '600 26px "DM Sans", sans-serif';
  ctx.fillText('PASSENGER CABIN · DRIVER & FARE CARD', 240, 182);

  // Driver Info Box
  ctx.fillStyle = '#f8fafc';
  drawRoundedRect(ctx, 48, 270, w - 96, 290, 24);
  ctx.fill();
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = '#64748b';
  ctx.font = 'bold 20px "DM Sans", sans-serif';
  ctx.fillText('VERIFIED DRIVER NAME', 84, 318);
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 38px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(params.driverName || 'Smart Ride Partner', 84, 364);

  ctx.fillStyle = '#64748b';
  ctx.font = 'bold 20px "DM Sans", sans-serif';
  ctx.fillText('VEHICLE NO.', 84, 434);
  ctx.fillText('APP REG. NO.', 500, 434);

  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 34px "JetBrains Mono", monospace';
  ctx.fillText(params.vehicleNumber || '—', 84, 480);
  ctx.fillStyle = '#047857';
  ctx.fillText(params.appRegNo, 500, 480);

  if (params.standArea) {
    ctx.fillStyle = '#475569';
    ctx.font = '600 22px "DM Sans", sans-serif';
    ctx.fillText(`Route / Stand: ${params.standArea}`, 84, 532);
  }

  // Fare Tariff Card
  ctx.fillStyle = '#ecfdf5';
  drawRoundedRect(ctx, 48, 592, w - 96, 178, 24);
  ctx.fill();
  ctx.strokeStyle = '#6ee7b7';
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = '#065f46';
  ctx.font = 'bold 24px "DM Sans", sans-serif';
  ctx.fillText('REGULATED OFFICIAL INR FARE RATES', 84, 642);

  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 34px "JetBrains Mono", monospace';
  ctx.fillText(
    `Base: ₹${params.baseFare}   |   Per Km: ₹${params.perKmFare}   |   Min: ₹${params.minFare}`,
    84,
    706
  );

  // QR Scan Box
  ctx.fillStyle = '#ffffff';
  drawRoundedRect(ctx, 210, 804, w - 420, 404, 28);
  ctx.fill();
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 3;
  ctx.stroke();

  if (qrImg) {
    ctx.drawImage(qrImg, 320, 830, 320, 320);
  }
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 26px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('SCAN TO BOOK OR RATE RIDE', 480, 1184);
  ctx.textAlign = 'left';

  return canvasToPngBlob(canvas);
}
