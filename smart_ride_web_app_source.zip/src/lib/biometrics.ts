const BIOMETRIC_CRED_KEY = 'smart_ride_admin_bio_v1';

interface StoredBiometricMeta {
  credentialId: string;
  registeredAt: string;
}

function bufferToBase64Url(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i += 1) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function base64UrlToUint8Array(base64Url: string): Uint8Array {
  const padding = '='.repeat((4 - (base64Url.length % 4)) % 4);
  const base64 = (base64Url + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) {
    out[i] = raw.charCodeAt(i);
  }
  return out;
}

export async function isPlatformBiometricSupported(): Promise<boolean> {
  if (typeof window === 'undefined' || !('PublicKeyCredential' in window)) {
    return false;
  }
  try {
    return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

export function getRegisteredFingerprintMeta(): StoredBiometricMeta | null {
  try {
    const raw = window.localStorage.getItem(BIOMETRIC_CRED_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredBiometricMeta;
    if (parsed && typeof parsed.credentialId === 'string' && parsed.credentialId.length > 0) {
      return parsed;
    }
  } catch {
    // Ignore invalid storage entries
  }
  return null;
}

export function clearRegisteredFingerprint(): void {
  try {
    window.localStorage.removeItem(BIOMETRIC_CRED_KEY);
  } catch {
    // Ignore storage errors
  }
}

export async function registerDeviceFingerprint(
  uid: string
): Promise<{ ok: boolean; error?: string }> {
  if (!(await isPlatformBiometricSupported())) {
    return {
      ok: false,
      error:
        'Device fingerprint/biometric sensor is not available in this browser or preview frame. Open the app directly in Chrome on Android to register fingerprint.',
    };
  }

  try {
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);
    const userIdBytes = new TextEncoder().encode(uid.slice(0, 64));

    const credential = (await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: {
          name: 'Smart Ride Admin Console',
          id: window.location.hostname,
        },
        user: {
          id: userIdBytes,
          name: 'smart-ride-admin',
          displayName: 'Smart Ride Admin',
        },
        pubKeyCredParams: [
          { type: 'public-key', alg: -7 },
          { type: 'public-key', alg: -257 },
        ],
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'required',
          residentKey: 'preferred',
        },
        timeout: 60000,
      },
    })) as PublicKeyCredential | null;

    if (!credential) {
      return { ok: false, error: 'Fingerprint registration was cancelled.' };
    }

    const meta: StoredBiometricMeta = {
      credentialId: bufferToBase64Url(credential.rawId),
      registeredAt: new Date().toISOString(),
    };
    window.localStorage.setItem(BIOMETRIC_CRED_KEY, JSON.stringify(meta));
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.toLowerCase().includes('notallowed') || msg.toLowerCase().includes('permissions')) {
      return {
        ok: false,
        error:
          'Fingerprint prompt was blocked or cancelled. If inside an embedded preview, open the Shared App URL in Chrome to use device fingerprint.',
      };
    }
    return { ok: false, error: msg };
  }
}

export async function verifyDeviceFingerprint(): Promise<{ ok: boolean; error?: string }> {
  const meta = getRegisteredFingerprintMeta();
  if (!meta) {
    return {
      ok: false,
      error: 'No fingerprint registered on this device yet. Sign in first to enable Fingerprint Lock.',
    };
  }
  if (!(await isPlatformBiometricSupported())) {
    return {
      ok: false,
      error:
        'Fingerprint sensor is unavailable in this browser context. Sign in using Google or Email & Password.',
    };
  }

  try {
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);
    const rawIdBytes = base64UrlToUint8Array(meta.credentialId);
    const allowIdBuffer = rawIdBytes.buffer.slice(
      rawIdBytes.byteOffset,
      rawIdBytes.byteOffset + rawIdBytes.byteLength
    ) as ArrayBuffer;

    const assertion = await navigator.credentials.get({
      publicKey: {
        challenge,
        rpId: window.location.hostname,
        allowCredentials: [
          {
            type: 'public-key',
            id: allowIdBuffer,
            transports: ['internal'],
          },
        ],
        userVerification: 'required',
        timeout: 60000,
      },
    });

    if (!assertion) {
      return { ok: false, error: 'Fingerprint verification was cancelled.' };
    }
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.toLowerCase().includes('notallowed') || msg.toLowerCase().includes('cancel')) {
      return {
        ok: false,
        error: 'Fingerprint scan cancelled or blocked. Try again or use Google / Email & Password.',
      };
    }
    return { ok: false, error: msg };
  }
}
