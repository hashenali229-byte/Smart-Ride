/**
 * Defensive Payload Constraints & Blueprint Validation Synchronicity
 * Bounds mirror /firebase-blueprint.json verbatim.
 */

export const FIELD_LIMITS = {
  UID_MAX: 128,
  NAME_MIN: 2,
  NAME_MAX: 100,
  PHONE_MAX: 20,
  EMAIL_MAX: 150,
  URL_MAX: 1000,
  CITY_MAX: 80,
  ADDRESS_MAX: 300,
  VEHICLE_NUMBER_MIN: 4,
  VEHICLE_NUMBER_MAX: 20,
  DOC_NUMBER_MIN: 4,
  DOC_NUMBER_MAX: 40,
  NOTES_MAX: 400,
  REJECTION_MAX: 300,
  FEEDBACK_MAX: 500,
  SUBJECT_MAX: 120,
  DESCRIPTION_MAX: 600,
} as const;

export const PATTERNS = {
  VALID_ID: /^[a-zA-Z0-9_-]+$/,
  VEHICLE_NUMBER: /^[A-Z0-9\- ]{4,20}$/,
  INDIAN_PHONE_E164: /^\+91[6-9][0-9]{9}$/,
} as const;

export function clampText(value: string, maxLength: number): string {
  return value.trim().slice(0, maxLength);
}

export function formatIndianPhone(raw: string): string {
  const digits = raw.replace(/\D/g, '');
  if (digits.length === 10) {
    return `+91${digits}`;
  }
  if (digits.length === 12 && digits.startsWith('91')) {
    return `+${digits}`;
  }
  if (raw.trim().startsWith('+91')) {
    return `+91${digits.slice(2, 12)}`;
  }
  return clampText(raw, FIELD_LIMITS.PHONE_MAX);
}

export function isValidIndianPhone(phone: string): boolean {
  return PATTERNS.INDIAN_PHONE_E164.test(phone.trim());
}

export function normalizeVehicleNumber(raw: string): string {
  return raw.toUpperCase().replace(/[^A-Z0-9\- ]/g, '').trim().slice(0, FIELD_LIMITS.VEHICLE_NUMBER_MAX);
}

export function isValidVehicleNumber(regNo: string): boolean {
  return PATTERNS.VEHICLE_NUMBER.test(regNo.trim());
}

export const INDIAN_STATE_RTO_CODES: Record<string, string> = {
  AN: 'Andaman & Nicobar',
  AP: 'Andhra Pradesh',
  AR: 'Arunachal Pradesh',
  AS: 'Assam',
  BR: 'Bihar',
  CG: 'Chhattisgarh',
  CH: 'Chandigarh',
  DD: 'Dadra & Nagar Haveli and Daman & Diu',
  DL: 'Delhi',
  GA: 'Goa',
  GJ: 'Gujarat',
  HP: 'Himachal Pradesh',
  HR: 'Haryana',
  JH: 'Jharkhand',
  JK: 'Jammu & Kashmir',
  KA: 'Karnataka',
  KL: 'Kerala',
  LA: 'Ladakh',
  LD: 'Lakshadweep',
  MH: 'Maharashtra',
  ML: 'Meghalaya',
  MN: 'Manipur',
  MP: 'Madhya Pradesh',
  MZ: 'Mizoram',
  NL: 'Nagaland',
  OD: 'Odisha',
  OR: 'Odisha',
  PB: 'Punjab',
  PY: 'Puducherry',
  RJ: 'Rajasthan',
  SK: 'Sikkim',
  TG: 'Telangana',
  TN: 'Tamil Nadu',
  TR: 'Tripura',
  TS: 'Telangana',
  UK: 'Uttarakhand',
  UP: 'Uttar Pradesh',
  WB: 'West Bengal',
};

export interface VehicleCheckResult {
  isValidFormat: boolean;
  status: 'valid_format' | 'invalid_format';
  stateName: string;
  normalized: string;
  message: string;
}

export function verifyIndianVehicleNumber(raw: string): VehicleCheckResult {
  const normalized = normalizeVehicleNumber(raw);
  const compact = normalized.replace(/[^A-Z0-9]/g, '');

  const bhMatch = compact.match(/^(\d{2})BH(\d{4})([A-Z]{1,2})$/);
  if (bhMatch) {
    const [, yy, num] = bhMatch;
    if (num === '0000') {
      return {
        isValidFormat: false,
        status: 'invalid_format',
        stateName: '',
        normalized,
        message: 'Fake/dummy plate detected (0000 is invalid).',
      };
    }
    return {
      isValidFormat: true,
      status: 'valid_format',
      stateName: `BH-Series (20${yy})`,
      normalized,
      message: `Valid Indian BH-Series RTO format (Year 20${yy}).`,
    };
  }

  const stdMatch = compact.match(/^([A-Z]{2})(\d{2})([A-Z]{1,3})(\d{4})$/);
  if (!stdMatch) {
    return {
      isValidFormat: false,
      status: 'invalid_format',
      stateName: '',
      normalized,
      message: 'Invalid/Fake format. Expected Indian RTO format like AS 01 ER 2048 or WB 04 ER 2048.',
    };
  }

  const [, stateCode, rtoDistrict, series, serial] = stdMatch;
  const stateName = INDIAN_STATE_RTO_CODES[stateCode];
  if (!stateName) {
    return {
      isValidFormat: false,
      status: 'invalid_format',
      stateName: '',
      normalized,
      message: `Unknown/Fake Indian State RTO code "${stateCode}".`,
    };
  }
  if (rtoDistrict === '00' || serial === '0000') {
    return {
      isValidFormat: false,
      status: 'invalid_format',
      stateName,
      normalized,
      message: 'Invalid/Fake RTO district "00" or serial "0000".',
    };
  }

  return {
    isValidFormat: true,
    status: 'valid_format',
    stateName,
    normalized: `${stateCode} ${rtoDistrict} ${series} ${serial}`,
    message: `Valid Indian RTO format (${stateName}, RTO-${rtoDistrict}). Ready for Admin Parivahan check.`,
  };
}

export interface DrivingLicenceCheckResult {
  isValid: boolean;
  status: 'valid' | 'invalid' | 'expired';
  stateName: string;
  normalized: string;
  message: string;
}

export function verifyIndianDrivingLicence(
  raw: string,
  expiryDate?: string
): DrivingLicenceCheckResult {
  const normalized = raw.toUpperCase().replace(/[^A-Z0-9\- ]/g, '').trim().slice(0, FIELD_LIMITS.DOC_NUMBER_MAX);
  const compact = normalized.replace(/[^A-Z0-9]/g, '');

  const dlMatch = compact.match(/^([A-Z]{2})(\d{2})((?:19|20)\d{2})(\d{7})$/);
  if (!dlMatch) {
    return {
      isValid: false,
      status: 'invalid',
      stateName: '',
      normalized,
      message: 'Invalid Driving Licence format. Expected Sarathi format e.g. AS01 20210012345 (15 chars).',
    };
  }

  const [, stateCode, rtoCode, yearStr, serial] = dlMatch;
  const stateName = INDIAN_STATE_RTO_CODES[stateCode];
  if (!stateName) {
    return {
      isValid: false,
      status: 'invalid',
      stateName: '',
      normalized,
      message: `Invalid state code "${stateCode}" in Driving Licence.`,
    };
  }

  const issueYear = Number(yearStr);
  const currentYear = new Date().getFullYear();
  if (rtoCode === '00' || serial === '0000000' || issueYear < 1970 || issueYear > currentYear) {
    return {
      isValid: false,
      status: 'invalid',
      stateName,
      normalized,
      message: 'Invalid Driving Licence year, RTO code, or serial number.',
    };
  }

  if (expiryDate) {
    const exp = new Date(expiryDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (!Number.isNaN(exp.getTime()) && exp < today) {
      return {
        isValid: false,
        status: 'expired',
        stateName,
        normalized,
        message: `Driving Licence EXPIRED on ${expiryDate}. Renew before applying.`,
      };
    }
  }

  return {
    isValid: true,
    status: 'valid',
    stateName,
    normalized: `${stateCode}${rtoCode} ${yearStr}${serial}`,
    message: `Valid Indian Driving Licence (${stateName} · Issued ${issueYear}).`,
  };
}

export function sanitizeImageUrl(url: string): string {
  const trimmed = url.trim().slice(0, FIELD_LIMITS.URL_MAX);
  if (!trimmed) return '';
  if (
    trimmed.startsWith('https://') ||
    trimmed.startsWith('/src/assets/images/')
  ) {
    return trimmed;
  }
  return '';
}

export function calculateSmartRideFare(params: {
  distanceKm: number;
  waitingMinutes?: number;
  baseFare: number;
  pricePerKm: number;
  minimumFare: number;
  waitingCharge: number;
}): number {
  const dist = Math.max(0, params.distanceKm);
  const wait = Math.max(0, params.waitingMinutes ?? 0);
  const raw = params.baseFare + dist * params.pricePerKm + wait * params.waitingCharge;
  return Math.round(Math.max(params.minimumFare, raw));
}

export function validateDateOfBirth(
  dob: string,
  minAgeYears: number
): { valid: boolean; age: number; message: string } {
  const trimmed = dob.trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    return { valid: false, age: 0, message: 'Please select a valid Date of Birth.' };
  }
  const birth = new Date(`${trimmed}T00:00:00`);
  if (Number.isNaN(birth.getTime()) || birth.getFullYear() < 1920) {
    return { valid: false, age: 0, message: 'Please enter a valid Date of Birth after 1920.' };
  }
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age -= 1;
  }
  if (birth > today) {
    return { valid: false, age: 0, message: 'Date of Birth cannot be in the future.' };
  }
  if (age < minAgeYears) {
    return {
      valid: false,
      age,
      message: `Minimum age required is ${minAgeYears} years.`,
    };
  }
  return { valid: true, age, message: '' };
}

export function isValidIfscCode(ifsc: string): boolean {
  return /^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc.trim().toUpperCase());
}

export function maskAccountNumber(accountNo: string): string {
  const clean = accountNo.replace(/\s+/g, '');
  if (clean.length <= 4) return clean;
  return `${'•'.repeat(Math.max(4, clean.length - 4))} ${clean.slice(-4)}`;
}

export function buildUpiPaymentLink(params: {
  upiId: string;
  payeeName: string;
  amount: number;
  note: string;
  app?: 'phonepe' | 'gpay' | 'amazonpay' | 'paytm' | 'upi';
}): string {
  const query = `pa=${encodeURIComponent(params.upiId)}&pn=${encodeURIComponent(
    params.payeeName || 'Smart Ride Electric Rickshaw'
  )}&am=${encodeURIComponent(String(params.amount))}&cu=INR&tn=${encodeURIComponent(
    params.note
  )}`;
  switch (params.app) {
    case 'phonepe':
      return `phonepe://pay?${query}`;
    case 'gpay':
      return `tez://upi/pay?${query}`;
    case 'amazonpay':
      return `amazonpay://upi/pay?${query}`;
    case 'paytm':
      return `paytmmp://pay?${query}`;
    default:
      return `upi://pay?${query}`;
  }
}

export function formatDriverAppRegNo(uid: string): string {
  const clean = uid.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  const code = (clean.slice(0, 8) || 'SMARTRID').padEnd(8, '0');
  return `SR-DRV-${code}`;
}

