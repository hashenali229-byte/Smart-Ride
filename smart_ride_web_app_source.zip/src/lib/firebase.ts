import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, type User } from 'firebase/auth';
import { doc, getDoc, getDocFromServer, getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });
export const firebaseAppConfig = firebaseConfig;

export const ADMIN_SESSION_TTL_MS = 12 * 60 * 60 * 1000;
export const ADMIN_OTP_EMAIL_STORAGE_KEY = 'smart_ride_admin_otp_email_v1';
export const ADMIN_SESSION_EXPIRED_KEY = 'smart_ride_admin_expired_v1';

export interface AdminSessionTiming {
  valid: boolean;
  authTimeMs: number;
  expiresAtMs: number;
  remainingMs: number;
}

export async function getAdminSessionTiming(
  currentUser: User | null
): Promise<AdminSessionTiming> {
  if (!currentUser) {
    return { valid: false, authTimeMs: 0, expiresAtMs: 0, remainingMs: 0 };
  }
  try {
    const tokenRes = await currentUser.getIdTokenResult();
    const parsedAuth = Date.parse(tokenRes.authTime);
    const authTimeMs = Number.isFinite(parsedAuth) ? parsedAuth : Date.now();
    const expiresAtMs = authTimeMs + ADMIN_SESSION_TTL_MS;
    const remainingMs = Math.max(0, expiresAtMs - Date.now());
    return {
      valid: remainingMs > 0,
      authTimeMs,
      expiresAtMs,
      remainingMs,
    };
  } catch {
    return {
      valid: true,
      authTimeMs: Date.now(),
      expiresAtMs: Date.now() + ADMIN_SESSION_TTL_MS,
      remainingMs: ADMIN_SESSION_TTL_MS,
    };
  }
}

export interface AdminSessionCheckResult {
  allowed: boolean;
  reason?: 'not_signed_in' | 'not_admin' | 'network_error' | 'session_expired';
  errorMessage?: string;
}

export async function verifyAdminSessionDetailed(
  currentUser: User | null
): Promise<AdminSessionCheckResult> {
  if (!currentUser) {
    return { allowed: false, reason: 'not_signed_in' };
  }

  const timing = await getAdminSessionTiming(currentUser);
  if (!timing.valid) {
    return {
      allowed: false,
      reason: 'session_expired',
      errorMessage: '12-hour Admin login validity expired. Please sign in again.',
    };
  }

  try {
    await currentUser.getIdToken();
  } catch {
    // Continue to Firestore check
  }

  const probeOnce = async (): Promise<AdminSessionCheckResult> => {
    try {
      const ownAdminSnap = await getDocFromServer(doc(db, 'admin_users', currentUser.uid));
      if (ownAdminSnap.exists() && ownAdminSnap.data()?.status === 'active') {
        return { allowed: true };
      }
    } catch {
      // Ignore missing/denied own doc and proceed to bootstrap probe
    }

    try {
      await getDocFromServer(doc(db, 'admin_users', 'boot_probe_check'));
      return { allowed: true };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      const code = (err as { code?: string })?.code || '';
      if (
        code === 'unavailable' ||
        msg.includes('offline') ||
        msg.includes('network')
      ) {
        return { allowed: false, reason: 'network_error', errorMessage: msg };
      }
      return { allowed: false, reason: 'not_admin', errorMessage: msg };
    }
  };

  const firstAttempt = await probeOnce();
  if (firstAttempt.allowed || firstAttempt.reason === 'network_error') {
    return firstAttempt;
  }

  // Retry once after forcing a fresh ID token in case Auth -> Firestore sync lagged right after login
  try {
    await currentUser.getIdToken(true);
    return await probeOnce();
  } catch {
    return firstAttempt;
  }
}

export async function verifyAdminSession(currentUser: User | null): Promise<boolean> {
  const result = await verifyAdminSessionDetailed(currentUser);
  return result.allowed;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<{ ok: boolean; offline: boolean }> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return { ok: true, offline: false };
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
      return { ok: false, offline: true };
    }
    return { ok: true, offline: false };
  }
}

void testConnection();
