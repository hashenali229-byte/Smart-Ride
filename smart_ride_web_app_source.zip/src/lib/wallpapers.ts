export type WallpaperPresetId = 'clean' | 'mint' | 'sunrise' | 'sky' | 'midnight' | 'custom';

export interface WallpaperConfig {
  id: WallpaperPresetId;
  customImage?: string;
}

export interface WallpaperOption {
  id: Exclude<WallpaperPresetId, 'custom'>;
  labelEn: string;
  labelBn: string;
  labelAs: string;
  swatchClass: string;
  containerClass: string;
  isDarkCanvas: boolean;
}

const WALLPAPER_STORAGE_KEY = 'smart_ride_wallpaper_v1';

export const WALLPAPER_OPTIONS: WallpaperOption[] = [
  {
    id: 'clean',
    labelEn: 'Classic',
    labelBn: 'সাধারণ',
    labelAs: 'সাধাৰণ',
    swatchClass: 'bg-neutral-100 border-neutral-300',
    containerClass: 'bg-neutral-50 text-neutral-900',
    isDarkCanvas: false,
  },
  {
    id: 'mint',
    labelEn: 'Eco Mint',
    labelBn: 'ইকো সবুজ',
    labelAs: 'ইক’ সেউজীয়া',
    swatchClass: 'bg-gradient-to-br from-emerald-100 to-teal-200 border-emerald-400',
    containerClass: 'bg-gradient-to-br from-emerald-50 via-teal-50/70 to-neutral-50 text-neutral-900',
    isDarkCanvas: false,
  },
  {
    id: 'sunrise',
    labelEn: 'Sunrise',
    labelBn: 'সোনালি সকাল',
    labelAs: 'সোণালী পুৱা',
    swatchClass: 'bg-gradient-to-br from-amber-100 to-orange-200 border-amber-400',
    containerClass: 'bg-gradient-to-br from-amber-50/80 via-orange-50/40 to-neutral-50 text-neutral-900',
    isDarkCanvas: false,
  },
  {
    id: 'sky',
    labelEn: 'Sky Blue',
    labelBn: 'আকাশী নীল',
    labelAs: 'আকাশী নীলা',
    swatchClass: 'bg-gradient-to-br from-sky-100 to-cyan-200 border-sky-400',
    containerClass: 'bg-gradient-to-br from-sky-50/80 via-cyan-50/50 to-neutral-50 text-neutral-900',
    isDarkCanvas: false,
  },
  {
    id: 'midnight',
    labelEn: 'Midnight',
    labelBn: 'ডার্ক নাইট',
    labelAs: 'ডাৰ্ক নাইট',
    swatchClass: 'bg-slate-900 border-slate-700',
    containerClass: 'bg-slate-900 text-neutral-900',
    isDarkCanvas: true,
  },
];

export function loadSavedWallpaper(): WallpaperConfig {
  try {
    const raw = window.localStorage.getItem(WALLPAPER_STORAGE_KEY);
    if (!raw) return { id: 'clean' };
    const parsed = JSON.parse(raw) as WallpaperConfig;
    if (parsed.id === 'custom' && parsed.customImage?.startsWith('data:image/')) {
      return parsed;
    }
    if (WALLPAPER_OPTIONS.some((o) => o.id === parsed.id)) {
      return { id: parsed.id };
    }
  } catch {
    // Ignore storage read errors
  }
  return { id: 'clean' };
}

export function saveWallpaperConfig(config: WallpaperConfig): void {
  try {
    window.localStorage.setItem(WALLPAPER_STORAGE_KEY, JSON.stringify(config));
  } catch {
    // Ignore storage quota errors
  }
}

export function compressWallpaperFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read selected image file.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image format.'));
      img.onload = () => {
        const maxSide = 1280;
        let width = img.width;
        let height = img.height;
        if (width > maxSide || height > maxSide) {
          if (width >= height) {
            height = Math.round((height * maxSide) / width);
            width = maxSide;
          } else {
            width = Math.round((width * maxSide) / height);
            height = maxSide;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context unavailable.'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.72);
        resolve(dataUrl);
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}
