export function getGoogleMapsApiKey(): string {
  const viteKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  if (typeof viteKey === 'string' && viteKey.trim().length > 0) {
    return viteKey.trim();
  }
  const procKey =
    typeof process !== 'undefined' && process.env
      ? process.env.GOOGLE_MAPS_API_KEY
      : '';
  if (typeof procKey === 'string' && procKey.trim().length > 0) {
    return procKey.trim();
  }
  return '';
}

export const GMP_ATTRIBUTION_IDS = ['gmp_mcp_codeassist_v1_aistudio'];
export const DEFAULT_INDIA_CENTER = { lat: 22.5726, lng: 88.3639 }; // Kolkata, India
export const SMART_RIDE_MAP_ID = 'DEMO_MAP_ID';

export function isMapsQuotaError(err: unknown): boolean {
  if (!err) return false;
  const text =
    err instanceof Error
      ? `${err.name} ${err.message}`
      : typeof err === 'object'
      ? JSON.stringify(err)
      : String(err);
  return (
    text.includes('429') ||
    text.includes('RESOURCE_EXHAUSTED') ||
    text.includes('OVER_QUERY_LIMIT') ||
    text.includes('OverQuotaMapError') ||
    text.includes('QuotaExceededError')
  );
}

export function triggerMapsQuotaExceededIfMatched(err: unknown): boolean {
  if (isMapsQuotaError(err)) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
    return true;
  }
  return false;
}
