# Smart Ride Electric Rickshaw — Full Web Source Code

## Run Locally
1. Copy `firebase-applet-config.example.json` to `firebase-applet-config.json` and `.env.example` to `.env`.
2. Run `npm install`
3. Run `npm run dev` (starts on port 3000) or `npm run build`.

## Google Play Store Upload (.AAB)
Option 1 (Fastest — TWA / PWABuilder):
  1. Open https://www.pwabuilder.com and enter your live Shared App URL.
  2. Click Package For Stores -> Android -> Generate signed `.aab` + `assetlinks.json`.
  3. Upload `.aab` to https://play.google.com/console

Option 2 (Native Flutter):
  Download Customer/Driver Flutter ZIPs in Admin Console and run `flutter build appbundle --release`.